# PWA Icons

Erstelle hier zwei PNG-Dateien für die PWA:

## icon-192.png
- Größe: 192x192 Pixel
- Hintergrund: #111111 (dunkel)
- Inhalt: Text "MG" oder ein Mini-Game Logo

## icon-512.png
- Größe: 512x512 Pixel
- Hintergrund: #111111 (dunkel)
- Inhalt: Text "MG" oder ein Mini-Game Logo

Du kannst diese mit einem Bildbearbeitungsprogramm erstellen oder online PNG-Generatoren verwenden.