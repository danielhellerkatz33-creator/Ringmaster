import { useLanguage as useLanguageContext } from "@/lib/i18n/language-context"

export function useLanguage() {
  return useLanguageContext()
}