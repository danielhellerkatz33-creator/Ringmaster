"use client"

import { createContext, useContext, useEffect, useState, type ReactNode } from 'react'
import { supabase, type User } from '@/lib/supabase'
import { isDeveloperMode } from '@/lib/plans'

interface AuthContextType {
  user: User | null
  loading: boolean
  isPro: boolean
  signIn: (email: string, password: string) => Promise<{ error: any }>
  signUp: (email: string, password: string) => Promise<{ error: any }>
  signOut: () => Promise<void>
  refreshUser: () => Promise<void>
}

const AuthContext = createContext<AuthContextType | null>(null)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  // Check if user is pro (developer mode or database flag)
  const isPro = isDeveloperMode() || user?.is_pro || false

  // Fetch user data from our users table
  const fetchUserData = async (authUserId: string) => {
    if (!supabase) return null
    
    try {
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .eq('id', authUserId)
        .single()

      if (error && error.code !== 'PGRST116') { // PGRST116 = no rows returned
        console.error('Error fetching user data:', error)
        return null
      }

      // If user doesn't exist in our table, create them
      if (!data) {
        const authUser = await supabase.auth.getUser()
        if (authUser.data.user?.email) {
          const { data: newUser, error: insertError } = await supabase
            .from('users')
            .insert({
              id: authUserId,
              email: authUser.data.user.email,
              is_pro: false,
            })
            .select()
            .single()

          if (insertError) {
            console.error('Error creating user:', insertError)
            return null
          }
          return newUser
        }
        return null
      }

      return data
    } catch (error) {
      console.error('Error in fetchUserData:', error)
      return null
    }
  }

  // Initialize auth state
  useEffect(() => {
    const initializeAuth = async () => {
      if (!supabase) {
        setLoading(false)
        return
      }
      
      try {
        const { data: { session } } = await supabase.auth.getSession()
        
        if (session?.user) {
          const userData = await fetchUserData(session.user.id)
          setUser(userData)
        }
      } catch (error) {
        console.error('Error initializing auth:', error)
      } finally {
        setLoading(false)
      }
    }

    initializeAuth()

    // Listen for auth changes
    if (supabase) {
      const { data: { subscription } } = supabase.auth.onAuthStateChange(
        async (event, session) => {
          if (session?.user) {
            const userData = await fetchUserData(session.user.id)
            setUser(userData)
          } else {
            setUser(null)
          }
          setLoading(false)
        }
      )

      return () => subscription.unsubscribe()
    }
  }, [])

  const signIn = async (email: string, password: string) => {
    if (!supabase) return { error: { message: 'Supabase not configured' } }
    
    try {
      const { error } = await supabase.auth.signInWithPassword({
        email,
        password,
      })
      return { error }
    } catch (error) {
      return { error }
    }
  }

  const signUp = async (email: string, password: string) => {
    if (!supabase) return { error: { message: 'Supabase not configured' } }
    
    try {
      const { error } = await supabase.auth.signUp({
        email,
        password,
      })
      return { error }
    } catch (error) {
      return { error }
    }
  }

  const signOut = async () => {
    if (!supabase) return
    
    try {
      await supabase.auth.signOut()
      setUser(null)
    } catch (error) {
      console.error('Error signing out:', error)
    }
  }

  const refreshUser = async () => {
    if (!user || !supabase) return
    
    try {
      const { data } = await supabase
        .from('users')
        .select('*')
        .eq('id', user.id)
        .single()
      
      if (data) {
        setUser(data)
      }
    } catch (error) {
      console.error('Error refreshing user:', error)
    }
  }

  const value: AuthContextType = {
    user,
    loading,
    isPro,
    signIn,
    signUp,
    signOut,
    refreshUser,
  }

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}
