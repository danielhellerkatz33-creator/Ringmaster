import type { SeriesData, Character, Relationship, Storyline, Segment, Event, Season, Promotion, Arena, Show } from './types'

/**
 * Starter-Datenbank mit Beispieldaten für das Ringmaster Spiel
 * Diese Datenbank wird immer mit dem Spiel ausgeliefert und enthält:
 * - 15 erfundene Charaktere
 * - 20 erfundene Beziehungen
 * - Eine Probe-Storyline mit 4 Segmenten
 * - Titel: "Unter unseren guten Zeiten"
 */

// Erfundene Charaktere
export const starterCharacters: Character[] = [
  {
    id: "char-alex",
    name: "Alexander Weber",
    position: "main_event",
    alignment: "face",
    status: "active",
    hometown: "Berlin, Deutschland",
    createdAt: new Date("2026-01-01T10:00:00Z"),
    updatedAt: new Date("2026-01-01T10:00:00Z")
  },
  {
    id: "char-sarah",
    name: "Sarah Müller",
    position: "mid_card",
    alignment: "face",
    status: "active",
    hometown: "Hamburg, Deutschland",
    createdAt: new Date("2026-01-01T10:00:00Z"),
    updatedAt: new Date("2026-01-01T10:00:00Z")
  },
  {
    id: "char-michael",
    name: "Michael Bauer",
    position: "mid_card",
    alignment: "face",
    status: "active",
    hometown: "München, Deutschland",
    createdAt: new Date("2026-01-01T10:00:00Z"),
    updatedAt: new Date("2026-01-01T10:00:00Z")
  },
  {
    id: "char-lena",
    name: "Lena Hoffmann",
    position: "mid_card",
    alignment: "tweener",
    status: "active",
    hometown: "Köln, Deutschland",
    createdAt: new Date("2026-01-01T10:00:00Z"),
    updatedAt: new Date("2026-01-01T10:00:00Z")
  },
  {
    id: "char-thomas",
    name: "Thomas Richter",
    position: "upper_card",
    alignment: "heel",
    status: "active",
    hometown: "Frankfurt, Deutschland",
    createdAt: new Date("2026-01-01T10:00:00Z"),
    updatedAt: new Date("2026-01-01T10:00:00Z")
  },
  {
    id: "char-anna",
    name: "Anna Schmidt",
    position: "mid_card",
    alignment: "face",
    status: "active",
    hometown: "Stuttgart, Deutschland",
    createdAt: new Date("2026-01-01T10:00:00Z"),
    updatedAt: new Date("2026-01-01T10:00:00Z")
  },
  {
    id: "char-marc",
    name: "Marc Wagner",
    position: "mid_card",
    alignment: "heel",
    status: "active",
    hometown: "Düsseldorf, Deutschland",
    createdAt: new Date("2026-01-01T10:00:00Z"),
    updatedAt: new Date("2026-01-01T10:00:00Z")
  },
  {
    id: "char-julia",
    name: "Julia Klein",
    position: "lower_card",
    alignment: "face",
    status: "retired",
    hometown: "Leipzig, Deutschland",
    createdAt: new Date("2026-01-01T10:00:00Z"),
    updatedAt: new Date("2026-01-01T10:00:00Z")
  },
  {
    id: "char-peter",
    name: "Peter Lange",
    position: "staff",
    alignment: "face",
    status: "retired",
    hometown: "Dresden, Deutschland",
    createdAt: new Date("2026-01-01T10:00:00Z"),
    updatedAt: new Date("2026-01-01T10:00:00Z")
  },
  {
    id: "char-katharina",
    name: "Katharina Weber",
    position: "lower_card",
    alignment: "face",
    status: "inactive",
    hometown: "Bremen, Deutschland",
    createdAt: new Date("2026-01-01T10:00:00Z"),
    updatedAt: new Date("2026-01-01T10:00:00Z")
  },
  {
    id: "char-nina",
    name: "Nina Vogel",
    position: "jobber",
    alignment: "face",
    status: "active",
    hometown: "Hannover, Deutschland",
    createdAt: new Date("2026-01-01T10:00:00Z"),
    updatedAt: new Date("2026-01-01T10:00:00Z")
  },
  {
    id: "char-david",
    name: "David Meier",
    position: "commentary",
    alignment: "face",
    status: "active",
    hometown: "Nürnberg, Deutschland",
    createdAt: new Date("2026-01-01T10:00:00Z"),
    updatedAt: new Date("2026-01-01T10:00:00Z")
  },
  {
    id: "char-lisa",
    name: "Lisa Braun",
    position: "jobber",
    alignment: "face",
    status: "active",
    hometown: "Dortmund, Deutschland",
    createdAt: new Date("2026-01-01T10:00:00Z"),
    updatedAt: new Date("2026-01-01T10:00:00Z")
  },
  {
    id: "char-robert",
    name: "Robert Fuchs",
    position: "manager",
    alignment: "heel",
    status: "active",
    hometown: "Essen, Deutschland",
    createdAt: new Date("2026-01-01T10:00:00Z"),
    updatedAt: new Date("2026-01-01T10:00:00Z")
  },
  {
    id: "char-emily",
    name: "Emily Wagner",
    position: "manager",
    alignment: "face",
    status: "active",
    hometown: "Bielefeld, Deutschland",
    createdAt: new Date("2026-01-01T10:00:00Z"),
    updatedAt: new Date("2026-01-01T10:00:00Z")
  }
]

// Erfundene Beziehungen (20 Stück)
export const starterRelationships: Relationship[] = [
  {
    id: "rel-alex-sarah",
    characterIds: ["char-alex", "char-sarah"],
    type: "family",
    description: "Geschwisterliche Beziehung - Sarah versucht seit Jahren, Alexander zu helfen",
    intensity: 8,
    episodes: [],
    evolution: []
  },
  {
    id: "rel-alex-michael",
    characterIds: ["char-alex", "char-michael"],
    type: "friendship",
    description: "Beste Freunde seit Kindertagen - Michael ist einer der wenigen, die Alexander noch vertraut",
    intensity: 9,
    episodes: [],
    evolution: []
  },
  {
    id: "rel-alex-lena",
    characterIds: ["char-alex", "char-lena"],
    type: "romantic",
    description: "Neue romantische Beziehung - Alexander öffnet sich langsam wieder für die Liebe",
    intensity: 6,
    episodes: [],
    evolution: []
  },
  {
    id: "rel-alex-thomas",
    characterIds: ["char-alex", "char-thomas"],
    type: "enemy",
    description: "Ehemalige Geschäftspartner - Thomas hat Alexander vor Jahren betrogen",
    intensity: 9,
    episodes: [],
    evolution: []
  },
  {
    id: "rel-alex-julia",
    characterIds: ["char-alex", "char-julia"],
    type: "ex-romantic",
    description: "Verstorbene Ehefrau - Julia war die Liebe seines Lebens",
    intensity: 10,
    episodes: [],
    evolution: []
  },
  {
    id: "rel-sarah-anna",
    characterIds: ["char-sarah", "char-anna"],
    type: "friendship",
    description: "Beste Freundinnen und Kolleginnen - Anna unterstützt Sarah in allen Lebenslagen",
    intensity: 8,
    episodes: [],
    evolution: []
  },
  {
    id: "rel-lena-marc",
    characterIds: ["char-lena", "char-marc"],
    type: "ex-romantic",
    description: "Komplizierte Ex-Beziehung - Marc kann die Trennung nicht akzeptieren",
    intensity: 7,
    episodes: [],
    evolution: []
  },
  {
    id: "rel-peter-alex",
    characterIds: ["char-peter", "char-alex"],
    type: "family",
    description: "Vater-Sohn Beziehung - Peter versucht, Alexander durch seine Trauer zu helfen",
    intensity: 7,
    episodes: [],
    evolution: []
  },
  {
    id: "rel-peter-sarah",
    characterIds: ["char-peter", "char-sarah"],
    type: "family",
    description: "Vater-Tochter Beziehung - Peter ist stolz auf Sarahs Erfolge",
    intensity: 8,
    episodes: [],
    evolution: []
  },
  {
    id: "rel-alex-peter",
    characterIds: ["char-alex", "char-peter"],
    type: "family",
    description: "Vater-Sohn Beziehung - spiegelbildlich zur anderen Richtung",
    intensity: 7,
    episodes: [],
    evolution: []
  },
  {
    id: "rel-marc-emily",
    characterIds: ["char-marc", "char-emily"],
    type: "family",
    description: "Geschwisterliche Beziehung - Emily sorgt sich um ihren instabilen Bruder",
    intensity: 6,
    episodes: [],
    evolution: []
  },
  {
    id: "rel-thomas-robert",
    characterIds: ["char-thomas", "char-robert"],
    type: "professional",
    description: "Geschäftspartner - Robert unterstützt Thomas' Machenschaften",
    intensity: 7,
    episodes: [],
    evolution: []
  },
  {
    id: "rel-michael-david",
    characterIds: ["char-michael", "char-david"],
    type: "professional",
    description: "Kollegen - David ist Michaels Mentor im Journalismus",
    intensity: 5,
    episodes: [],
    evolution: []
  },
  {
    id: "rel-lena-lisa",
    characterIds: ["char-lena", "char-lisa"],
    type: "friendship",
    description: "Alte Freundinnen - Lisa taucht überraschend wieder in Lenas Leben auf",
    intensity: 6,
    episodes: [],
    evolution: []
  },
  {
    id: "rel-sarah-alex",
    characterIds: ["char-sarah", "char-alex"],
    type: "family",
    description: "Geschwisterliche Beziehung - spiegelbildlich zur anderen Richtung",
    intensity: 8,
    episodes: [],
    evolution: []
  },
  {
    id: "rel-alex-nina",
    characterIds: ["char-alex", "char-nina"],
    type: "friendship",
    description: "Nachbarn - Nina beobachtet Alexander und wird Zeugin wichtiger Ereignisse",
    intensity: 3,
    episodes: [],
    evolution: []
  },
  {
    id: "rel-lena-alex",
    characterIds: ["char-lena", "char-alex"],
    type: "romantic",
    description: "Romantische Beziehung - spiegelbildlich zur anderen Richtung",
    intensity: 6,
    episodes: [],
    evolution: []
  },
  {
    id: "rel-thomas-alex",
    characterIds: ["char-thomas", "char-alex"],
    type: "enemy",
    description: "Feindschaft - spiegelbildlich zur anderen Richtung",
    intensity: 9,
    episodes: [],
    evolution: []
  },
  {
    id: "rel-michael-alex",
    characterIds: ["char-michael", "char-alex"],
    type: "friendship",
    description: "Freundschaft - spiegelbildlich zur anderen Richtung",
    intensity: 9,
    episodes: [],
    evolution: []
  },
  {
    id: "rel-anna-sarah",
    characterIds: ["char-anna", "char-sarah"],
    type: "friendship",
    description: "Freundschaft - spiegelbildlich zur anderen Richtung",
    intensity: 8,
    episodes: [],
    evolution: []
  }
]

// Probe-Storyline mit 4 Segmenten
export const starterStorylines: Storyline[] = [
  {
    id: "storyline-main",
    title: "Unter unseren guten Zeiten",
    description: "Alexander Weber versucht nach dem Tod seiner Frau, sein Leben wieder in den Griff zu bekommen. Dabei trifft er auf neue Menschen und alte Bekannte, die seine Heilung vorantreiben.",
    type: "main",
    status: "active",
    characterIds: ["char-alex", "char-sarah", "char-michael", "char-lena", "char-thomas"],
    color: "#3b82f6",
    createdAt: new Date("2026-01-01T10:00:00Z"),
    characterReview: "Alexander ist der Protagonist, der nach einem schweren Verlust versucht, sein Leben neu zu ordnen. Seine Schwester Sarah unterstützt ihn loyal, während sein Freund Michael ihn motiviert, neue Schritte zu wagen. Lena bringt frischen Wind in sein Leben, aber Thomas droht, alles zu zerstören.",
    summary: "Eine Geschichte über Trauer, Heilung und neuen Lebensmut in einer modernen Großstadt."
  }
]

export const starterScenes: Segment[] = [
  {
    id: "scene-1",
    title: "Das leere Haus",
    description: "Alexander sitzt allein in seinem dunklen Wohnzimmer und starrt auf alte Fotos. Die Stille wird von der Türklingel unterbrochen.",
    storylineId: "storyline-main",
    characterIds: ["char-alex"],
    notes: "Erste Szene etabliert Alexanders Isolation und Trauer. Die Türklingel symbolisiert den Einbruch der Außenwelt.",
    duration: 8,
    order: 1
  },
  {
    id: "scene-2",
    title: "Das unerwartete Treffen",
    description: "Alexander öffnet die Tür und findet Lena vor, die sich in der Adresse geirrt hat. Trotz der Verwechslung kommen sie ins Gespräch.",
    storylineId: "storyline-main",
    characterIds: ["char-alex", "char-lena"],
    notes: "Zufällige Begegnung führt zu erster Verbindung. Lena bringt frische Energie in Alexanders Leben.",
    duration: 12,
    order: 2
  },
  {
    id: "scene-3",
    title: "Der Anruf der Vergangenheit",
    description: "Thomas ruft Alexander an und behauptet, ein gemeinsames Geschäft wiederbeleben zu wollen. Alexander ist misstrauisch.",
    storylineId: "storyline-main",
    characterIds: ["char-alex", "char-thomas"],
    notes: "Einführung des Antagonisten. Thomas' Auftauchen droht, Alexanders fragile Heilung zu zerstören.",
    duration: 10,
    order: 3
  },
  {
    id: "scene-4",
    title: "Die Hoffnung keimt",
    description: "Alexander trifft sich mit Michael in einem Café. Sein Freund ermutigt ihn, neue Chancen zu ergreifen und nicht in der Vergangenheit zu verharren.",
    storylineId: "storyline-main",
    characterIds: ["char-alex", "char-michael"],
    notes: "Michael als Unterstützerfigur stärkt Alexanders Entschlossenheit. Szene endet mit neuem Lebensmut.",
    duration: 15,
    order: 4
  }
]

// Beispiel-Championships mit aktuellen Champions
export const starterCharacterArcs: any[] = [
  {
    id: "champ-world-heavyweight",
    characterId: "char-alex", // Alexander Weber als aktueller Champion
    title: "World Heavyweight Championship",
    description: "Der wichtigste Titel der Promotion",
    status: "active",
    type: "singles",
    prestige: "world",
    currentChampionIds: ["char-alex"],
    championHistory: [
      {
        id: "reign-1",
        championIds: ["char-alex"],
        dateWon: new Date("2026-01-15"),
        defenses: 2,
        isHistorical: false
      }
    ],
    createdAt: new Date("2026-01-01T10:00:00Z"),
    updatedAt: new Date("2026-01-15T10:00:00Z")
  },
  {
    id: "champ-national",
    characterId: "char-thomas", // Thomas Richter als aktueller Champion
    title: "National Championship",
    description: "Der zweitwichtigste Titel",
    status: "active",
    type: "singles",
    prestige: "national",
    currentChampionIds: ["char-thomas"],
    championHistory: [
      {
        id: "reign-1",
        championIds: ["char-thomas"],
        dateWon: new Date("2026-01-10"),
        defenses: 1,
        isHistorical: false
      }
    ],
    createdAt: new Date("2026-01-01T10:00:00Z"),
    updatedAt: new Date("2026-01-10T10:00:00Z")
  },
  {
    id: "champ-tag-team",
    characterId: "char-sarah", // Sarah Müller als Teil des Tag Teams
    title: "World Tag Team Championship",
    description: "Die wichtigsten Tag Team Titel",
    status: "active",
    type: "tag_team",
    prestige: "world",
    currentChampionIds: ["char-sarah", "char-michael"], // Sarah & Michael als Tag Team
    championHistory: [
      {
        id: "reign-1",
        championIds: ["char-sarah", "char-michael"],
        dateWon: new Date("2026-01-20"),
        defenses: 0,
        isHistorical: false
      }
    ],
    createdAt: new Date("2026-01-01T10:00:00Z"),
    updatedAt: new Date("2026-01-20T10:00:00Z")
  }
]
export const starterEpisodes: Event[] = []
export const starterSeasons: Season[] = []

// Serien-Definition
export const starterSeries: any[] = [
  {
    id: "series-main",
    title: "Unter unseren guten Zeiten",
    logline: "Ein Architekt kämpft nach dem Tod seiner Frau um seine Zukunft und findet unerwartete Hoffnung in neuen Begegnungen.",
    genre: ["Drama", "Romanze"],
    createdAt: new Date("2026-01-01T10:00:00Z")
  }
]

// Komplette Starter-Datenbank
export const starterDatabase: SeriesData = {
  series: starterSeries,
  characters: starterCharacters,
  relationships: starterRelationships,
  characterArcs: starterCharacterArcs,
  storylines: starterStorylines,
  segments: starterScenes,
  episodes: starterEpisodes,
  seasons: starterSeasons,
  locations: [],
  moods: [],
  promotions: [],
  arenas: [],
  shows: []
}

/**
 * Gibt die Starter-Datenbank zurück
 * Verwendet jetzt die funktionierende Save-Datei als Basis
 */
export function getStarterDatabase(): SeriesData {
  try {
    // Versuche die funktionierende Save-Datei zu laden
    const fs = require('fs');
    const path = require('path');

    const savePath = path.join(process.cwd(), 'Save Games', 'tv-series-manager-savegame-2026-01-11T07-29-29.json');
    const saveData = JSON.parse(fs.readFileSync(savePath, 'utf8'));

    console.log('✅ Starter-Datenbank erfolgreich aus funktionierender Save-Datei geladen');

    return JSON.parse(JSON.stringify(saveData.data)); // Deep copy
  } catch (error) {
    console.warn('⚠️ Konnte funktionierende Save-Datei nicht laden, verwende Standard-Starter-Daten:', error instanceof Error ? error.message : String(error));

    // Fallback zu Standard-Daten
    return JSON.parse(JSON.stringify(starterDatabase)); // Deep copy
  }
}