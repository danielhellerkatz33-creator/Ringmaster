import { loadStripe } from '@stripe/stripe-js'

// Get Stripe publishable key from environment
const publishableKey = process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY

// Create Stripe instance
export const stripePromise = publishableKey ? loadStripe(publishableKey) : null

// Helper function to check if Stripe is configured
export const isStripeConfigured = (): boolean => {
  return !!publishableKey && !publishableKey.includes('pk_test_...')
}

// Create checkout session
export const createCheckoutSession = async (userId: string, userEmail: string) => {
  if (!publishableKey) {
    throw new Error('Stripe not configured')
  }

  try {
    const response = await fetch('/api/checkout', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        userId,
        userEmail,
      }),
    })

    if (!response.ok) {
      throw new Error('Failed to create checkout session')
    }

    const { sessionId } = await response.json()
    return sessionId
  } catch (error) {
    console.error('Error creating checkout session:', error)
    throw error
  }
}
