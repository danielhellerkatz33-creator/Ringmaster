// Plan system for Ringmaster App - Freemium model with Pro upgrade

export interface PlanLimits {
  maxWrestlers: number
  maxActiveStorylines: number
  maxSegments?: number
  maxEpisodes?: number
}

export interface Plan {
  name: string
  limits: PlanLimits
  isPro: boolean
}

export const PLANS: Record<'free' | 'pro', Plan> = {
  free: {
    name: 'Free',
    limits: {
      maxWrestlers: 50,
      maxActiveStorylines: 10,
      maxSegments: 100,
      maxEpisodes: 20,
    },
    isPro: false,
  },
  pro: {
    name: 'Pro',
    limits: {
      maxWrestlers: Infinity,
      maxActiveStorylines: Infinity,
      maxSegments: Infinity,
      maxEpisodes: Infinity,
    },
    isPro: true,
  },
}

// Developer mode override for unlimited access during development
export const isDeveloperMode = (): boolean => {
  return process.env.NEXT_PUBLIC_DEVELOPER_MODE === 'true'
}

// Get current user plan - now takes user pro status into account
export const getCurrentPlan = (userIsPro: boolean = false): Plan => {
  // Developer mode always gets pro plan
  if (isDeveloperMode()) {
    return PLANS.pro
  }
  
  // User's pro status determines plan
  return userIsPro ? PLANS.pro : PLANS.free
}

// Helper functions to check if user can perform actions
export const canCreateWrestler = (currentCount: number, userIsPro: boolean = false): boolean => {
  if (isDeveloperMode()) return true
  const plan = getCurrentPlan(userIsPro)
  return currentCount < plan.limits.maxWrestlers
}

export const canActivateStoryline = (activeCount: number, userIsPro: boolean = false): boolean => {
  if (isDeveloperMode()) return true
  const plan = getCurrentPlan(userIsPro)
  return activeCount < plan.limits.maxActiveStorylines
}

export const canCreateSegment = (currentCount: number, userIsPro: boolean = false): boolean => {
  if (isDeveloperMode()) return true
  const plan = getCurrentPlan(userIsPro)
  return currentCount < (plan.limits.maxSegments || Infinity)
}

export const canCreateEpisode = (currentCount: number, userIsPro: boolean = false): boolean => {
  if (isDeveloperMode()) return true
  const plan = getCurrentPlan(userIsPro)
  return currentCount < (plan.limits.maxEpisodes || Infinity)
}

// Get remaining counts for UI display
export const getRemainingCounts = (currentData: {
  wrestlers: number
  activeStorylines: number
  segments?: number
  episodes?: number
}, userIsPro: boolean = false) => {
  const plan = getCurrentPlan(userIsPro)
  
  return {
    wrestlers: isDeveloperMode() ? Infinity : Math.max(0, plan.limits.maxWrestlers - currentData.wrestlers),
    activeStorylines: isDeveloperMode() ? Infinity : Math.max(0, plan.limits.maxActiveStorylines - currentData.activeStorylines),
    segments: isDeveloperMode() ? Infinity : Math.max(0, (plan.limits.maxSegments || Infinity) - (currentData.segments || 0)),
    episodes: isDeveloperMode() ? Infinity : Math.max(0, (plan.limits.maxEpisodes || Infinity) - (currentData.episodes || 0)),
  }
}

// Check if any limit is reached (for upgrade prompts)
export const isAnyLimitReached = (currentData: {
  wrestlers: number
  activeStorylines: number
  segments?: number
  episodes?: number
}, userIsPro: boolean = false): boolean => {
  if (isDeveloperMode()) return false
  
  const plan = getCurrentPlan(userIsPro)
  return (
    currentData.wrestlers >= plan.limits.maxWrestlers ||
    currentData.activeStorylines >= plan.limits.maxActiveStorylines ||
    (currentData.segments || 0) >= (plan.limits.maxSegments || Infinity) ||
    (currentData.episodes || 0) >= (plan.limits.maxEpisodes || Infinity)
  )
}

// Get specific limit that was reached
export const getReachedLimit = (currentData: {
  wrestlers: number
  activeStorylines: number
  segments?: number
  episodes?: number
}, userIsPro: boolean = false): string | null => {
  if (isDeveloperMode()) return null
  
  const plan = getCurrentPlan(userIsPro)
  
  if (currentData.wrestlers >= plan.limits.maxWrestlers) {
    return 'wrestlers'
  }
  if (currentData.activeStorylines >= plan.limits.maxActiveStorylines) {
    return 'activeStorylines'
  }
  if ((currentData.segments || 0) >= (plan.limits.maxSegments || Infinity)) {
    return 'segments'
  }
  if ((currentData.episodes || 0) >= (plan.limits.maxEpisodes || Infinity)) {
    return 'episodes'
  }
  
  return null
}

// Format limit text for UI
export const formatLimitText = (type: string, current: number, max: number): string => {
  if (isDeveloperMode() || max === Infinity) {
    return `${current} (unbegrenzt im Developer Mode)`
  }
  
  const typeNames: Record<string, string> = {
    wrestlers: 'Wrestler',
    activeStorylines: 'aktive Storylines',
    segments: 'Segmente',
    episodes: 'Events',
  }
  
  return `${current} / ${max} ${typeNames[type] || type}`
}
