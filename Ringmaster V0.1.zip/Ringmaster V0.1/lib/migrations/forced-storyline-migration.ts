// Erneute Migration für Segmente, die noch storylineId haben
import { indexedDBStorage } from "../indexeddb-storage"

export async function runForcedStorylineMigration(): Promise<void> {
  try {
    console.log("Starting FORCED storyline migration...")
    
    // Alle Daten aus IndexedDB holen
    const data = await indexedDBStorage.getAllData()
    
    if (!data.segments || data.segments.length === 0) {
      console.log("No segments found, skipping migration")
      return
    }
    
    console.log(`Found ${data.segments.length} segments to check`)
    
    let migratedCount = 0
    
    // Nur Segmente migrieren, die noch storylineId haben
    for (const segment of data.segments) {
      const hasOldFormat = (segment as any).storylineId !== undefined
      const hasNewFormat = segment.storylineIds && segment.storylineIds.length > 0
      
      if (hasOldFormat && !hasNewFormat) {
        // Konvertiere altes Format
        const oldStorylineId = (segment as any).storylineId
        const updatedSegment = {
          ...segment,
          storylineIds: oldStorylineId ? [oldStorylineId] : [],
        }
        
        // Entferne altes Feld
        delete (updatedSegment as any).storylineId
        
        await indexedDBStorage.saveSegment(updatedSegment)
        migratedCount++
        console.log(`Migrated segment: ${segment.title}`)
      }
    }
    
    console.log(`FORCED storyline migration completed! Migrated ${migratedCount} segments`)
    
  } catch (error) {
    console.error("FORCED storyline migration failed:", error)
    throw error
  }
}

// Funktion zum Aufrufen aus der Browser-Konsole
// Führe dies aus: window.runForcedStorylineMigration()
if (typeof window !== 'undefined') {
  (window as any).runForcedStorylineMigration = runForcedStorylineMigration
}
