// Manuelle Migration für bestehende IndexedDB-Daten
import { indexedDBStorage } from "../indexeddb-storage"
import { migrateSegmentsToMultipleStorylines } from "./segment-storyline-migration"

export async function runManualStorylineMigration(): Promise<void> {
  try {
    console.log("Starting manual storyline migration...")
    
    // Alle Daten aus IndexedDB holen
    const data = await indexedDBStorage.getAllData()
    
    if (!data.segments || data.segments.length === 0) {
      console.log("No segments found, skipping migration")
      return
    }
    
    console.log(`Found ${data.segments.length} segments to migrate`)
    
    // Migration durchführen
    const migratedData = migrateSegmentsToMultipleStorylines(data)
    
    // Nur Segmente neu speichern (andere Daten bleiben unverändert)
    for (const segment of migratedData.segments) {
      await indexedDBStorage.saveSegment(segment)
    }
    
    console.log("Manual storyline migration completed successfully!")
    
  } catch (error) {
    console.error("Manual storyline migration failed:", error)
    throw error
  }
}

// Funktion zum Aufrufen aus der Browser-Konsole
// Führe dies aus: window.runManualStorylineMigration()
if (typeof window !== 'undefined') {
  (window as any).runManualStorylineMigration = runManualStorylineMigration
}
