// Migration für bestehende Segmente von storylineId zu storylineIds
export function migrateSegmentsToMultipleStorylines(data: any): any {
  if (!data.segments || !Array.isArray(data.segments)) {
    return data
  }

  return {
    ...data,
    segments: data.segments.map((segment: any) => {
      // Wenn bereits storylineIds existiert, nichts tun
      if (segment.storylineIds && Array.isArray(segment.storylineIds)) {
        return segment
      }
      
      // Wenn storylineId existiert, zu storylineIds konvertieren
      if (segment.storylineId) {
        return {
          ...segment,
          storylineIds: [segment.storylineId],
          storylineId: undefined // Altes Feld entfernen
        }
      }
      
      // Weder storylineId noch storylineIds - leeres Array setzen
      return {
        ...segment,
        storylineIds: []
      }
    })
  }
}
