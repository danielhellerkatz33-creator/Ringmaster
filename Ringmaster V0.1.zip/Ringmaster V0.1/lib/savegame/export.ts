import { indexedDBStorage } from "../indexeddb-storage"
import type { SavegameAsset } from "./schema"

/**
 * Sammelt alle Avatar-Assets aus IndexedDB
 */
async function collectAvatarAssets(): Promise<SavegameAsset[]> {
  try {
    const assets: SavegameAsset[] = []
    // In IndexedDB gibt es einen "blobs" Store für alle Blob-Daten
    // Wir müssen alle Blob-Keys finden, die mit "avatar-" beginnen

    // Da wir keinen direkten Zugriff auf alle Blob-Keys haben,
    // sammeln wir sie aus den Character-Daten
    const characters = await indexedDBStorage.getCharacters()

    for (const character of characters) {
      if (character.avatarBlobId) {
        try {
          const blob = await indexedDBStorage.getBlob(character.avatarBlobId)
          if (blob) {
            // Konvertiere Blob zu Base64
            const base64 = await blobToBase64(blob)
            assets.push({
              avatarKey: character.avatarBlobId,
              mimeType: blob.type || 'image/jpeg',
              dataBase64: base64,
            })
          }
        } catch (error) {
          console.warn(`Failed to export avatar ${character.avatarBlobId}:`, error)
        }
      }
    }

    return assets
  } catch (error) {
    console.error("Failed to collect avatar assets:", error)
    return []
  }
}

/**
 * Konvertiert einen Blob zu Base64 String
 */
function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => {
      const result = reader.result as string
      // Entferne den Data-URL-Prefix (data:mime;base64,)
      const base64 = result.split(',')[1]
      resolve(base64)
    }
    reader.onerror = reject
    reader.readAsDataURL(blob)
  })
}

/**
 * Erstellt einen Dateinamen für das Savegame
 */
function generateFilename(): string {
  const now = new Date()
  const dateStr = now.toISOString().slice(0, 19).replace(/[:.]/g, '-')
  return `ringmaster-savegame-${dateStr}.json`
}

/**
 * Exportiert das komplette Savegame als JSON-Datei
 */
export async function exportSavegame(includeAssets: boolean = true): Promise<void> {
  try {
    console.log("Starting savegame export...")

    // Sammle alle Daten aus IndexedDB
    const data = await indexedDBStorage.getAllData()

    // Sammle Assets falls gewünscht
    let assets = undefined
    if (includeAssets) {
      console.log("Collecting avatar assets...")
      const avatarAssets = await collectAvatarAssets()
      if (avatarAssets.length > 0) {
        assets = { avatars: avatarAssets }
      }
    }

    // Erstelle Savegame-Objekt
    const savegame = {
      schemaVersion: 1,
      exportedAt: new Date().toISOString(),
      appVersion: "1.0.0", // Könnte aus package.json kommen
      data,
      ...(assets && { assets }),
    }

    // Konvertiere zu JSON
    const jsonString = JSON.stringify(savegame, null, 2)

    // Erstelle Download-Link
    const blob = new Blob([jsonString], { type: 'application/json' })
    const url = URL.createObjectURL(blob)

    const link = document.createElement('a')
    link.href = url
    link.download = generateFilename()
    link.style.display = 'none'

    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)

    URL.revokeObjectURL(url)

    console.log("Savegame export completed successfully")
    return Promise.resolve()

  } catch (error) {
    console.error("Savegame export failed:", error)
    throw new Error("Export fehlgeschlagen. Bitte versuchen Sie es erneut.")
  }
}