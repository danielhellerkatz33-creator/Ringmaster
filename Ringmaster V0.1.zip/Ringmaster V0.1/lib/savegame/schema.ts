import { z } from "zod"

// Basis-Schema für Savegame-Assets
export const SavegameAssetSchema = z.object({
  avatarKey: z.string(),
  mimeType: z.string(),
  dataBase64: z.string(),
})

export type SavegameAsset = z.infer<typeof SavegameAssetSchema>

// Basis-Schema für Savegame-Daten
export const SavegameDataSchema = z.object({
  series: z.union([z.array(z.any()), z.any()]).nullable().optional(), // Series[] oder Series oder null (für Rückwärtskompatibilität)
  characters: z.array(z.any()).optional(), // Character[]
  relationships: z.array(z.any()).optional(), // Relationship[]
  characterArcs: z.array(z.any()).optional(), // CharacterArc[]
  storylines: z.array(z.any()).optional(), // Storyline[]
  segments: z.array(z.any()).optional(), // Segment[]
  episodes: z.array(z.any()).optional(), // Episode[]
  seasons: z.array(z.any()).optional(), // Season[]
})

// Haupt-Schema für Savegame
export const SavegameSchema = z.object({
  schemaVersion: z.number().optional(), // Erlaube verschiedene Versionen oder fehlende Version
  exportedAt: z.string().datetime().optional(), // Mache optional für ältere Formate
  appVersion: z.string().optional(),
  data: SavegameDataSchema,
  assets: z.object({
    avatars: z.array(SavegameAssetSchema),
  }).optional(),
})

export type Savegame = z.infer<typeof SavegameSchema>
export type SavegameData = z.infer<typeof SavegameDataSchema>

// Hilfsfunktion zur Konvertierung alter Savegame-Formate
function migrateSavegameData(data: any): any {
  const migratedData = { ...data }

  // Stelle sicher, dass data-Objekt existiert
  if (!migratedData.data) {
    migratedData.data = {}
  }

  // Fehlende Felder mit Standardwerten füllen
  migratedData.data.series = migratedData.data.series || []
  migratedData.data.characters = migratedData.data.characters || []
  migratedData.data.relationships = migratedData.data.relationships || []
  migratedData.data.characterArcs = migratedData.data.characterArcs || []
  migratedData.data.storylines = migratedData.data.storylines || []
  migratedData.data.segments = migratedData.data.segments || []
  migratedData.data.episodes = migratedData.data.episodes || []
  migratedData.data.seasons = migratedData.data.seasons || []

  // Konvertiere series von Objekt/null zu Array (für Rückwärtskompatibilität)
  if (migratedData.data.series === null) {
    // null -> leeres Array
    migratedData.data.series = []
  } else if (!Array.isArray(migratedData.data.series)) {
    // einzelnes Objekt -> Array mit einem Element
    migratedData.data.series = [migratedData.data.series]
  } else if (Array.isArray(migratedData.data.series) && migratedData.data.series.length > 0 && Array.isArray(migratedData.data.series[0])) {
    // Doppel-Array-Problem beheben: [[{...}]] -> [{...}]
    migratedData.data.series = migratedData.data.series[0]
  }
  // Array bleibt unverändert

  // Fehlende Hauptfelder mit Standardwerten füllen
  migratedData.schemaVersion = migratedData.schemaVersion || 1
  migratedData.exportedAt = migratedData.exportedAt || new Date().toISOString()
  migratedData.appVersion = migratedData.appVersion || "1.0.0"

  return migratedData
}

// Validierung für verschiedene Schema-Versionen
export function validateSavegame(data: unknown): { success: true; data: Savegame } | { success: false; error: string } {
  try {
    // Zuerst versuchen wir das neue Format zu validieren
    const result = SavegameSchema.safeParse(data)

    if (result.success) {
      // Wenn es das neue Format ist, konvertieren wir trotzdem für Konsistenz
      const migratedData = migrateSavegameData(result.data)
      const finalResult = SavegameSchema.safeParse(migratedData)

      if (finalResult.success) {
        return { success: true, data: finalResult.data }
      }
    }

    // Wenn das neue Format nicht passt, versuchen wir mit Migration
    const migratedData = migrateSavegameData(data)
    const migratedResult = SavegameSchema.safeParse(migratedData)

    if (migratedResult.success) {
      return { success: true, data: migratedResult.data }
    }

    // Log migrated errors for debugging
    console.error('Migrated savegame validation errors:', migratedResult.error?.issues)

    // Wenn alles fehlschlägt, geben wir den ursprünglichen Fehler zurück
    const errorMessages = result.error?.issues.map(i => `${i.path.join('.')}: ${i.message}`) || ['Unbekannter Fehler']
    console.error('Savegame validation errors:', result.error?.issues)
    return {
      success: false,
      error: `Ungültiges Savegame-Format: ${errorMessages.join(', ')}`
    }

  } catch (error) {
    return {
      success: false,
      error: `Validierungsfehler: ${error instanceof Error ? error.message : 'Unbekannter Fehler'}`
    }
  }
}

// Schema-Version-Checker
export function isSupportedSchemaVersion(version: number): boolean {
  return version === 1
}