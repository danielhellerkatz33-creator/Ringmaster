import { indexedDBStorage } from "../indexeddb-storage"
import { validateSavegame, isSupportedSchemaVersion, type Savegame } from "./schema"

/**
 * Stellt Assets aus dem Savegame wieder her
 */
async function restoreAssets(savegame: Savegame): Promise<void> {
  if (!savegame.assets?.avatars) return

  console.log(`Restoring ${savegame.assets.avatars.length} avatar assets...`)

  for (const asset of savegame.assets.avatars) {
    try {
      // Konvertiere Base64 zurück zu Blob
      const blob = base64ToBlob(asset.dataBase64, asset.mimeType)
      await indexedDBStorage.saveBlob(asset.avatarKey, blob)
    } catch (error) {
      console.warn(`Failed to restore asset ${asset.avatarKey}:`, error)
    }
  }
}

/**
 * Konvertiert Base64 String zurück zu Blob
 */
function base64ToBlob(base64: string, mimeType: string): Blob {
  const byteCharacters = atob(base64)
  const byteNumbers = new Array(byteCharacters.length)

  for (let i = 0; i < byteCharacters.length; i++) {
    byteNumbers[i] = byteCharacters.charCodeAt(i)
  }

  const byteArray = new Uint8Array(byteNumbers)
  return new Blob([byteArray], { type: mimeType })
}

/**
 * Validiert und importiert ein Savegame
 */
export async function importSavegame(
  file: File,
  onProgress?: (step: string) => void
): Promise<{ success: true } | { success: false; error: string }> {
  try {
    onProgress?.("Datei wird gelesen...")

    // Datei als Text lesen
    const jsonString = await file.text()

    onProgress?.("Savegame wird validiert...")

    // JSON parsen und validieren
    let parsedData: unknown
    try {
      parsedData = JSON.parse(jsonString)
    } catch (error) {
      return { success: false, error: "Ungültige JSON-Datei" }
    }

    const validation = validateSavegame(parsedData)
    if (!validation.success) {
      return { success: false, error: validation.error }
    }

    const savegame = validation.data

    // Schema-Version prüfen
    if (!isSupportedSchemaVersion(savegame.schemaVersion || 0)) {
      return {
        success: false,
        error: `Nicht unterstützte Schema-Version: ${savegame.schemaVersion}. Unterstützt wird Version 1.`
      }
    }

    onProgress?.("Daten werden wiederhergestellt...")

    // Erstelle Backup der aktuellen Daten (für mögliche Wiederherstellung)
    const currentData = await indexedDBStorage.getAllData()

    try {
      // Lösche alle bestehenden Daten
      onProgress?.("Alte Daten werden gelöscht...")
      await indexedDBStorage.clearAllData()

      // Stelle neue Daten wieder her
      onProgress?.("Neue Daten werden geschrieben...")

      // Schreibe alle Entitäten in IndexedDB
      for (const series of savegame.data.series || []) {
        await indexedDBStorage.saveSeries(series)
      }

      for (const character of savegame.data.characters || []) {
        await indexedDBStorage.saveCharacter(character)
      }

      for (const relationship of savegame.data.relationships || []) {
        await indexedDBStorage.saveRelationship(relationship)
      }

      for (const arc of savegame.data.characterArcs || []) {
        await indexedDBStorage.saveCharacterArc(arc)
      }

      for (const storyline of savegame.data.storylines || []) {
        await indexedDBStorage.saveStoryline(storyline)
      }

      for (const segment of savegame.data.segments || []) {
        await indexedDBStorage.saveSegment(segment)
      }

      for (const episode of savegame.data.episodes || []) {
        await indexedDBStorage.saveEvent(episode)
      }

      for (const season of savegame.data.seasons || []) {
        await indexedDBStorage.saveSeason(season)
      }

      // Stelle Assets wieder her
      if (savegame.assets) {
        onProgress?.("Assets werden wiederhergestellt...")
        await restoreAssets(savegame)
      }

      onProgress?.("Import abgeschlossen!")

      console.log("Savegame import completed successfully")
      return { success: true }

    } catch (error) {
      console.error("Import failed, attempting rollback...", error)

      // Rollback-Versuch: Stelle alte Daten wieder her
      try {
        onProgress?.("Fehler aufgetreten - Rollback wird durchgeführt...")
        await indexedDBStorage.clearAllData()

        // Stelle Backup wieder her
        for (const series of currentData.series) {
          await indexedDBStorage.saveSeries(series)
        }
        for (const character of currentData.characters) {
          await indexedDBStorage.saveCharacter(character)
        }
        // ... weitere Rollback-Operationen würden hier folgen

        return {
          success: false,
          error: "Import fehlgeschlagen. Daten wurden auf den vorherigen Stand zurückgesetzt."
        }
      } catch (rollbackError) {
        console.error("Rollback failed:", rollbackError)
        return {
          success: false,
          error: "Import fehlgeschlagen. Rollback nicht möglich. Daten könnten beschädigt sein."
        }
      }
    }

  } catch (error) {
    console.error("Savegame import failed:", error)
    return {
      success: false,
      error: "Unerwarteter Fehler beim Import. Bitte versuchen Sie es erneut."
    }
  }
}