// Korrigierte Starter-Datenbank mit funktionierender Save-Datei
import type { SeriesData } from './types'

// Lade die funktionierende Save-Datei als Starter-Daten
const fs = require('fs');
const path = require('path');

function loadStarterData(): SeriesData {
  try {
    // Lade die funktionierende Save-Datei
    const savePath = path.join(process.cwd(), 'Save Games', 'tv-series-manager-savegame-2026-01-11T07-29-29.json');
    const saveData = JSON.parse(fs.readFileSync(savePath, 'utf8'));

    console.log('✅ Starter-Daten erfolgreich geladen aus funktionierender Save-Datei');

    return saveData.data;
  } catch (error) {
    console.error('❌ Fehler beim Laden der Starter-Daten:', error);

    // Fallback: Leere Datenbank
    return {
      series: [],
      characters: [],
      relationships: [],
      characterArcs: [],
      storylines: [],
      scenes: [],
      episodes: [],
      seasons: [],
      locations: [],
      moods: [],
    };
  }
}

export const starterData: SeriesData = loadStarterData();