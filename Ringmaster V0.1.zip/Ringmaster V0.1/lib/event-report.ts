import type { Event, Segment, Character, Storyline, EventReport, CharacterAppearance, StorylineProgress, SeriesData } from "./types"

/**
 * Generiert einen provisorischen Bericht für eine Episode in Planung
 */
export function generateProvisionalReport(episodeId: string, data: SeriesData): EventReport {
  const episode = data.episodes.find(e => e.id === episodeId)
  if (!episode) {
    throw new Error(`Episode mit ID ${episodeId} nicht gefunden`)
  }

  // Alle Segmente der Episode sammeln (falls bereits welche zugewiesen)
  const episodeSegments = episode.sceneIds
    .map(sceneId => data.segments.find(s => s.id === sceneId))
    .filter((s): s is Segment => s !== undefined)

  const totalDuration = episodeSegments.reduce((sum, segment) => sum + segment.duration, 0)
  const characterAppearances = calculateCharacterAppearances(episodeSegments, data.characters)
  const storylineProgress = analyzeStorylineProgress(episodeSegments, data.storylines)
  const summary = generateProvisionalSummary(episode, episodeSegments, characterAppearances, storylineProgress)

  return {
    generatedAt: new Date(),
    totalDuration,
    segmentCount: episodeSegments.length,
    characterAppearances,
    storylineProgress,
    summary
  }
}

/**
 * Generiert einen automatischen Bericht für ein abgeschlossenes Event
 */
export function generateEventReport(episodeId: string, data: SeriesData): EventReport {
  const episode = data.episodes.find(e => e.id === episodeId)
  if (!episode) {
    throw new Error(`Episode mit ID ${episodeId} nicht gefunden`)
  }

  // Alle Segmente der Episode sammeln
  const episodeSegments = episode.sceneIds
    .map(sceneId => data.segments.find(s => s.id === sceneId))
    .filter((s): s is Segment => s !== undefined)

  const totalDuration = episodeSegments.reduce((sum, segment) => sum + segment.duration, 0)
  const characterAppearances = calculateCharacterAppearances(episodeSegments, data.characters)
  const storylineProgress = analyzeStorylineProgress(episodeSegments, data.storylines)
  const summary = generateEventSummary(episode, episodeSegments, characterAppearances, storylineProgress)

  return {
    generatedAt: new Date(),
    totalDuration,
    segmentCount: episodeSegments.length,
    characterAppearances,
    storylineProgress,
    summary
  }
}

/**
 * Berechnet die Character-Statistiken für alle Segmente
 */
function calculateCharacterAppearances(segments: Segment[], characters: Character[]): CharacterAppearance[] {
  const characterStats = new Map<string, CharacterAppearance>()

  segments.forEach(segment => {
    segment.characterIds.forEach(characterId => {
      const character = characters.find(c => c.id === characterId)
      if (!character) return

      const existing = characterStats.get(characterId)
      if (existing) {
        existing.appearanceCount++
        existing.totalScreenTime += segment.duration
        existing.segments.push(segment.id)
      } else {
        characterStats.set(characterId, {
          characterId,
          characterName: character.name,
          appearanceCount: 1,
          totalScreenTime: segment.duration,
          segments: [segment.id]
        })
      }
    })
  })

  // Sortiere nach Appearance Count (absteigend)
  return Array.from(characterStats.values()).sort((a, b) => b.appearanceCount - a.appearanceCount)
}

/**
 * Analysiert den Fortschritt der Storylines basierend auf den Segmenten
 */
function analyzeStorylineProgress(segments: Segment[], storylines: Storyline[]): StorylineProgress[] {
  const storylineStats = new Map<string, StorylineProgress>()

  segments.forEach(segment => {
    if (!segment.storylineIds || segment.storylineIds.length === 0) return

    segment.storylineIds.forEach(storylineId => {
      const storyline = storylines.find(s => s.id === storylineId)
      if (!storyline) return

      const existing = storylineStats.get(storylineId)
      if (existing) {
        existing.segmentCount++
      } else {
        storylineStats.set(storylineId, {
          storylineId: storyline.id,
          storylineTitle: storyline.title,
          storylineColor: storyline.color,
          segmentCount: 1,
          characterIds: segment.characterIds,
          status: "advanced"
        })
      }
    })
  })

  return Array.from(storylineStats.values())
}

/**
 * Bestimmt den Status der Storyline basierend auf ihrem aktuellen Status
 */
function determineStorylineStatus(storyline: Storyline): StorylineProgress["status"] {
  switch (storyline.status) {
    case "active":
      return "continued"
    case "completed":
      return "completed"
    case "paused":
      return "paused"
    default:
      return "advanced"
  }
}

/**
 * Generiert eine provisorische Zusammenfassung für eine Episode in Planung
 */
function generateProvisionalSummary(
  episode: Event, 
  segments: Segment[], 
  characterAppearances: CharacterAppearance[], 
  storylineProgress: StorylineProgress[]
): string {
  const eventType = episode.eventType
  const eventNumber = episode.eventNumber
  const title = episode.title
  
  // Top-Characters
  const topCharacters = characterAppearances.slice(0, 3)
    .map(ca => ca.characterName)
    .join(", ")

  // Storyline-Info
  const storylineCount = storylineProgress.length
  const storylineNames = storylineProgress
    .slice(0, 2)
    .map(sp => sp.storylineTitle)
    .join(", ")

  // Zusammenfassung bauen
  let summary = `PROVISORISCHER BERICHT - ${eventType} #${eventNumber}: ${title}\n\n`
  summary += `Status: In Planung\n\n`
  
  if (segments.length === 0) {
    summary += `Noch keine Segmente zugewiesen.\n\n`
  } else {
    summary += `Aktuell ${segments.length} Segment${segments.length > 1 ? 'e' : ''} mit einer Gesamtdauer von ${segments.reduce((sum, s) => sum + s.duration, 0)} Minuten geplant.\n\n`
    
    if (topCharacters) {
      summary += `Geplante Characters: ${topCharacters}\n\n`
    }

    if (storylineCount > 0) {
      summary += `Storyline-Fokus: ${storylineCount} Storyline${storylineCount > 1 ? 's' : ''}`
      if (storylineNames) {
        summary += `, darunter ${storylineNames}`
      }
      summary += ".\n\n"
    }

    // Segmente im Detail auflisten
    summary += `SEGMENTE IM DETAIL:\n`
    summary += `-------------------\n`
    segments.forEach((segment, index) => {
      summary += `${index + 1}. "${segment.title}" (${segment.duration} Min.)\n`
      if (segment.description && segment.description.trim()) {
        summary += `   ${segment.description}\n`
      }
      summary += `\n`
    })
  }

  summary += `---\nDieser Bericht ist provisorisch und basiert auf der aktuellen Planung. Er kann für ChatGPT-Anfragen verwendet werden, um eine erste Einschätzung der Show zu erhalten.`

  return summary
}

/**
 * Generiert eine automatische Zusammenfassung des Events
 */
function generateEventSummary(
  episode: Event, 
  segments: Segment[], 
  characterAppearances: CharacterAppearance[], 
  storylineProgress: StorylineProgress[]
): string {
  const eventType = episode.eventType
  const eventNumber = episode.eventNumber
  const title = episode.title
  
  // Top-Characters
  const topCharacters = characterAppearances.slice(0, 3)
    .map(ca => ca.characterName)
    .join(", ")

  // Storyline-Info
  const storylineCount = storylineProgress.length
  const storylineNames = storylineProgress
    .slice(0, 2)
    .map(sp => sp.storylineTitle)
    .join(", ")

  // Zusammenfassung bauen
  let summary = `${eventType} #${eventNumber}: ${title}\n\n`
  summary += `Dieses Event featured ${segments.length} Segmente mit einer Gesamtdauer von ${segments.reduce((sum, s) => sum + s.duration, 0)} Minuten.\n\n`
  
  if (topCharacters) {
    summary += `Top-Performers: ${topCharacters}\n\n`
  }

  if (storylineCount > 0) {
    summary += `Storyline-Fortschritt: ${storylineCount} Storyline${storylineCount > 1 ? 's' : ''} vorangebracht`
    if (storylineNames) {
      summary += `, darunter ${storylineNames}`
    }
    summary += ".\n\n"
  }

  // Highlight-Informationen
  if (segments.length > 0) {
    const longestSegment = segments.reduce((max, segment) => 
      segment.duration > max.duration ? segment : max, segments[0])
    
    summary += `Längstes Segment: "${longestSegment.title}" (${longestSegment.duration} Minuten)\n`
  }

  // Segmente im Detail auflisten
  if (segments.length > 0) {
    summary += `\nSEGMENTE IM DETAIL:\n`
    summary += `-------------------\n`
    segments.forEach((segment, index) => {
      summary += `${index + 1}. "${segment.title}" (${segment.duration} Min.)\n`
      if (segment.description && segment.description.trim()) {
        summary += `   ${segment.description}\n`
      }
      summary += `\n`
    })
  }

  return summary
}

/**
 * Prüft ob ein Event bereits einen Bericht hat
 */
export function hasEventReport(episode: Event): boolean {
  return !!episode.completionReport
}

/**
 * Aktualisiert einen bestehenden Bericht oder erstellt einen neuen
 */
export function updateEventReport(episodeId: string, data: SeriesData): EventReport {
  const newReport = generateEventReport(episodeId, data)
  return newReport
}
