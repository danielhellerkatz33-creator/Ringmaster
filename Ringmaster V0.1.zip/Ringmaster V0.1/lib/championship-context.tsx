"use client"

import { createContext, useContext, useCallback } from "react"
import type { CharacterArc, ChampionshipReign } from "./types"
import { useSeries } from "./series-context"

interface ChampionshipContextType {
  // Championship Reign operations
  addChampionshipReign: (championshipId: string, reign: Omit<ChampionshipReign, "id">) => void
  updateChampionshipReign: (championshipId: string, reign: ChampionshipReign) => void
  deleteChampionshipReign: (championshipId: string, reignId: string) => void
  
  // Helper functions
  getCurrentChampions: (championshipId: string) => string[]
  getChampionshipHistory: (championshipId: string) => ChampionshipReign[]
  transferChampionship: (championshipId: string, newChampionIds: string[], dateWon?: Date) => void
}

const ChampionshipContext = createContext<ChampionshipContextType | null>(null)

export function useChampionship() {
  const context = useContext(ChampionshipContext)
  if (!context) {
    throw new Error("useChampionship must be used within a ChampionshipProvider")
  }
  return context
}

export function ChampionshipProvider({ children }: { children: React.ReactNode }) {
  const { data, updateCharacterArc, addChampionshipReign: seriesAddReign, updateChampionshipReign: seriesUpdateReign, deleteChampionshipReign: seriesDeleteReign } = useSeries()

  const addChampionshipReign = useCallback((championshipId: string, reign: Omit<ChampionshipReign, "id">) => {
    seriesAddReign(championshipId, reign)
  }, [seriesAddReign])

  const updateChampionshipReign = useCallback((championshipId: string, reign: ChampionshipReign) => {
    seriesUpdateReign(championshipId, reign)
  }, [seriesUpdateReign])

  const deleteChampionshipReign = useCallback((championshipId: string, reignId: string) => {
    seriesDeleteReign(championshipId, reignId)
  }, [seriesDeleteReign])

  const getCurrentChampions = useCallback((championshipId: string) => {
    const championship = data.characterArcs.find(arc => arc.id === championshipId)
    return championship?.currentChampionIds || []
  }, [data])

  const getChampionshipHistory = useCallback((championshipId: string) => {
    const championship = data.characterArcs.find(arc => arc.id === championshipId)
    return championship?.championHistory || []
  }, [data])

  const transferChampionship = useCallback((championshipId: string, newChampionIds: string[], dateWon?: Date) => {
    const championship = data.characterArcs.find(arc => arc.id === championshipId)
    if (!championship) return

    const now = dateWon || new Date()
    
    // End current reign if exists
    const currentReign = championship.championHistory.find(r => !r.dateLost)
    const updatedHistory = currentReign 
      ? championship.championHistory.map(r => 
          r.id === currentReign.id 
            ? { ...r, dateLost: now }
            : r
        )
      : championship.championHistory

    // Add new reign
    const newReign: ChampionshipReign = {
      id: Math.random().toString(36).substr(2, 9),
      championIds: newChampionIds,
      dateWon: now,
      defenses: 0,
    }

    updateCharacterArc({
      ...championship,
      championHistory: [...updatedHistory, newReign],
      currentChampionIds: newChampionIds,
      updatedAt: new Date(),
    })
  }, [data, updateCharacterArc])

  const value: ChampionshipContextType = {
    addChampionshipReign,
    updateChampionshipReign,
    deleteChampionshipReign,
    getCurrentChampions,
    getChampionshipHistory,
    transferChampionship,
  }

  return (
    <ChampionshipContext.Provider value={value}>
      {children}
    </ChampionshipContext.Provider>
  )
}

