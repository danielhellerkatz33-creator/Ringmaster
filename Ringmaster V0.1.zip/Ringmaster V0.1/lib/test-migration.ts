// Test-Script für die IndexedDB-Migration
// Dies kann in der Browser-Konsole ausgeführt werden

import { initializeStorage, createBackup, restoreFromBackup } from './migration'
import { indexedDBStorage } from './indexeddb-storage'

// Test-Funktionen für die Browser-Konsole
declare global {
  interface Window {
    testMigration: () => Promise<void>
    testBackup: () => Promise<void>
    testIndexedDB: () => Promise<void>
  }
}

window.testMigration = async () => {
  console.log('Testing IndexedDB Migration...')
  try {
    const success = await initializeStorage()
    console.log('Migration result:', success ? 'SUCCESS' : 'FAILED')
  } catch (error) {
    console.error('Migration test failed:', error)
  }
}

window.testBackup = async () => {
  console.log('Testing Backup functionality...')
  try {
    const backup = await createBackup()
    console.log('Backup created:', backup.length, 'characters')
    console.log('Backup sample:', backup.substring(0, 200) + '...')

    // Test restore
    const restoreSuccess = await restoreFromBackup(backup)
    console.log('Restore result:', restoreSuccess ? 'SUCCESS' : 'FAILED')
  } catch (error) {
    console.error('Backup test failed:', error)
  }
}

window.testIndexedDB = async () => {
  console.log('Testing IndexedDB operations...')
  try {
    await indexedDBStorage.init()
    console.log('IndexedDB initialized')

    const data = await indexedDBStorage.getAllData()
    console.log('Current data:', data)

    // Test blob operations
    const testBlob = new Blob(['Hello World'], { type: 'text/plain' })
    await indexedDBStorage.saveBlob('test-blob', testBlob)
    const retrievedBlob = await indexedDBStorage.getBlob('test-blob')
    console.log('Blob test:', retrievedBlob ? 'SUCCESS' : 'FAILED')

  } catch (error) {
    console.error('IndexedDB test failed:', error)
  }
}

export {} // Make this a module