import { indexedDBStorage, IndexedDBStorage } from "./indexeddb-storage"
import type { SeriesData } from "./types"
import { migrateSegmentsToMultipleStorylines } from "./migrations/segment-storyline-migration"

const STORAGE_KEY = "ringmaster-manager-data"

/**
 * Migriert Daten von localStorage zu IndexedDB
 * Sollte nur einmal beim ersten Start mit IndexedDB aufgerufen werden
 */
export async function migrateFromLocalStorage(): Promise<boolean> {
  try {
    // Prüfen ob bereits migriert wurde
    const migrationFlag = localStorage.getItem("ringmaster-manager-migrated")
    if (migrationFlag === "true") {
      console.log("Migration already completed")
      return true
    }

    const stored = localStorage.getItem(STORAGE_KEY)
    if (!stored) {
      console.log("No localStorage data found, skipping migration")
      localStorage.setItem("ringmaster-manager-migrated", "true")
      return true
    }

    console.log("Starting migration from localStorage to IndexedDB...")

    // Validiere JSON vor der Migration
    let data: SeriesData
    try {
      data = JSON.parse(stored)
    } catch (error) {
      console.error("Invalid JSON in localStorage, skipping migration:", error)
      localStorage.setItem("ringmaster-manager-migration-error", "Invalid JSON data")
      return false
    }

    // Prüfe grundlegende Datenstruktur
    if (!data || typeof data !== 'object') {
      console.error("Invalid data structure in localStorage")
      localStorage.setItem("ringmaster-manager-migration-error", "Invalid data structure")
      return false
    }

    // Storyline-Migration durchführen
    data = migrateSegmentsToMultipleStorylines(data)

    // Erstelle Backup der Originaldaten
    localStorage.setItem("ringmaster-manager-pre-migration-backup", stored)
    localStorage.setItem("ringmaster-manager-migration-started", new Date().toISOString())

    // Serielle Migration um Transaktionen nicht zu überlasten
    let migratedItems = 0
    const totalItems = (data.characters?.length || 0) +
                      (data.relationships?.length || 0) +
                      (data.characterArcs?.length || 0) +
                      (data.storylines?.length || 0) +
                      (data.segments?.length || 0) +
                      (data.episodes?.length || 0) +
                      (data.seasons?.length || 0) +
                      (data.locations?.length || 0) +
                      (data.moods?.length || 0) + (data.series?.length || 0)

    try {
      // Parallele Migration für bessere Performance
      const migrationPromises: Promise<void>[] = []

      if (data.series && data.series.length > 0) {
        for (const series of data.series) {
          migrationPromises.push(indexedDBStorage.saveSeries(series))
          migratedItems++
        }
      }

      for (const character of (data.characters || [])) {
        migrationPromises.push(indexedDBStorage.saveCharacter(character))
        migratedItems++
      }

      for (const relationship of (data.relationships || [])) {
        migrationPromises.push(indexedDBStorage.saveRelationship(relationship))
        migratedItems++
      }

      for (const arc of (data.characterArcs || [])) {
        migrationPromises.push(indexedDBStorage.saveCharacterArc(arc))
        migratedItems++
      }

      for (const storyline of (data.storylines || [])) {
        migrationPromises.push(indexedDBStorage.saveStoryline(storyline))
        migratedItems++
      }

      for (const segment of (data.segments || [])) {
        migrationPromises.push(indexedDBStorage.saveSegment(segment))
        migratedItems++
      }

      for (const episode of (data.episodes || [])) {
        migrationPromises.push(indexedDBStorage.saveEvent(episode))
        migratedItems++
      }

      for (const season of (data.seasons || [])) {
        migrationPromises.push(indexedDBStorage.saveSeason(season))
        migratedItems++
      }

      for (const location of (data.locations || [])) {
        migrationPromises.push(indexedDBStorage.saveLocation(location))
        migratedItems++
      }

      for (const mood of (data.moods || [])) {
        migrationPromises.push(indexedDBStorage.saveMood(mood))
        migratedItems++
      }

      // Alle Migrationen parallel ausführen
      await Promise.all(migrationPromises)
      console.log(`Migration completed successfully - ${migratedItems} items migrated`)

      // Migration erfolgreich abgeschlossen
      localStorage.setItem("ringmaster-manager-migrated", "true")
      localStorage.setItem("ringmaster-manager-migration-completed", new Date().toISOString())
      localStorage.removeItem("ringmaster-manager-migration-started")

      console.log(`Migration completed successfully - ${migratedItems} items migrated`)
      return true

    } catch (migrationError) {
      console.error("Migration failed during data transfer:", migrationError)

      // Versuche Rollback - IndexedDB leeren
      try {
        await indexedDBStorage.clearAllData()
        console.log("Rollback completed - IndexedDB cleared")
      } catch (rollbackError) {
        console.error("Rollback failed:", rollbackError)
      }

      localStorage.setItem("ringmaster-manager-migration-error", migrationError instanceof Error ? migrationError.message : "Unknown error")
      return false
    }

  } catch (error) {
    console.error("Migration failed:", error)
    return false
  }
}

/**
 * Erstellt ein Backup der aktuellen IndexedDB-Daten als JSON-String
 */
export async function createBackup(): Promise<string> {
  const data = await indexedDBStorage.getAllData()
  return JSON.stringify(data, null, 2)
}

/**
 * Stellt Daten aus einem Backup wieder her
 */
export async function restoreFromBackup(backupData: string): Promise<boolean> {
  try {
    const data: SeriesData = JSON.parse(backupData)

    // Erst alle alten Daten löschen
    await indexedDBStorage.clearAllData()

    // Dann neue Daten einfügen
    if (data.series && data.series.length > 0) {
      for (const series of data.series) {
        await indexedDBStorage.saveSeries(series)
      }
    }

    for (const character of data.characters) {
      await indexedDBStorage.saveCharacter(character)
    }

    for (const relationship of data.relationships) {
      await indexedDBStorage.saveRelationship(relationship)
    }

    for (const arc of data.characterArcs) {
      await indexedDBStorage.saveCharacterArc(arc)
    }

    for (const storyline of data.storylines) {
      await indexedDBStorage.saveStoryline(storyline)
    }

    for (const segment of data.segments) {
      await indexedDBStorage.saveSegment(segment)
    }

    for (const event of data.episodes) {
      await indexedDBStorage.saveEvent(event)
    }

    for (const season of data.seasons) {
      await indexedDBStorage.saveSeason(season)
    }

    for (const location of data.locations || []) {
      await indexedDBStorage.saveLocation(location)
    }

    for (const mood of data.moods || []) {
      await indexedDBStorage.saveMood(mood)
    }

    console.log("Backup restored successfully")
    return true

  } catch (error) {
    console.error("Backup restore failed:", error)
    return false
  }
}

/**
 * Initialisiert locations und moods aus bestehenden Scenes
 * Diese Funktion sollte nach der Migration aufgerufen werden
 */
export async function initializeLocationsAndMoodsFromScenes(): Promise<void> {
  try {
    console.log("Initializing locations and moods from existing scenes...")

    // Hole alle Segmente (früher Scenes)
    const scenes = await indexedDBStorage.getSegments()
    if (scenes.length === 0) {
      console.log("No scenes found, skipping locations/moods initialization")
      return
    }

    // Sammle einzigartige Locations
    const locationNames = new Set<string>()
    scenes.forEach(scene => {
      if (scene.location && scene.location.trim()) {
        locationNames.add(scene.location.trim())
      }
    })

    // Sammle einzigartige Moods
    const moodNames = new Set<string>()
    scenes.forEach(scene => {
      if (scene.mood && scene.mood.trim()) {
        moodNames.add(scene.mood.trim())
      }
    })

    // Hole bestehende Locations und Moods
    const existingLocations = await indexedDBStorage.getLocations()
    const existingMoods = await indexedDBStorage.getMoods()

    const existingLocationNames = new Set(
      existingLocations.map(loc => loc.name.toLowerCase().trim())
    )
    const existingMoodNames = new Set(
      existingMoods.map(mood => mood.name.toLowerCase().trim())
    )

    // Erstelle neue Locations
    const newLocations = Array.from(locationNames)
      .filter(name => !existingLocationNames.has(name.toLowerCase()))
      .map(name => ({
        id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        name: name,
        description: '',
        isActive: true,
        createdAt: new Date(),
        updatedAt: new Date(),
      }))

    // Erstelle neue Moods
    const newMoods = Array.from(moodNames)
      .filter(name => !existingMoodNames.has(name.toLowerCase()))
      .map(name => ({
        id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        name: name,
        description: '',
        isActive: true,
        createdAt: new Date(),
        updatedAt: new Date(),
      }))

    // Speichere neue Locations und Moods
    await Promise.all([
      ...newLocations.map(location => indexedDBStorage.saveLocation(location)),
      ...newMoods.map(mood => indexedDBStorage.saveMood(mood))
    ])

    console.log(`Initialized ${newLocations.length} locations and ${newMoods.length} moods from existing scenes`)

  } catch (error) {
    console.warn("Failed to initialize locations and moods from scenes:", error)
  }
}

/**
 * Prüft ob IndexedDB verfügbar ist und initialisiert die Migration
 */
export async function initializeStorage(): Promise<boolean> {
  if (!IndexedDBStorage.isSupported()) {
    console.warn("IndexedDB not supported, falling back to localStorage")
    return false
  }

  try {
    await indexedDBStorage.init()
    const migrated = await migrateFromLocalStorage()

    // Nach der Migration locations und moods aus Scenes initialisieren
    await initializeLocationsAndMoodsFromScenes()

    return migrated
  } catch (error) {
    console.error("Failed to initialize IndexedDB:", error)
    return false
  }
}