import type { 
  Event, 
  Segment, 
  Character, 
  Storyline, 
  StateOfTheArtReport, 
  StorylineReport, 
  EventAssignment, 
  EventTimeAllocation,
  SeriesData,
  Show 
} from "./types"

/**
 * Generiert einen umfassenden "State of The Art" Bericht für alle aktiven Storylines
 */
export function generateStateOfTheArtReport(data: SeriesData): StateOfTheArtReport {
  // Aktive Storylines filtern
  const activeStorylines = data.storylines.filter(s => s.status === "active")
  
  // Alle Segmente für aktive Storylines sammeln
  const storylineSegments = activeStorylines.flatMap(storyline => {
    const segments = data.segments.filter(segment => 
      segment.storylineIds?.includes(storyline.id)
    )
    return { storyline, segments }
  })

  // Geplante Events filtern und nach Datum sortieren (ältestes zuerst)
  const plannedEvents = data.episodes
    .filter(event => event.status === "planning" || event.status === "writing")
    .sort((a, b) => {
      // Wenn beide Events airDate haben, nach Datum sortieren
      if (a.airDate && b.airDate) {
        return new Date(a.airDate).getTime() - new Date(b.airDate).getTime()
      }
      // Wenn nur eines airDate hat, das ohne Datum ans Ende
      if (a.airDate && !b.airDate) return -1
      if (!a.airDate && b.airDate) return 1
      // Wenn keins airDate hat, nach Event-Nummer sortieren
      return a.eventNumber - b.eventNumber
    })

  // Storyline-Berichte erstellen
  const storylineReports: StorylineReport[] = activeStorylines.map(storyline => {
    const segments = data.segments.filter(segment => 
      segment.storylineIds?.includes(storyline.id)
    )
    
    const characters = data.characters.filter(character => 
      storyline.characterIds.includes(character.id)
    )

    // Event-Zuordnungen für diese Storyline
    const eventAssignments: EventAssignment[] = []
    segments.forEach(segment => {
      const event = data.episodes.find(e => e.sceneIds.includes(segment.id))
      if (event) {
        const existingAssignment = eventAssignments.find(a => a.eventId === event.id)
        if (existingAssignment) {
          existingAssignment.segmentIds.push(segment.id)
          existingAssignment.totalBookedTime += segment.duration
        } else {
          eventAssignments.push({
            eventId: event.id,
            eventTitle: event.title,
            eventType: event.eventType,
            eventNumber: event.eventNumber,
            segmentIds: [segment.id],
            totalBookedTime: segment.duration
          })
        }
      }
    })

    // Verfügbare Events (geplante Events ohne diese Storyline und nach letztem Segment-Datum)
    const availableEvents = plannedEvents.filter(event => {
      // Event darf bereits zugewiesen sein
      if (eventAssignments.some(assignment => assignment.eventId === event.id)) {
        return false
      }

      // Wenn die Storyline Segmente hat, prüfe das Datum des letzten Segments
      if (segments.length > 0) {
        // Finde das Event mit dem spätesten Datum für diese Storyline
        const latestSegmentEvent = segments.reduce((latest, segment) => {
          const segmentEvent = data.episodes.find(e => e.sceneIds.includes(segment.id))
          if (!segmentEvent || !segmentEvent.airDate) return latest
          
          if (!latest || !latest.airDate) return segmentEvent
          return new Date(segmentEvent.airDate) > new Date(latest.airDate) ? segmentEvent : latest
        }, null as Event | null)

        // Wenn das letzte Segment-Event-Datum bekannt ist, zeige nur Events danach
        if (latestSegmentEvent && latestSegmentEvent.airDate && event.airDate) {
          return new Date(event.airDate) > new Date(latestSegmentEvent.airDate)
        }
      }

      // Wenn keine Segmente oder keine Datum-Informationen verfügbar sind, zeige alle Events
      return true
    })

    return {
      storyline,
      segments,
      totalSegmentTime: segments.reduce((sum, segment) => sum + segment.duration, 0),
      eventAssignments,
      availableEvents,
      characters
    }
  })

  // Event-Zeit-Allokation berechnen
  const eventTimeAllocations: EventTimeAllocation[] = plannedEvents.map(event => {
    const eventSegments = event.sceneIds
      .map(sceneId => data.segments.find(s => s.id === sceneId))
      .filter((s): s is Segment => s !== undefined)

    const bookedDuration = eventSegments.reduce((sum, segment) => sum + segment.duration, 0)
    const assignedStorylines = eventSegments
      .flatMap(segment => segment.storylineIds || [])
      .filter((storylineId, index, arr) => arr.indexOf(storylineId) === index) // Entfernt Duplikate

    // Geschätzte Gesamtdauer basierend auf Event-Typ und Titel
    const estimatedTotalDuration = getEstimatedEventDuration(event.eventType, event.title, data.shows)

    return {
      event,
      totalDuration: estimatedTotalDuration,
      bookedDuration,
      availableDuration: Math.max(0, estimatedTotalDuration - bookedDuration),
      assignedStorylines
    }
  })

  // Zusammenfassung generieren
  const summary = generateStateOfTheArtSummary(
    activeStorylines, 
    storylineReports, 
    eventTimeAllocations, 
    data
  )

  return {
    generatedAt: new Date(),
    totalActiveStorylines: activeStorylines.length,
    totalSegments: storylineReports.reduce((sum, report) => sum + report.segments.length, 0),
    totalBookedTime: storylineReports.reduce((sum, report) => sum + report.totalSegmentTime, 0),
    storylines: storylineReports,
    events: eventTimeAllocations,
    summary
  }
}

/**
 * Schätzt die Gesamtdauer eines Events basierend auf seinem Typ und Titel
 */
function getEstimatedEventDuration(eventType: string, eventTitle: string, shows?: Show[]): number {
  // Zuerst auf Titel prüfen (spezifische Events)
  if (eventTitle.toLowerCase().includes("nwa main event")) {
    return 60 // 1 Stunde für NWA Main Event
  }
  
  // Prüfen ob es eine Show mit passendem Titel und custom Dauer gibt
  if (shows) {
    const matchingShow = shows.find(show => 
      eventTitle.toLowerCase().includes(show.name.toLowerCase()) ||
      show.name.toLowerCase().includes(eventTitle.toLowerCase())
    )
    if (matchingShow && matchingShow.defaultDuration) {
      return matchingShow.defaultDuration
    }
  }
  
  // Dann auf eventType prüfen
  switch (eventType) {
    case "Weekly TV":
      return 120 // 2 Stunden
    case "PPV":
      return 180 // 3 Stunden
    case "TV-Special":
      return 120 // 2 Stunden
    default:
      return 120 // Standard: 2 Stunden
  }
}

/**
 * Generiert eine formatierte Zusammenfassung für den Bericht
 */
function generateStateOfTheArtSummary(
  activeStorylines: Storyline[],
  storylineReports: StorylineReport[],
  eventTimeAllocations: EventTimeAllocation[],
  data: SeriesData
): string {
  let summary = "STATE OF THE ART STORYLINE REPORT\n"
  summary += `Generated: ${new Date().toLocaleString('de-DE')}\n\n`

  // Übersicht
  summary += "ÜBERSICHT:\n"
  summary += `- Aktive Storylines: ${activeStorylines.length}\n`
  summary += `- Gesamte Segmente: ${storylineReports.reduce((sum, report) => sum + report.segments.length, 0)}\n`
  summary += `- Gebuchte Zeit: ${storylineReports.reduce((sum, report) => sum + report.totalSegmentTime, 0)} Minuten\n`
  
  const eventsWithAvailableTime = eventTimeAllocations.filter(eta => eta.availableDuration > 0)
  summary += `- Events mit verfügbarer Zeit: ${eventsWithAvailableTime.length}\n\n`

  // Storyline-Details
  summary += "STORYLINE-DETAILS:\n"
  summary += "==================\n\n"
  
  storylineReports.forEach((report, index) => {
    summary += `${index + 1}. Storyline: "${report.storyline.title}" (${report.storyline.type === 'main' ? 'Main Story' : 'Side Story'})\n`
    summary += `   Status: ${report.storyline.status === 'active' ? 'Aktiv' : report.storyline.status}\n`
    summary += `   Charaktere: ${report.characters.map(c => c.name).join(', ')}\n`
    summary += `   Segmente: ${report.segments.length} (${report.totalSegmentTime} Minuten)\n`
    
    if (report.eventAssignments.length > 0) {
      summary += `   Event-Zuordnungen:\n`
      report.eventAssignments.forEach(assignment => {
        summary += `     - ${assignment.eventType} #${assignment.eventNumber}: ${assignment.eventTitle} (${assignment.totalBookedTime} Minuten)\n`
      })
    }
    
    if (report.availableEvents.length > 0) {
      summary += `   Verfügbare Events für Fortsetzung:\n`
      report.availableEvents.forEach(event => {
        const timeAllocation = eventTimeAllocations.find(eta => eta.event.id === event.id)
        summary += `     - ${event.eventType} #${event.eventNumber}: ${event.title} (${timeAllocation?.availableDuration || 0} Minuten verfügbar)\n`
      })
    }
    
    if (report.segments.length > 0) {
      summary += `   Segmente im Detail:\n`
      report.segments.forEach((segment, segIndex) => {
        summary += `     ${segIndex + 1}. "${segment.title}" (${segment.duration} Min.)\n`
        if (segment.description && segment.description.trim()) {
          summary += `        ${segment.description}\n`
        }
      })
    }
    
    summary += "\n"
  })

  // Event-Zeit-Allokation
  summary += "EVENT-ZEIT-ALLOKATION:\n"
  summary += "=====================\n\n"
  
  eventTimeAllocations.forEach((allocation, index) => {
    summary += `${index + 1}. Event: ${allocation.event.eventType} #${allocation.event.eventNumber}: ${allocation.event.title}\n`
    summary += `   Gesamtdauer: ${allocation.bookedDuration}/${allocation.totalDuration} Minuten\n`
    summary += `   Verfügbare Zeit: ${allocation.availableDuration} Minuten\n`
    summary += `   Zugewiesene Storylines: ${allocation.assignedStorylines.length > 0 ? allocation.assignedStorylines.map(id => {
      const storyline = activeStorylines.find(s => s.id === id)
      return storyline ? storyline.title : 'Unbekannt'
    }).join(', ') : 'Keine'}\n`
    
    if (allocation.availableDuration > 0) {
      summary += `   EMPFEHLUNG: ${allocation.availableDuration} Minuten für neue Segmente verfügbar\n`
    }
    
    summary += "\n"
  })

  // Empfehlungen
  summary += "EMPFEHLUNGEN:\n"
  summary += "=============\n\n"
  
  // Storylines die mehr Segmente brauchen
  const storylinesNeedingSegments = storylineReports.filter(report => report.segments.length < 3)
  if (storylinesNeedingSegments.length > 0) {
    summary += "Storylines die mehr Segmente brauchen:\n"
    storylinesNeedingSegments.forEach(report => {
      summary += `- "${report.storyline.title}" (aktuell ${report.segments.length} Segmente)\n`
    })
    summary += "\n"
  }

  // Events mit verfügbarer Zeit
  if (eventsWithAvailableTime.length > 0) {
    summary += "Events mit verfügbarer Zeit:\n"
    eventsWithAvailableTime.forEach(allocation => {
      summary += `- ${allocation.event.eventType} #${allocation.event.eventNumber}: ${allocation.event.title} (${allocation.availableDuration} Minuten)\n`
    })
    summary += "\n"
  }

  summary += "---\n"
  summary += "Dieser Bericht wurde automatisch generiert und kann für ChatGPT-Anfragen verwendet werden, um Storylines extern fortzusetzen.\n"

  return summary
}

/**
 * Exportiert den Bericht als formatierten Text
 */
export function exportReportAsText(report: StateOfTheArtReport): string {
  return report.summary
}

/**
 * Exportiert den Bericht als JSON
 */
export function exportReportAsJSON(report: StateOfTheArtReport): string {
  return JSON.stringify(report, null, 2)
}
