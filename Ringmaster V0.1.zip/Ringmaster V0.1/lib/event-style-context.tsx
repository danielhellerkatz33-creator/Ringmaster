"use client"

import { createContext, useContext, useState, ReactNode } from "react"

type EventStyle = "style1" | "style2"

interface EventStyleContextType {
  eventStyle: EventStyle
  setEventStyle: (style: EventStyle) => void
}

const EventStyleContext = createContext<EventStyleContextType | undefined>(undefined)

export function EventStyleProvider({ children }: { children: ReactNode }) {
  const [eventStyle, setEventStyle] = useState<EventStyle>("style2")

  return (
    <EventStyleContext.Provider value={{ eventStyle, setEventStyle }}>
      {children}
    </EventStyleContext.Provider>
  )
}

export function useEventStyle() {
  const context = useContext(EventStyleContext)
  if (context === undefined) {
    throw new Error("useEventStyle must be used within an EventStyleProvider")
  }
  return context
}
