"use client"

import { createContext, useContext, useEffect, useState, useCallback, useRef, type ReactNode } from "react"
import type {
  Character,
  Relationship,
  Storyline,
  Segment,
  Event,
  Season,
  Series,
  CharacterArc,
  ChampionshipReign,
  Mood,
  SeriesData,
  Promotion,
  Arena,
  Show,
  Location,
} from "./types"
import { indexedDBStorage } from "./indexeddb-storage"
import { DatabaseMigrator } from "./indexeddb-storage"
import { initializeStorage } from "./migration"
import { runManualStorylineMigration } from "./migrations/manual-storyline-migration"
import { runForcedStorylineMigration } from "./migrations/forced-storyline-migration"

const defaultData: SeriesData = {
  series: [],
  characters: [],
  relationships: [],
  characterArcs: [],
  storylines: [],
  segments: [],
  episodes: [],
  seasons: [],
  locations: [],
  moods: [],
  // Game Center Data
  promotions: [],
  arenas: [],
  shows: [],
}

interface SeriesContextType {
  data: SeriesData
  isLoading: boolean
  storageReady: boolean

  // Series
  createSeries: (series: Omit<Series, "id" | "createdAt">) => void
  updateSeries: (series: Series) => void
  uploadCoverImage: (file: File) => Promise<string>
  getCoverImageUrl: (series: Series) => Promise<string | null>

  // Characters
  addCharacter: (character: Omit<Character, "id" | "createdAt" | "updatedAt">) => void
  updateCharacter: (character: Character) => void
  deleteCharacter: (id: string) => void
  uploadAvatar: (characterId: string, file: File) => Promise<string>
  getAvatarUrl: (character: Character) => Promise<string | null>

  // Relationships
  addRelationship: (relationship: Omit<Relationship, "id">) => void
  updateRelationship: (relationship: Relationship) => void
  deleteRelationship: (id: string) => void

  // Character Arcs
  addCharacterArc: (arc: Omit<CharacterArc, "id">) => void
  updateCharacterArc: (arc: CharacterArc) => void
  deleteCharacterArc: (id: string) => void

  // Championship Reign operations
  addChampionshipReign: (championshipId: string, reign: Omit<ChampionshipReign, "id">) => void
  updateChampionshipReign: (championshipId: string, reign: ChampionshipReign) => void
  deleteChampionshipReign: (championshipId: string, reignId: string) => void

  // Storylines
  addStoryline: (storyline: Omit<Storyline, "id" | "createdAt">) => void
  updateStoryline: (storyline: Storyline) => void
  deleteStoryline: (id: string) => void

  // Segments
  addScene: (scene: Omit<Segment, "id">) => void
  updateScene: (scene: Segment) => void
  deleteScene: (id: string) => void

  // Events
  addEpisode: (episode: Omit<Event, "id">) => void
  updateEpisode: (episode: Event) => void
  deleteEpisode: (id: string) => void
  addSceneToEpisode: (episodeId: string, sceneId: string) => void
  removeSceneFromEpisode: (episodeId: string, sceneId: string) => void
  sortEpisodeScenesByTimeOfDay: (episodeId: string) => void

  // Locations
  addLocation: (location: Omit<Location, "id" | "createdAt" | "updatedAt">) => void
  updateLocation: (location: Location) => void
  deleteLocation: (id: string) => void
  getActiveLocations: () => Location[]

  // Moods
  addMood: (mood: Omit<Mood, "id" | "createdAt" | "updatedAt">) => void
  updateMood: (mood: Mood) => void
  deleteMood: (id: string) => void
  getActiveMoods: () => Mood[]

  // Seasons
  addSeason: (season: Omit<Season, "id">) => void
  updateSeason: (season: Season) => void

  // Game Center Operations
  addPromotion: (promotion: Omit<Promotion, "id" | "createdAt" | "updatedAt">) => void
  updatePromotion: (promotion: Promotion) => void
  deletePromotion: (id: string) => void
  addArena: (arena: Omit<Arena, "id" | "createdAt" | "updatedAt">) => void
  updateArena: (arena: Arena) => void
  deleteArena: (id: string) => void
  addShow: (show: Omit<Show, "id" | "createdAt" | "updatedAt">) => void
  updateShow: (show: Show) => void
  deleteShow: (id: string) => void
}

const SeriesContext = createContext<SeriesContextType | null>(null)

function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
}

export function SeriesProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<SeriesData>(defaultData)
  const [isLoading, setIsLoading] = useState(true)
  const [storageReady, setStorageReady] = useState(false)
  const [initialized, setInitialized] = useState(false)

  // Manuelle Storyline-Migration global verfügbar machen
  useEffect(() => {
    if (typeof window !== 'undefined') {
      (window as any).runManualStorylineMigration = runManualStorylineMigration
      (window as any).runForcedStorylineMigration = runForcedStorylineMigration
    }
  }, [])

  // Initialize storage and load data on mount (nur einmal, idempotent)
  useEffect(() => {
    if (initialized) return // Verhindere doppelte Initialisierung (React Strict Mode)

    const initStorage = async () => {
      setInitialized(true)
      try {
        const success = await initializeStorage()
        setStorageReady(success)

        if (success) {
          // Load data from IndexedDB first
          const storedData = await indexedDBStorage.getAllData()
          console.log('Loaded data from IndexedDB:', {
            segments: storedData.segments?.length || 0,
            characters: storedData.characters?.length || 0,
            storylines: storedData.storylines?.length || 0,
            segmentsData: storedData.segments
          })
          
          // Direkter Test: Lade Segmente einzeln
          const directSegments = await indexedDBStorage.getSegments()
          console.log('Direct segments from DB:', directSegments.length, directSegments)

          // Run migrations and initialize moods from scenes
          let dataToSet = storedData

          try {
            await DatabaseMigrator.migrateIfNeeded(indexedDBStorage)

            // Manuelle Storyline-Migration durchführen
            try {
              await runManualStorylineMigration()
              console.log("Manual storyline migration completed")
            } catch (migrationError) {
              console.warn("Manual storyline migration failed (might already be done):", migrationError)
            }

            // Erneute Forced Migration durchführen
            try {
              await runForcedStorylineMigration()
              console.log("Forced storyline migration completed")
            } catch (forcedMigrationError) {
              console.warn("Forced storyline migration failed:", forcedMigrationError)
            }

            // Moods-Funktion für Wrestling nicht benötigt - auskommentiert
            /*
            if (!storedData.moods || storedData.moods.length === 0) {
              console.log('Initializing moods from existing scenes...')
              const uniqueMoods = new Set<string>()

              storedData.segments?.forEach(scene => {
                if (scene.mood && scene.mood.trim()) {
                  uniqueMoods.add(scene.mood.trim())
                }
              })

              if (uniqueMoods.size > 0) {
                const moods = Array.from(uniqueMoods).map(moodName => ({
                  id: generateId(),
                  name: moodName,
                  description: '',
                  isActive: true,
                  createdAt: new Date(),
                  updatedAt: new Date(),
                }))

                dataToSet = {
                  ...storedData,
                  moods
                }

                // Try to save moods to IndexedDB (may fail if stores don't exist)
                try {
                  await Promise.all(moods.map(mood => indexedDBStorage.saveMood(mood)))
                  console.log(`Saved ${moods.length} moods to database`)
                } catch (saveError) {
                  console.warn('Could not save moods to database, keeping in memory:', saveError)
                }
              }
            }
            */
          } catch (migrationError) {
            console.warn('Migration failed, but continuing with existing data:', migrationError)
          }

          setData(dataToSet)
        } else {
          // Fallback to localStorage if IndexedDB fails
          console.warn("Using localStorage as fallback")
          const stored = localStorage.getItem("ringmaster-app-data")
          if (stored) {
            try {
              const parsed = JSON.parse(stored)
              setData(parsed)
            } catch (parseError) {
              console.error("Failed to parse localStorage data:", parseError)
            }
          }
        }
      } catch (error) {
        console.error("Failed to initialize storage:", error)
        // Fallback to localStorage
        const stored = localStorage.getItem("ringmaster-manager-data")
        if (stored) {
          try {
            const parsed = JSON.parse(stored)
            setData(parsed)
          } catch (parseError) {
            console.error("Failed to parse localStorage data:", parseError)
          }
        }
      } finally {
        // Immer isLoading auf false setzen
        setIsLoading(false)
      }
    }

    initStorage()
  }, [initialized])

  // Save data to IndexedDB whenever it changes (only after initialization)
  // Verwende useRef um unendliche Loops zu vermeiden
  const lastSavedData = useRef<string>('')

  useEffect(() => {
    if (!isLoading && storageReady) {
      const dataString = JSON.stringify(data)
      // Nur speichern wenn sich die Daten tatsächlich geändert haben
      if (dataString !== lastSavedData.current) {
        lastSavedData.current = dataString

        const saveData = async () => {
          try {
            // Save each entity type separately for better performance
            // Use Promise.allSettled to handle individual failures gracefully
            // Ensure all data arrays are actually arrays before mapping
            const safeData = {
              series: Array.isArray(data.series) ? data.series : [],
              characters: Array.isArray(data.characters) ? data.characters : [],
              relationships: Array.isArray(data.relationships) ? data.relationships : [],
              characterArcs: Array.isArray(data.characterArcs) ? data.characterArcs : [],
              storylines: Array.isArray(data.storylines) ? data.storylines : [],
              segments: Array.isArray(data.segments) ? data.segments : [],
              episodes: Array.isArray(data.episodes) ? data.episodes : [],
              seasons: Array.isArray(data.seasons) ? data.seasons : [],
              locations: Array.isArray(data.locations) ? data.locations : [],
              moods: [], // Moods-Funktion für Wrestling nicht benötigt - auskommentiert
              promotions: Array.isArray(data.promotions) ? data.promotions : [],
              arenas: Array.isArray(data.arenas) ? data.arenas : [],
              shows: Array.isArray(data.shows) ? data.shows : [],
            }

            const saveResults = await Promise.allSettled([
              ...safeData.series.map(series => indexedDBStorage.saveSeries(series)),
              ...safeData.characters.map(char => indexedDBStorage.saveCharacter(char)),
              ...safeData.relationships.map(rel => indexedDBStorage.saveRelationship(rel)),
              ...safeData.characterArcs.map(arc => indexedDBStorage.saveCharacterArc(arc)),
              ...safeData.storylines.map(story => indexedDBStorage.saveStoryline(story)),
              ...safeData.segments.map(segment => indexedDBStorage.saveSegment(segment)),
              ...safeData.episodes.map(ep => indexedDBStorage.saveEvent(ep)),
              ...safeData.seasons.map(season => indexedDBStorage.saveSeason(season)),
              ...safeData.locations.map(location => indexedDBStorage.saveLocation(location)),
              ...safeData.promotions.map(promotion => indexedDBStorage.savePromotion(promotion)),
              ...safeData.arenas.map(arena => indexedDBStorage.saveArena(arena)),
              ...safeData.shows.map(show => indexedDBStorage.saveShow(show)),
            ])

            // Check if any saves failed
            const failedSaves = saveResults.filter(result => result.status === 'rejected')
            if (failedSaves.length > 0) {
              console.warn(`${failedSaves.length} saves failed, data kept in memory`)
              failedSaves.forEach((result, index) => {
                if (result.status === 'rejected') {
                  console.error(`Save failed for item ${index}:`, result.reason)
                }
              })
            }

          } catch (error) {
            console.error("Failed to save data to IndexedDB:", error)
            // Fallback: save to localStorage with aggressive size reduction
            try {
              // Create a much smaller version for emergency fallback
              const emergencyData = {
                series: data.series,
                characters: data.characters.slice(0, 10), // Limit to 10 characters
                relationships: data.relationships.slice(0, 20), // Limit relationships
                storylines: data.storylines.slice(0, 5), // Limit storylines
                segments: data.segments.slice(0, 50), // Limit segments
                episodes: data.episodes.slice(0, 10), // Limit episodes
                seasons: data.seasons,
                locations: data.locations.slice(0, 20), // Limit locations
                moods: [], // Moods-Funktion für Wrestling nicht benötigt - auskommentiert
                characterArcs: data.characterArcs.slice(0, 5), // Limit character arcs
              }

              // Try to save the reduced data
              localStorage.setItem("ringmaster-app-data", JSON.stringify(emergencyData))
              console.warn("Saved emergency reduced data to localStorage due to quota issues")
            } catch (fallbackError) {
              console.error("Emergency fallback save also failed:", fallbackError)
              // Last resort: clear localStorage and save minimal data
              try {
                localStorage.removeItem("ringmaster-app-data")
                const minimalData = {
                  series: data.series,
                  characters: [],
                  relationships: [],
                  storylines: [],
                  scenes: [],
                  episodes: [],
                  seasons: [],
                  locations: [],
                  moods: [], // Moods-Funktion für Wrestling nicht benötigt - auskommentiert
                  characterArcs: [],
                }
                localStorage.setItem("ringmaster-app-data", JSON.stringify(minimalData))
                console.warn("Saved minimal data to localStorage as last resort")
              } catch (lastResortError) {
                console.error("All save attempts failed, data only in memory:", lastResortError)
                // Data stays in memory only
              }
            }
          }
        }

        saveData()
      }
    }
  }, [data, isLoading, storageReady])

  const updateData = useCallback((updater: (prev: SeriesData) => SeriesData) => {
    setData(updater)
  }, [])

  // Avatar upload function
  const uploadAvatar = useCallback(async (characterId: string, file: File): Promise<string> => {
    const blobId = `avatar-${characterId}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
    await indexedDBStorage.saveBlob(blobId, file)

    // Update character with blob reference
    setData(prev => ({
      ...prev,
      characters: prev.characters.map(char =>
        char.id === characterId
          ? { ...char, avatarBlobId: blobId, updatedAt: new Date() }
          : char
      )
    }))

    return blobId
  }, [])

  // Get avatar URL from blob
  const getAvatarUrl = useCallback(async (character: Character): Promise<string | null> => {
    if (character.avatarBlobId) {
      try {
        const blob = await indexedDBStorage.getBlob(character.avatarBlobId)
        return blob ? URL.createObjectURL(blob) : character.imageUrl || null
      } catch (error) {
        console.error("Failed to load avatar blob:", error)
        return character.imageUrl || null
      }
    }
    return character.imageUrl || null
  }, [])

  // Series operations
  const createSeries = useCallback(
    (series: Omit<Series, "id" | "createdAt">) => {
      updateData((prev) => ({
        ...prev,
        series: [...prev.series, { ...series, id: generateId(), createdAt: new Date() }],
      }))
    },
    [updateData],
  )

  const updateSeries = useCallback(
    (series: Series) => {
      updateData((prev) => ({
        ...prev,
        series: prev.series && prev.series.length > 0 ? [series] : prev.series
      }))
    },
    [updateData],
  )

  const uploadCoverImage = useCallback(async (file: File): Promise<string> => {
    const blobId = `cover-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
    await indexedDBStorage.saveBlob(blobId, file)

    // Update series with blob reference
    setData(prev => ({
      ...prev,
      series: prev.series && prev.series.length > 0 ? [
        {
          ...prev.series[0],
          coverImageBlobId: blobId,
          updatedAt: new Date()
        }
      ] : prev.series
    }))

    return blobId
  }, [])

  const getCoverImageUrl = useCallback(async (series: Series): Promise<string | null> => {
    if (series.coverImageBlobId) {
      try {
        const blob = await indexedDBStorage.getBlob(series.coverImageBlobId)
        return blob ? URL.createObjectURL(blob) : series.coverImageUrl || null
      } catch (error) {
        console.error("Failed to load cover image blob:", error)
        return series.coverImageUrl || null
      }
    }
    return series.coverImageUrl || null
  }, [])

  // Character operations
  const addCharacter = useCallback(
    (character: Omit<Character, "id" | "createdAt" | "updatedAt">) => {
      updateData((prev) => ({
        ...prev,
        characters: [
          ...prev.characters,
          {
            ...character,
            id: generateId(),
            createdAt: new Date(),
            updatedAt: new Date(),
          },
        ],
      }))
    },
    [updateData],
  )

  const updateCharacter = useCallback(
    (character: Character) => {
      updateData((prev) => ({
        ...prev,
        characters: prev.characters.map((c) => (c.id === character.id ? { ...c, ...character, updatedAt: new Date() } : c)),
      }))
    },
    [updateData],
  )

  const deleteCharacter = useCallback(
    (id: string) => {
      updateData((prev) => ({
        ...prev,
        characters: prev.characters.filter((c) => c.id !== id),
        relationships: prev.relationships.filter(
          (r) => {
            // Handle both old and new data structure
            const characterIds = r.characterIds || 
              ((r as any).characterId1 && (r as any).characterId2 ? 
                [(r as any).characterId1, (r as any).characterId2] : [])
            return !characterIds.includes(id)
          }
        ),
        characterArcs: prev.characterArcs.filter((arc) => arc.characterId !== id),
        storylines: prev.storylines.map((story) => ({
          ...story,
          characterIds: story.characterIds.filter((cid) => cid !== id),
        })),
        segments: prev.segments.map((segment) => ({
          ...segment,
          characterIds: segment.characterIds.filter((cid) => cid !== id),
        })),
      }))
    },
    [data.characters, storageReady],
  )

  // Relationship operations
  const addRelationship = useCallback(
    (relationship: Omit<Relationship, "id">) => {
      updateData((prev) => ({
        ...prev,
        relationships: [...prev.relationships, { ...relationship, id: generateId() }],
      }))
    },
    [updateData],
  )

  const updateRelationship = useCallback(
    (relationship: Relationship) => {
      updateData((prev) => ({
        ...prev,
        relationships: prev.relationships.map((r) => (r.id === relationship.id ? relationship : r)),
      }))
    },
    [updateData],
  )

  const deleteRelationship = useCallback(
    (id: string) => {
      updateData((prev) => ({
        ...prev,
        relationships: prev.relationships.filter((r) => r.id !== id),
      }))
      
      // Also delete from IndexedDB
      if (storageReady) {
        indexedDBStorage.deleteRelationship(id).catch(console.error)
      }
    },
    [updateData, storageReady],
  )

  // Character Arc operations
  const addCharacterArc = useCallback(
    (arc: Omit<CharacterArc, "id">) => {
      const now = new Date()
      const newArc: CharacterArc = {
        ...arc,
        id: generateId(),
        createdAt: arc.createdAt || now,
        updatedAt: now,
        // Ensure championship fields have defaults
        type: arc.type || "singles",
        prestige: arc.prestige || "world",
        currentChampionIds: arc.currentChampionIds || [],
        championHistory: arc.championHistory || [],
      }
      updateData((prev) => ({
        ...prev,
        characterArcs: [...prev.characterArcs, newArc],
      }))
    },
    [updateData],
  )

  const updateCharacterArc = useCallback(
    (arc: CharacterArc) => {
      updateData((prev) => ({
        ...prev,
        characterArcs: prev.characterArcs.map((a) => (a.id === arc.id ? arc : a)),
      }))
    },
    [updateData],
  )

  const deleteCharacterArc = useCallback(
    (id: string) => {
      updateData((prev) => ({
        ...prev,
        characterArcs: prev.characterArcs.filter((a) => a.id !== id),
      }))
    },
    [updateData],
  )

  // Storyline operations
  const addStoryline = useCallback(
    (storyline: Omit<Storyline, "id" | "createdAt">) => {
      updateData((prev) => ({
        ...prev,
        storylines: [...prev.storylines, { ...storyline, id: generateId(), createdAt: new Date() }],
      }))
    },
    [updateData],
  )

  const updateStoryline = useCallback(
    (storyline: Storyline) => {
      updateData((prev) => ({
        ...prev,
        storylines: prev.storylines.map((s) => (s.id === storyline.id ? storyline : s)),
      }))
    },
    [updateData],
  )

  const deleteStoryline = useCallback(
    (id: string) => {
      updateData((prev) => ({
        ...prev,
        storylines: prev.storylines.filter((s) => s.id !== id),
      }))
    },
    [updateData],
  )

  // Scene operations
  const addScene = useCallback(
    (scene: Omit<Segment, "id">) => {
      console.log('Adding scene:', scene.title)
      updateData((prev) => {
        const newSegments = [...prev.segments, { ...scene, id: generateId() }]
        console.log('New segments count:', newSegments.length)
        return {
          ...prev,
          segments: newSegments,
        }
      })
    },
    [updateData],
  )

  const updateScene = useCallback(
    (scene: Segment) => {
      console.log('Updating scene:', scene.title)
      updateData((prev) => {
        const updatedSegments = prev.segments.map((s) => (s.id === scene.id ? scene : s))
        console.log('Updated segments count:', updatedSegments.length)
        return {
          ...prev,
          segments: updatedSegments,
        }
      })
    },
    [updateData],
  )

  const deleteScene = useCallback(
    (id: string) => {
      console.log('Deleting scene:', id)
      updateData((prev) => {
        const remainingSegments = prev.segments.filter((s) => s.id !== id)
        console.log('Remaining segments count:', remainingSegments.length)
        return {
          ...prev,
          segments: remainingSegments,
          episodes: prev.episodes.map((ep) => ({
            ...ep,
            sceneIds: ep.sceneIds.filter((sid) => sid !== id),
          })),
        }
      })
    },
    [updateData],
  )

  // Event operations
  const addEpisode = useCallback(
    (episode: Omit<Event, "id">) => {
      updateData((prev) => ({
        ...prev,
        episodes: [...prev.episodes, { ...episode, id: generateId() }],
      }))
    },
    [updateData],
  )

  const updateEpisode = useCallback(
    (episode: Event) => {
      // Prüfen ob Status auf "completed" geändert wurde und noch kein Bericht existiert
      const existingEpisode = data.episodes.find(e => e.id === episode.id)
      const shouldGenerateReport = 
        episode.status === "completed" && 
        (!existingEpisode || existingEpisode.status !== "completed" || !existingEpisode.completionReport)

      let updatedEpisode = episode

      if (shouldGenerateReport) {
        try {
          const { generateEventReport } = require("./event-report")
          const report = generateEventReport(episode.id, data)
          updatedEpisode = { ...episode, completionReport: report }
        } catch (error) {
          console.error("Fehler beim Generieren des Event-Berichts:", error)
        }
      }

      updateData((prev) => ({
        ...prev,
        episodes: prev.episodes.map((e) => (e.id === episode.id ? updatedEpisode : e)),
      }))
    },
    [updateData, data],
  )

  const deleteEpisode = useCallback(
    (id: string) => {
      updateData((prev) => ({
        ...prev,
        episodes: prev.episodes.filter((e) => e.id !== id),
      }))
    },
    [updateData],
  )

  const addSceneToEpisode = useCallback(
    (episodeId: string, sceneId: string) => {
      updateData((prev) => ({
        ...prev,
        episodes: prev.episodes.map((ep) =>
          ep.id === episodeId ? { ...ep, sceneIds: [...ep.sceneIds, sceneId] } : ep,
        ),
      }))
    },
    [updateData],
  )

  const removeSceneFromEpisode = useCallback(
    (episodeId: string, sceneId: string) => {
      updateData((prev) => ({
        ...prev,
        episodes: prev.episodes.map((ep) =>
          ep.id === episodeId ? { ...ep, sceneIds: ep.sceneIds.filter((id) => id !== sceneId) } : ep,
        ),
      }))
    },
    [updateData],
  )

  const sortEpisodeScenesByTimeOfDay = useCallback(
    (episodeId: string) => {
      updateData((prev) => {
        const episode = prev.episodes.find((ep) => ep.id === episodeId)
        if (!episode) return prev

        // TimeOfDay-Funktion für Wrestling nicht benötigt - auskommentiert
        // Definiere die Sortierreihenfolge für Tageszeiten
        // const timeOfDayOrder = { morning: 0, afternoon: 1, evening: 2, night: 3 }

        // Hole alle Segmente der Episode
        const segmentsToSort = episode.sceneIds
          .map((segmentId) => prev.segments.find((s) => s.id === segmentId))
          .filter((segment): segment is Segment => segment !== undefined)

        // Einfache Sortierung nach Order für Wrestling-Promotion
        const sortedSegments = segmentsToSort.sort((a, b) => a.order - b.order)
        
        // Erstelle neue sortierte Liste der Segment-IDs
        const sortedSegmentIds: string[] = []
        sortedSegments.forEach((segment: Segment) => {
          sortedSegmentIds.push(segment.id)
        })

        // Aktualisiere die Episode mit den sortierten Segment-IDs
        return {
          ...prev,
          episodes: prev.episodes.map((ep) =>
            ep.id === episodeId ? { ...ep, sceneIds: sortedSegmentIds } : ep
          ),
        }
      })
    },
    [updateData],
  )

  // Location operations
  const addLocation = useCallback(
    (location: Omit<Location, "id" | "createdAt" | "updatedAt">) => {
      updateData((prev) => ({
        ...prev,
        locations: [
          ...prev.locations,
          {
            ...location,
            id: generateId(),
            createdAt: new Date(),
            updatedAt: new Date(),
          },
        ],
      }))
    },
    [updateData],
  )

  const updateLocation = useCallback(
    (location: Location) => {
      updateData((prev) => ({
        ...prev,
        locations: prev.locations.map((l) => (l.id === location.id ? { ...location, updatedAt: new Date() } : l)),
      }))
    },
    [updateData],
  )

  const deleteLocation = useCallback(
    (id: string) => {
      updateData((prev) => ({
        ...prev,
        locations: prev.locations.filter((l) => l.id !== id),
      }))
    },
    [updateData],
  )

  const getActiveLocations = useCallback(
    () => {
      return (data.locations || []).filter((location) => location && location.isActive)
    },
    [data.locations],
  )

  // Mood operations
  const addMood = useCallback(
    (mood: Omit<Mood, "id" | "createdAt" | "updatedAt">) => {
      updateData((prev) => ({
        ...prev,
        moods: [
          ...prev.moods,
          {
            ...mood,
            id: generateId(),
            createdAt: new Date(),
            updatedAt: new Date(),
          },
        ],
      }))
    },
    [updateData],
  )

  const updateMood = useCallback(
    (mood: Mood) => {
      updateData((prev) => ({
        ...prev,
        moods: prev.moods.map((m) => (m.id === mood.id ? { ...mood, updatedAt: new Date() } : m)),
      }))
    },
    [updateData],
  )

  const deleteMood = useCallback(
    (id: string) => {
      updateData((prev) => ({
        ...prev,
        moods: prev.moods.filter((m) => m.id !== id),
      }))
    },
    [updateData],
  )

  const getActiveMoods = useCallback(
    () => {
      return (data.moods || []).filter((mood) => mood && mood.isActive)
    },
    [data.moods],
  )

  // Game Center Operations
  
  // Promotion operations
  const addPromotion = useCallback(
    (promotion: Omit<Promotion, "id" | "createdAt" | "updatedAt">) => {
      const newPromotion: Promotion = {
        ...promotion,
        id: generateId(),
        createdAt: new Date(),
        updatedAt: new Date(),
      }
      updateData((prev) => ({
        ...prev,
        promotions: [...prev.promotions, newPromotion],
      }))
    },
    [updateData],
  )

  const updatePromotion = useCallback(
    (promotion: Promotion) => {
      updateData((prev) => ({
        ...prev,
        promotions: prev.promotions.map((p) => (p.id === promotion.id ? { ...p, ...promotion, updatedAt: new Date() } : p)),
      }))
    },
    [updateData],
  )

  const deletePromotion = useCallback(
    (id: string) => {
      updateData((prev) => ({
        ...prev,
        promotions: prev.promotions.filter((p) => p.id !== id),
      }))
    },
    [updateData],
  )

  // Arena operations
  const addArena = useCallback(
    (arena: Omit<Arena, "id" | "createdAt" | "updatedAt">) => {
      const newArena: Arena = {
        ...arena,
        id: generateId(),
        createdAt: new Date(),
        updatedAt: new Date(),
      }
      updateData((prev) => ({
        ...prev,
        arenas: [...prev.arenas, newArena],
      }))
    },
    [updateData],
  )

  const updateArena = useCallback(
    (arena: Arena) => {
      updateData((prev) => ({
        ...prev,
        arenas: prev.arenas.map((a) => (a.id === arena.id ? { ...a, ...arena, updatedAt: new Date() } : a)),
      }))
    },
    [updateData],
  )

  const deleteArena = useCallback(
    (id: string) => {
      updateData((prev) => ({
        ...prev,
        arenas: prev.arenas.filter((a) => a.id !== id),
      }))
    },
    [updateData],
  )

  // Show operations
  const addShow = useCallback(
    (show: Omit<Show, "id" | "createdAt" | "updatedAt">) => {
      const newShow: Show = {
        ...show,
        id: generateId(),
        createdAt: new Date(),
        updatedAt: new Date(),
      }
      updateData((prev) => ({
        ...prev,
        shows: [...prev.shows, newShow],
      }))
    },
    [updateData],
  )

  const updateShow = useCallback(
    (show: Show) => {
      updateData((prev) => ({
        ...prev,
        shows: prev.shows.map((s) => (s.id === show.id ? { ...s, ...show, updatedAt: new Date() } : s)),
      }))
    },
    [updateData],
  )

  const deleteShow = useCallback(
    (id: string) => {
      updateData((prev) => ({
        ...prev,
        shows: prev.shows.filter((s) => s.id !== id),
      }))
    },
    [updateData],
  )

  // Season operations
  const addSeason = useCallback(
    (season: Omit<Season, "id">) => {
      updateData((prev) => ({
        ...prev,
        seasons: [...prev.seasons, { ...season, id: generateId() }],
      }))
    },
    [updateData],
  )

  const updateSeason = useCallback(
    (season: Season) => {
      updateData((prev) => ({
        ...prev,
        seasons: prev.seasons.map((s) => (s.id === season.id ? season : s)),
      }))
    },
    [updateData],
  )

  // Championship Reign operations
  const addChampionshipReign = useCallback(
    (championshipId: string, reign: Omit<ChampionshipReign, "id">) => {
      updateData((prev) => ({
        ...prev,
        characterArcs: prev.characterArcs.map((arc) =>
          arc.id === championshipId
            ? { ...arc, championHistory: [...arc.championHistory, { ...reign, id: generateId() }] }
            : arc
        ),
      }))
    },
    [updateData],
  )

  const updateChampionshipReign = useCallback(
    (championshipId: string, reign: ChampionshipReign) => {
      updateData((prev) => ({
        ...prev,
        characterArcs: prev.characterArcs.map((arc) =>
          arc.id === championshipId
            ? { ...arc, championHistory: arc.championHistory.map((r) => (r.id === reign.id ? reign : r)) }
            : arc
        ),
      }))
    },
    [updateData],
  )

  const deleteChampionshipReign = useCallback(
    (championshipId: string, reignId: string) => {
      updateData((prev) => ({
        ...prev,
        characterArcs: prev.characterArcs.map((arc) =>
          arc.id === championshipId
            ? { ...arc, championHistory: arc.championHistory.filter((r) => r.id !== reignId) }
            : arc
        ),
      }))
    },
    [updateData],
  )

  return (
    <SeriesContext.Provider
      value={{
        data,
        isLoading,
        storageReady,
        createSeries,
        updateSeries,
        uploadCoverImage,
        getCoverImageUrl,
        addCharacter,
        updateCharacter,
        deleteCharacter,
        uploadAvatar,
        getAvatarUrl,
        addRelationship,
        updateRelationship,
        deleteRelationship,
        addCharacterArc,
        updateCharacterArc,
        deleteCharacterArc,
        addStoryline,
        updateStoryline,
        deleteStoryline,
        addScene,
        updateScene,
        deleteScene,
        addEpisode,
        updateEpisode,
        deleteEpisode,
        addSceneToEpisode,
        removeSceneFromEpisode,
        sortEpisodeScenesByTimeOfDay,
        addLocation,
        updateLocation,
        deleteLocation,
        getActiveLocations,
        addMood,
        updateMood,
        deleteMood,
        getActiveMoods,
        addSeason,
        updateSeason,
        // Game Center Operations
        addPromotion,
        updatePromotion,
        deletePromotion,
        addArena,
        updateArena,
        deleteArena,
        addShow,
        updateShow,
        deleteShow,
        addChampionshipReign,
        updateChampionshipReign,
        deleteChampionshipReign,
      }}
    >
      {children}
    </SeriesContext.Provider>
  )
}

export function useSeries() {
  const context = useContext(SeriesContext)
  if (!context) {
    throw new Error("useSeries must be used within a SeriesProvider")
  }
  return context
}
