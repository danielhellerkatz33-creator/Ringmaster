import type { CharacterArc, Character } from './types'

/**
 * Helper-Funktionen für Championship-Integration in Character-Ansichten
 */

export interface ChampionshipInfo {
  id: string
  title: string
  type: 'current' | 'former'
  prestige: 'world' | 'national' | 'regional' | 'local' | 'developmental'
  dateWon?: Date
  dateLost?: Date
  defenses?: number
}

/**
 * Gibt alle aktuellen Championships für einen Character zurück
 */
export function getCurrentChampionships(
  characterId: string,
  championships: CharacterArc[]
): ChampionshipInfo[] {
  return championships
    .filter(champ => 
      champ.currentChampionIds?.includes(characterId) && 
      champ.status === 'active'
    )
    .map(champ => ({
      id: champ.id,
      title: champ.title,
      type: 'current' as const,
      prestige: champ.prestige,
    }))
    .sort((a, b) => getPrestigeOrder(a.prestige) - getPrestigeOrder(b.prestige))
}

/**
 * Zählt die ehemaligen Championships für einen Character
 */
export function getFormerChampionshipsCount(
  characterId: string,
  championships: CharacterArc[]
): number {
  return championships.reduce((count, champ) => {
    const characterReigns = champ.championHistory.filter(
      reign => reign.championIds.includes(characterId)
    )
    return count + characterReigns.length
  }, 0)
}

/**
 * Gibt die Gesamtzahl der Reigns für einen Character zurück
 */
export function getTotalReigns(
  characterId: string,
  championships: CharacterArc[]
): number {
  return championships.reduce((count, champ) => {
    const characterReigns = champ.championHistory.filter(
      reign => reign.championIds.includes(characterId)
    )
    return count + characterReigns.length
  }, 0) + getCurrentChampionships(characterId, championships).length
}

/**
 * Gibt die komplette Championship-Historie für einen Character zurück
 */
export function getChampionshipHistory(
  characterId: string,
  championships: CharacterArc[]
): ChampionshipInfo[] {
  const history: ChampionshipInfo[] = []
  
  championships.forEach(champ => {
    // Aktuelle Reigns
    if (champ.currentChampionIds?.includes(characterId)) {
      history.push({
        id: champ.id,
        title: champ.title,
        type: 'current' as const,
        prestige: champ.prestige,
      })
    }
    
    // Historische Reigns
    champ.championHistory
      .filter(reign => reign.championIds.includes(characterId))
      .forEach(reign => {
        history.push({
          id: champ.id,
          title: champ.title,
          type: 'former' as const,
          prestige: champ.prestige,
          dateWon: reign.dateWon,
          dateLost: reign.dateLost,
          defenses: reign.defenses,
        })
      })
  })
  
  // Nach Datum sortieren (neueste zuerst)
  return history.sort((a, b) => {
    if (!a.dateWon && !b.dateWon) return 0
    if (!a.dateWon) return 1 // Aktuelle Titel kommen zuerst
    if (!b.dateWon) return -1
    
    // Konvertiere String-Daten zu Date-Objekten wenn nötig
    const dateA = a.dateWon instanceof Date ? a.dateWon : new Date(a.dateWon)
    const dateB = b.dateWon instanceof Date ? b.dateWon : new Date(b.dateWon)
    
    return dateB.getTime() - dateA.getTime()
  })
}

/**
 * Hilfsfunktion für Prestige-Sortierung
 */
function getPrestigeOrder(prestige: string): number {
  const order = {
    'world': 1,
    'national': 2,
    'regional': 3,
    'local': 4,
    'developmental': 5
  }
  return order[prestige as keyof typeof order] || 5
}

/**
 * Formatiert die Championship-Anzeige für Character-Card
 */
export function formatChampionshipBadges(
  characterId: string,
  championships: CharacterArc[]
): { current: string[], former: string } {
  const current = getCurrentChampionships(characterId, championships)
  const formerCount = getFormerChampionshipsCount(characterId, championships)
  
  const currentBadges = current.map(champ => `🏆 ${champ.title}`)
  const formerBadge = formerCount > 0 ? `🥈 ${formerCount}x Former Champion` : ''
  
  return {
    current: currentBadges,
    former: formerBadge
  }
}
