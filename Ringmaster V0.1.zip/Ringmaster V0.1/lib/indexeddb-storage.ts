import type {
  SeriesData,
  Character,
  Relationship,
  Storyline,
  Segment,
  Event,
  Season,
  Series,
  CharacterArc,
  Location,
  Mood,
  Promotion,
  Arena,
  Show,
} from "./types"

export class IndexedDBStorage {
  private db: IDBDatabase | null = null
  private readonly dbName = "ringmaster-manager"
  private readonly dbVersion = 5

  async init(): Promise<void> {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.dbName, this.dbVersion)

      // Timeout nach 5 Sekunden, falls IndexedDB blockiert ist
      const timeout = setTimeout(() => {
        console.warn("IndexedDB initialization timeout - falling back to localStorage")
        reject(new Error("IndexedDB initialization timeout"))
      }, 5000)

      request.onerror = () => {
        clearTimeout(timeout)
        console.error("IndexedDB error:", request.error)
        reject(request.error)
      }

      request.onsuccess = () => {
        clearTimeout(timeout)
        this.db = request.result
        console.log("IndexedDB initialized successfully")
        resolve()
      }

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result
        console.log("IndexedDB upgrade needed, creating stores...")

        // Object Stores für verschiedene Entitäten
        if (!db.objectStoreNames.contains("series")) {
          db.createObjectStore("series", { keyPath: "id" })
        }

        if (!db.objectStoreNames.contains("characters")) {
          const characterStore = db.createObjectStore("characters", { keyPath: "id" })
          characterStore.createIndex("name", "name", { unique: false })
          characterStore.createIndex("position", "position", { unique: false })
        }

        if (!db.objectStoreNames.contains("relationships")) {
          db.createObjectStore("relationships", { keyPath: "id" })
        }

        if (!db.objectStoreNames.contains("characterArcs")) {
          db.createObjectStore("characterArcs", { keyPath: "id" })
        }

        if (!db.objectStoreNames.contains("storylines")) {
          const storylineStore = db.createObjectStore("storylines", { keyPath: "id" })
          storylineStore.createIndex("type", "type", { unique: false })
          storylineStore.createIndex("status", "status", { unique: false })
        }

        if (!db.objectStoreNames.contains("locations")) {
          const locationStore = db.createObjectStore("locations", { keyPath: "id" })
          locationStore.createIndex("isActive", "isActive", { unique: false })
        }

        if (!db.objectStoreNames.contains("moods")) {
          const moodStore = db.createObjectStore("moods", { keyPath: "id" })
          moodStore.createIndex("isActive", "isActive", { unique: false })
        }

        if (!db.objectStoreNames.contains("scenes")) {
          db.createObjectStore("scenes", { keyPath: "id" })
        }

        if (!db.objectStoreNames.contains("episodes")) {
          const episodeStore = db.createObjectStore("episodes", { keyPath: "id" })
          episodeStore.createIndex("status", "status", { unique: false })
        }

        if (!db.objectStoreNames.contains("seasons")) {
          db.createObjectStore("seasons", { keyPath: "id" })
        }

        // Game Center Stores
        if (!db.objectStoreNames.contains("promotions")) {
          const promotionStore = db.createObjectStore("promotions", { keyPath: "id" })
          promotionStore.createIndex("name", "name", { unique: false })
        }

        if (!db.objectStoreNames.contains("arenas")) {
          const arenaStore = db.createObjectStore("arenas", { keyPath: "id" })
          arenaStore.createIndex("name", "name", { unique: false })
          arenaStore.createIndex("location", "location", { unique: false })
        }

        if (!db.objectStoreNames.contains("shows")) {
          const showStore = db.createObjectStore("shows", { keyPath: "id" })
          showStore.createIndex("name", "name", { unique: false })
          showStore.createIndex("type", "type", { unique: false })
        }

        // Blob Store für Avatare und Dateien
        if (!db.objectStoreNames.contains("blobs")) {
          db.createObjectStore("blobs")
        }

        // Migration store
        if (!db.objectStoreNames.contains("migrations")) {
          db.createObjectStore("migrations", { keyPath: "id" })
        }
      }
    })
  }

  // Generic helper methods
  private async getAllFromStore<T>(storeName: string): Promise<T[]> {
    if (!this.db) throw new Error("Database not initialized")

    const transaction = this.db.transaction([storeName], "readonly")
    const store = transaction.objectStore(storeName)
    const request = store.getAll()

    return new Promise((resolve, reject) => {
      request.onsuccess = () => resolve(request.result)
      request.onerror = () => reject(request.error)
    })
  }

  private async putInStore(storeName: string, item: any): Promise<void> {
    if (!this.db) throw new Error("Database not initialized")

    const transaction = this.db.transaction([storeName], "readwrite")
    const store = transaction.objectStore(storeName)
    const request = store.put(item)

    return new Promise((resolve, reject) => {
      request.onsuccess = () => resolve()
      request.onerror = () => reject(request.error)
    })
  }

  private async deleteFromStore(storeName: string, key: string): Promise<void> {
    if (!this.db) throw new Error("Database not initialized")

    const transaction = this.db.transaction([storeName], "readwrite")
    const store = transaction.objectStore(storeName)
    const request = store.delete(key)

    return new Promise((resolve, reject) => {
      request.onsuccess = () => resolve()
      request.onerror = () => reject(request.error)
    })
  }

  // Series operations
  async saveSeries(series: Series): Promise<void> {
    if (series) {
      await this.putInStore("series", series)
    } else {
      // Delete current series if null
      const transaction = this.db!.transaction(["series"], "readwrite")
      const store = transaction.objectStore("series")
      const request = store.clear()
      await new Promise((resolve, reject) => {
        request.onsuccess = () => resolve(void 0)
        request.onerror = () => reject(request.error)
      })
    }
  }

  async getSeries(): Promise<Series[]> {
    const series = await this.getAllFromStore<Series>("series")
    return series
  }

  // Character operations
  async saveCharacter(character: Character): Promise<void> {
    await this.putInStore("characters", character)
  }

  async getCharacters(): Promise<Character[]> {
    return this.getAllFromStore<Character>("characters")
  }

  async deleteCharacter(characterId: string): Promise<void> {
    await this.deleteFromStore("characters", characterId)
  }

  // Relationship operations
  async saveRelationship(relationship: Relationship): Promise<void> {
    await this.putInStore("relationships", relationship)
  }

  async getRelationships(): Promise<Relationship[]> {
    return this.getAllFromStore<Relationship>("relationships")
  }

  async deleteRelationship(relationshipId: string): Promise<void> {
    await this.deleteFromStore("relationships", relationshipId)
  }

  // Character Arc operations
  async saveCharacterArc(arc: CharacterArc): Promise<void> {
    await this.putInStore("characterArcs", arc)
  }

  async getCharacterArcs(): Promise<CharacterArc[]> {
    return this.getAllFromStore<CharacterArc>("characterArcs")
  }

  async deleteCharacterArc(arcId: string): Promise<void> {
    await this.deleteFromStore("characterArcs", arcId)
  }

  // Storyline operations
  async saveStoryline(storyline: Storyline): Promise<void> {
    await this.putInStore("storylines", storyline)
  }

  async getStorylines(): Promise<Storyline[]> {
    return this.getAllFromStore<Storyline>("storylines")
  }

  async deleteStoryline(storylineId: string): Promise<void> {
    await this.deleteFromStore("storylines", storylineId)
  }

  // Segment operations (früher Scene)
  async saveSegment(segment: Segment): Promise<void> {
    await this.putInStore("scenes", segment)
  }

  async getSegments(): Promise<Segment[]> {
    return this.getAllFromStore<Segment>("scenes")
  }

  async deleteSegment(segmentId: string): Promise<void> {
    await this.deleteFromStore("scenes", segmentId)
  }

  // Event operations (früher Episode)
  async saveEvent(event: Event): Promise<void> {
    await this.putInStore("episodes", event)
  }

  async getEvents(): Promise<Event[]> {
    return this.getAllFromStore<Event>("episodes")
  }

  async deleteEvent(eventId: string): Promise<void> {
    await this.deleteFromStore("episodes", eventId)
  }

  // Season operations
  async saveSeason(season: Season): Promise<void> {
    await this.putInStore("seasons", season)
  }

  async getSeasons(): Promise<Season[]> {
    return this.getAllFromStore<Season>("seasons")
  }

  async deleteSeason(seasonId: string): Promise<void> {
    await this.deleteFromStore("seasons", seasonId)
  }

  // Location operations
  async saveLocation(location: Location): Promise<void> {
    try {
      await this.putInStore("locations", location)
    } catch (error) {
      console.error("Failed to save location:", error)
      throw error
    }
  }

  async getLocations(): Promise<Location[]> {
    try {
      return await this.getAllFromStore<Location>("locations")
    } catch (error) {
      // Fallback for when the locations store doesn't exist yet (during migration)
      console.warn("Locations store not found, returning empty array:", error)
      return []
    }
  }

  async deleteLocation(locationId: string): Promise<void> {
    await this.deleteFromStore("locations", locationId)
  }

  // Mood operations
  async saveMood(mood: Mood): Promise<void> {
    await this.putInStore("moods", mood)
  }

  async getMoods(): Promise<Mood[]> {
    try {
      return await this.getAllFromStore<Mood>("moods")
    } catch (error) {
      // Fallback for when the moods store doesn't exist yet (during migration)
      console.warn("Moods store not found, returning empty array:", error)
      return []
    }
  }

  async deleteMood(moodId: string): Promise<void> {
    await this.deleteFromStore("moods", moodId)
  }

  // Game Center Operations
  
  // Promotion operations
  async savePromotion(promotion: Promotion): Promise<void> {
    await this.putInStore("promotions", promotion)
  }

  async getPromotions(): Promise<Promotion[]> {
    return this.getAllFromStore<Promotion>("promotions")
  }

  async deletePromotion(promotionId: string): Promise<void> {
    await this.deleteFromStore("promotions", promotionId)
  }

  // Arena operations
  async saveArena(arena: Arena): Promise<void> {
    await this.putInStore("arenas", arena)
  }

  async getArenas(): Promise<Arena[]> {
    return this.getAllFromStore<Arena>("arenas")
  }

  async deleteArena(arenaId: string): Promise<void> {
    await this.deleteFromStore("arenas", arenaId)
  }

  // Show operations
  async saveShow(show: Show): Promise<void> {
    await this.putInStore("shows", show)
  }

  async getShows(): Promise<Show[]> {
    return this.getAllFromStore<Show>("shows")
  }

  async deleteShow(showId: string): Promise<void> {
    await this.deleteFromStore("shows", showId)
  }

  // Blob operations for avatars and files
  async saveBlob(key: string, blob: Blob): Promise<void> {
    if (!this.db) throw new Error("Database not initialized")

    const transaction = this.db.transaction(["blobs"], "readwrite")
    const store = transaction.objectStore("blobs")
    const request = store.put(blob, key)

    return new Promise((resolve, reject) => {
      request.onsuccess = () => resolve()
      request.onerror = () => reject(request.error)
    })
  }

  async getBlob(key: string): Promise<Blob | null> {
    if (!this.db) throw new Error("Database not initialized")

    const transaction = this.db.transaction(["blobs"], "readonly")
    const store = transaction.objectStore("blobs")
    const request = store.get(key)

    return new Promise((resolve, reject) => {
      request.onsuccess = () => resolve(request.result || null)
      request.onerror = () => reject(request.error)
    })
  }

  async deleteBlob(key: string): Promise<void> {
    await this.deleteFromStore("blobs", key)
  }

  // Get all data at once (for initialization and export)
  async getAllData(): Promise<SeriesData> {
    try {
      const results = await Promise.allSettled([
        this.getSeries(),
        this.getCharacters(),
        this.getRelationships(),
        this.getCharacterArcs(),
        this.getStorylines(),
        this.getSegments(),
        this.getEvents(),
        this.getSeasons(),
        this.getLocations(),
        this.getMoods(),
        this.getPromotions(),
        this.getArenas(),
        this.getShows(),
      ])

      const [
        seriesResult,
        charactersResult,
        relationshipsResult,
        characterArcsResult,
        storylinesResult,
        segmentsResult,
        eventsResult,
        seasonsResult,
        locationsResult,
        moodsResult,
        promotionsResult,
        arenasResult,
        showsResult,
      ] = results

      return {
        series: seriesResult.status === 'fulfilled' ? seriesResult.value : [],
        characters: charactersResult.status === 'fulfilled' ? charactersResult.value : [],
        relationships: relationshipsResult.status === 'fulfilled' ? relationshipsResult.value : [],
        characterArcs: characterArcsResult.status === 'fulfilled' ? characterArcsResult.value : [],
        storylines: storylinesResult.status === 'fulfilled' ? storylinesResult.value : [],
        segments: segmentsResult.status === 'fulfilled' ? segmentsResult.value : [],
        episodes: eventsResult.status === 'fulfilled' ? eventsResult.value : [],
        seasons: seasonsResult.status === 'fulfilled' ? seasonsResult.value : [],
        locations: locationsResult.status === 'fulfilled' ? locationsResult.value : [],
        moods: moodsResult.status === 'fulfilled' ? moodsResult.value : [],
        // Game Center Data
        promotions: promotionsResult.status === 'fulfilled' ? promotionsResult.value : [],
        arenas: arenasResult.status === 'fulfilled' ? arenasResult.value : [],
        shows: showsResult.status === 'fulfilled' ? showsResult.value : [],
      }
    } catch (error) {
      console.error('Failed to load data from IndexedDB:', error)
      // Return empty data as fallback
      return {
        series: [],
        characters: [],
        relationships: [],
        characterArcs: [],
        storylines: [],
        segments: [],
        episodes: [],
        seasons: [],
        locations: [],
        moods: [],
        // Game Center Data
        promotions: [],
        arenas: [],
        shows: [],
      }
    }
  }

  // Clear all data (for reset)
  async clearAllData(): Promise<void> {
    if (!this.db) throw new Error("Database not initialized")

    const storeNames = ["series", "characters", "relationships", "characterArcs", "storylines", "locations", "moods", "scenes", "episodes", "seasons", "promotions", "arenas", "shows", "blobs"]

    const transaction = this.db.transaction(storeNames, "readwrite")

    await Promise.all(
      storeNames.map(storeName => {
        const store = transaction.objectStore(storeName)
        const request = store.clear()
        return new Promise<void>((resolve, reject) => {
          request.onsuccess = () => resolve()
          request.onerror = () => reject(request.error)
        })
      })
    )
  }

  // Check if IndexedDB is supported
  static isSupported(): boolean {
    return typeof indexedDB !== "undefined"
  }
}

// Migration system for database schema updates
export class DatabaseMigrator {
  private static readonly MIGRATION_STORE = 'migrations'
  private static readonly CURRENT_VERSION = 5

  static async migrateIfNeeded(storage: IndexedDBStorage): Promise<void> {
    try {
      // Check current migration version
      const currentMigrationVersion = await this.getCurrentMigrationVersion(storage)

      if (currentMigrationVersion < this.CURRENT_VERSION) {
        console.log(`Migrating database from version ${currentMigrationVersion} to ${this.CURRENT_VERSION}...`)

        // Run migrations sequentially
        for (let version = currentMigrationVersion + 1; version <= this.CURRENT_VERSION; version++) {
          await this.runMigration(version, storage)
          await this.setMigrationVersion(version, storage)
        }

        console.log('All migrations completed successfully')
      }
    } catch (error) {
      console.error('Migration failed:', error)
      // Don't throw - allow app to continue with potentially incomplete schema
    }
  }

  private static async runMigration(version: number, storage: IndexedDBStorage): Promise<void> {
    switch (version) {
      case 3:
        await this.migrateToVersion3(storage)
        break
      case 4:
        await this.migrateToVersion4(storage)
        break
      case 5:
        await this.migrateToVersion5(storage)
        break
      default:
        console.warn(`No migration defined for version ${version}`)
    }
  }

  private static async migrateToVersion3(storage: IndexedDBStorage): Promise<void> {
    console.log('Running migration to version 3: Ensuring stores exist and initializing data')

    // Ensure stores exist (upgrade database if needed)
    await this.ensureStoresExist(storage)

    // Initialize locations and moods from existing scenes
    await this.initializeLocationsFromScenes(storage)
    await this.initializeMoodsFromScenes(storage)

    console.log('Version 3 migration completed')
  }

  private static async migrateToVersion4(storage: IndexedDBStorage): Promise<void> {
    console.log('Running migration to version 4: Finalizing stores and data persistence')

    // This migration runs in onupgradeneeded when version changes to 4
    // The stores should be created by the onupgradeneeded handler
    console.log('Version 4 migration completed - stores should now be available')
  }

  private static async migrateToVersion5(storage: IndexedDBStorage): Promise<void> {
    console.log('Running migration to version 5: Adding Game Center stores and migration store')
    
    // This migration runs in onupgradeneeded when version changes to 5
    // The Game Center stores and migration store should be created by the onupgradeneeded handler
    console.log('Version 5 migration completed - Game Center stores and migration store should now be available')
  }

  private static async ensureStoresExist(storage: IndexedDBStorage): Promise<void> {
    if (!storage['db']) throw new Error('Database not initialized')

    const storesToCheck = ['locations', 'moods']
    const missingStores = storesToCheck.filter(store => !(storage['db'] as IDBDatabase).objectStoreNames.contains(store))

    if (missingStores.length === 0) {
      console.log('All required stores exist')
      return // All stores exist
    }

    console.log('Missing stores detected:', missingStores)
    console.log('Cannot create stores in existing database. Data migration will be skipped.')
    console.log('Please clear your browser data or use incognito mode to reset the database.')

    // Don't throw error - allow app to continue with empty data
  }

  private static async initializeLocationsFromScenes(storage: IndexedDBStorage): Promise<void> {
    try {
      // Get existing locations and scenes
      const [existingLocations, segments] = await Promise.all([
        storage.getLocations(),
        storage.getSegments()
      ])

      if (segments.length === 0) return

      // Create set of existing location names (case-insensitive)
      const existingNames = new Set(
        existingLocations.map(loc => loc.name.toLowerCase().trim())
      )

      // Extract unique locations that don't already exist
      const newLocationNames = new Set<string>()
      segments.forEach(segment => {
        if (segment.location && segment.location.trim()) {
          const locationName = segment.location.trim()
          if (!existingNames.has(locationName.toLowerCase()) && !newLocationNames.has(locationName.toLowerCase())) {
            newLocationNames.add(locationName)
          }
        }
      })

      if (newLocationNames.size === 0) return

      // Create location objects
      const locations = Array.from(newLocationNames).map(locationName => ({
        id: generateId(),
        name: locationName,
        description: '',
        isActive: true,
        createdAt: new Date(),
        updatedAt: new Date(),
      }))

      // Save locations
      await Promise.all(locations.map(location => storage.saveLocation(location)))
      console.log(`Initialized ${locations.length} new locations from existing segments`)

    } catch (error) {
      console.warn('Failed to initialize locations from segments:', error)
      // Continue - this is not critical
    }
  }

  private static async initializeMoodsFromScenes(storage: IndexedDBStorage): Promise<void> {
    try {
      // Get existing moods and scenes
      const [existingMoods, segments] = await Promise.all([
        storage.getMoods(),
        storage.getSegments()
      ])

      if (segments.length === 0) return

      // Create set of existing mood names (case-insensitive)
      const existingNames = new Set(
        existingMoods.map(mood => mood.name.toLowerCase().trim())
      )

      // Extract unique moods that don't already exist
      const newMoodNames = new Set<string>()
      segments.forEach(segment => {
        if (segment.mood && segment.mood.trim()) {
          const moodName = segment.mood.trim()
          if (!existingNames.has(moodName.toLowerCase()) && !newMoodNames.has(moodName.toLowerCase())) {
            newMoodNames.add(moodName)
          }
        }
      })

      if (newMoodNames.size === 0) return

      // Create mood objects
      const moods = Array.from(newMoodNames).map(moodName => ({
        id: generateId(),
        name: moodName,
        description: '',
        isActive: true,
        createdAt: new Date(),
        updatedAt: new Date(),
      }))

      // Save moods
      await Promise.all(moods.map(mood => storage.saveMood(mood)))
      console.log(`Initialized ${moods.length} new moods from existing segments`)

    } catch (error) {
      console.warn('Failed to initialize moods from segments:', error)
      // Continue - this is not critical
    }
  }

  private static async getCurrentMigrationVersion(storage: IndexedDBStorage): Promise<number> {
    try {
      // Try to get from localStorage first (fallback)
      const stored = localStorage.getItem('ringmaster-manager-migration-version')
      if (stored) {
        return parseInt(stored, 10) || 0
      }

      // Try to get from IndexedDB
      const migrations = await storage['getAllFromStore']<{ version: number }>('migrations')
      if (migrations.length > 0) {
        return Math.max(...migrations.map(m => m.version))
      }

      return 0
    } catch (error) {
      console.warn('Could not determine migration version:', error)
      return 0
    }
  }

  private static async setMigrationVersion(version: number, storage: IndexedDBStorage): Promise<void> {
    try {
      // Save to localStorage as backup
      localStorage.setItem('ringmaster-manager-migration-version', version.toString())

      // Save to IndexedDB if possible
      await storage['putInStore']('migrations', {
        id: `migration_${version}`,
        version,
        migratedAt: new Date(),
      })
    } catch (error) {
      console.warn('Could not save migration version:', error)
    }
  }
}

// Helper function for generating IDs (duplicate from series-context)
function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
}

export const indexedDBStorage = new IndexedDBStorage()