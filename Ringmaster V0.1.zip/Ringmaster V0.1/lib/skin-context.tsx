// 📁 lib/skin-context.tsx
'use client';
import React, { createContext, useContext, useEffect, useState } from 'react';

export type Skin = 'dark' | 'light' | 'retro' | 'soap' | 'arena' | 'championship' | 'attitude' | 'lucha' | 'indie' | 'puroresu' | 'nxt';
interface SkinContextType {
  skin: Skin;
  setSkin: (skin: Skin) => void;
  toggleSkin: () => void;
}

const SkinContext = createContext<SkinContextType | undefined>(undefined);

export function useSkin() {
  const context = useContext(SkinContext);
  if (!context) throw new Error('useSkin must be used within a SkinProvider');
  return context;
}

interface SkinProviderProps {
  children: React.ReactNode;
  defaultSkin?: Skin;
  storageKey?: string;
}

export function SkinProvider({
  children,
  defaultSkin = 'dark',
  storageKey = 'ringmaster-app-skin',
}: SkinProviderProps) {
  const [skin, setSkinState] = useState<Skin>(defaultSkin);

  useEffect(() => {
    const stored = localStorage.getItem(storageKey);
    if (['dark', 'light', 'retro', 'soap', 'arena', 'championship', 'attitude', 'lucha', 'indie', 'puroresu', 'nxt'].includes(stored || '')) {
      setSkinState(stored as Skin);
    }
  }, []);

  useEffect(() => {
    const root = document.documentElement;
    root.setAttribute('data-theme', skin);
    root.classList.remove('dark', 'light', 'retro', 'soap', 'arena', 'championship', 'attitude', 'lucha', 'indie', 'puroresu', 'nxt');
    root.classList.add(skin);
  }, [skin]);

  const setSkin = (newSkin: Skin) => {
    setSkinState(newSkin);
    localStorage.setItem(storageKey, newSkin);
  };

  const toggleSkin = () => {
    const skins: Skin[] = ['dark', 'light', 'retro', 'soap', 'arena', 'championship', 'attitude', 'lucha', 'indie', 'puroresu', 'nxt'];
    const next = skins[(skins.indexOf(skin) + 1) % skins.length];
    setSkin(next);
  };

  return (
    <SkinContext.Provider value={{ skin, setSkin, toggleSkin }}>
      {children}
    </SkinContext.Provider>
  );
}