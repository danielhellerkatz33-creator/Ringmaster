"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

export type Language = "de" | "en"

export interface Translations {
  // Main Menu
  mainMenu: {
    title: string
    subtitle: string
    currentSeries: string
    newGame: string
    newGameStarting: string
    loadGame: string
    loadGameLoading: string
    confirmNewGame: string
    confirmNewGameMessage: string
    errorNewGame: string
    errorSelectJson: string
    errorLoadGame: string
    errorLoadGameMessage: string
  }

  // Navigation
  navigation: {
    mainMenu: string
    dashboard: string
    characters: string
    relationships: string
    arcs: string
    storylines: string
    scenes: string
    episodes: string
    deploymentPlanning: string
    booking: string
    storySummaries: string
    characterAnalysis: string
    storyAnalysis: string
    settings: string
    statsFormat: string
  }

  // Dashboard
  dashboard: {
    loading: string
    welcomeTitle: string
    welcomeDescription: string
    createSeries: string
    characters: string
    relationships: string
    storylines: string
    episodes: string
    charactersCreated: string
    relationshipsDefined: string
    activeStorylines: string
    episodesInProgress: string
    quickActions: string
    createCharacter: string
    createStoryline: string
    writeScene: string
    planEpisode: string
    recentCharacters: string
    showAll: string
    noCharacters: string
    activeStorylinesTitle: string
    noActiveStorylines: string
    charactersCount: string
    characterArcs: string
    noCharacterArcs: string
    unknownCharacter: string
    active: string
  }

  // Characters
  characters: {
    formTitle: string
    editTitle: string
    createTitle: string
    name: string
    position: string
    alignment: string
    status: string
    description: string
    backstory: string
    traits: string
    addTrait: string
    image: string
    uploadImage: string
    changeImage: string
    imageRequirements: string
    storedInIndexedDB: string
    fallbackBase64: string
    preview: string
    imageTooLarge: string
    save: string
    cancel: string
    create: string
    editDescription: string
    createDescription: string
    namePlaceholder: string
    descriptionPlaceholder: string
    backstoryPlaceholder: string
    traitPlaceholder: string
    positions: {
      main_event: string
      upper_card: string
      mid_card: string
      lower_card: string
      jobber: string
      road_agent: string
      manager: string
      staff: string
      commentary: string
      referee: string
    }
    alignments: {
      face: string
      heel: string
      tweener: string
    }
    statuses: {
      active: string
      injured: string
      suspended: string
      retired: string
      inactive: string
    }
  }

  // Scenes
  scenes: {
    formTitle: string
    editTitle: string
    createTitle: string
    title: string
    description: string
    location: string
    mood: string
    timeOfDay: string
    notes: string
    duration: string
    durationMinutes: string
    storyline: string
    characters: string
    save: string
    cancel: string
    timesOfDay: {
      morning: string
      afternoon: string
      evening: string
      night: string
    }
    editDescription: string
    createDescription: string
    titlePlaceholder: string
    descriptionPlaceholder: string
    locationPlaceholder: string
    moodPlaceholder: string
    notesPlaceholder: string
    noLocationsAvailable: string
    noMoodsAvailable: string
    selectCharacters: string
    selectStoryline: string
  }

  // Episodes
  episodes: {
    formTitle: string
    editTitle: string
    createTitle: string
    seasonNumber: string
    episodeNumber: string
    title: string
    synopsis: string
    status: string
    notes: string
    airDate: string
    image: string
    save: string
    cancel: string
    statuses: {
      planning: string
      writing: string
      filming: string
      editing: string
      aired: string
    }
    editDescription: string
    createDescription: string
    season: string
    episode: string
    uploadImage: string
    changeImage: string
    imageRequirements: string
    preview: string
    imageTooLarge: string
  }

  // Relationships
  relationships: {
    formTitle: string
    editTitle: string
    createTitle: string
    character1: string
    character2: string
    type: string
    description: string
    strength: string
    save: string
    cancel: string
    types: {
      tag_team: string
      stable: string
      manager: string
      rivalry: string
      friendship: string
    }
    editDescription: string
    createDescription: string
    selectCharacter: string
    relationshipStrength: string
    veryWeak: string
    weak: string
    moderate: string
    strong: string
    veryStrong: string
  }

  // Storylines
  storylines: {
    formTitle: string
    editTitle: string
    createTitle: string
    title: string
    description: string
    type: string
    characterIds: string
    color: string
    status: string
    save: string
    cancel: string
    types: {
      main: string
      subplot: string
    }
    statuses: {
      active: string
      completed: string
      paused: string
    }
    colors: {
      lightRed: string
      orange: string
      yellow: string
      lightGreen: string
      turquoise: string
      skyBlue: string
      darkBlue: string
      navy: string
      purple: string
      magenta: string
      pink: string
      fuchsia: string
      brown: string
      oliveGreen: string
      gray: string
      white: string
    }
  }

  // Save Button
  saveButton: {
    title: string
    successTitle: string
    successDescription: string
    errorTitle: string
    errorDescription: string
  }

  // Common UI Elements
  common: {
    loading: string
    error: string
    save: string
    cancel: string
    delete: string
    edit: string
    add: string
    remove: string
    yes: string
    no: string
    ok: string
    close: string
    characters: string
    episodes: string
    scenes: string
    storylines: string
    relationships: string
    arcs: string
    search: string
    filter: string
    sort: string
    sortBy: string
    show: string
    hide: string
    open: string
    create: string
    new: string
    empty: string
    none: string
    all: string
    select: string
    selected: string
    available: string
    intensity: string
    weak: string
    strong: string
    stories: string
    description: string
    background: string
    traits: string
    notes: string
    duration: string
    minutes: string
    date: string
    status: string
    type: string
    color: string
    upload: string
    image: string
    title: string
    copy: string
    copied: string
    paste: string
    generate: string
    confirm: string
    warning: string
    info: string
    help: string
    of: string
    from: string
    to: string
    by: string
    at: string
    in: string
    on: string
    with: string
    for: string
    and: string
    or: string
  }

  // UI States and Messages
  ui: {
    loadingStates: {
      loading: string
      saving: string
      deleting: string
      creating: string
      updating: string
      uploading: string
      exporting: string
      importing: string
      generating: string
    }
    emptyStates: {
      noCharacters: string
      noScenes: string
      noEpisodes: string
      noStorylines: string
      noRelationships: string
      noArcs: string
      noResults: string
      noData: string
      createFirst: string
      noCharacterReviews: string
    }
    placeholders: {
      search: string
      select: string
      enterText: string
      enterDescription: string
      enterNotes: string
      chooseFile: string
    }
    confirmations: {
      deleteItem: string
      deleteCharacter: string
      deleteScene: string
      deleteEpisode: string
      deleteStoryline: string
      deleteRelationship: string
      replaceData: string
      generateScenes: string
    }
    errors: {
      required: string
      invalid: string
      notFound: string
      network: string
      fileTooLarge: string
      unsupportedFile: string
      indexedDBUnavailable: string
      importFailed: string
      exportFailed: string
    }
    success: {
      saved: string
      deleted: string
      created: string
      updated: string
      imported: string
      exported: string
      copied: string
    }
  }

  // Upgrade Modal
  upgradeModal: {
    title: string
    loginTitle: string
    loginDescription: string
    wrestlersLimit: string
    storylinesLimit: string
    segmentsLimit: string
    eventsLimit: string
    currentStatus: string
    proFeatures: string
    unlimitedWrestlers: string
    unlimitedStorylines: string
    unlimitedSegments: string
    unlimitedEvents: string
    futureFeatures: string
    pricing: string
    oneTimePayment: string
    login: string
    later: string
    upgradeNow: string
    developerModeActive: string
    developerModeDescription: string
    futureLoginNotice: string
  }

  // Dashboard specific
  dashboardStats: {
    wrestlers: string
    relationships: string
    storylines: string
    events: string
    created: string
    defined: string
    active: string
    inPlanning: string
    quickActions: string
    recentWrestlers: string
    activeStorylines: string
    championships: string
    showAll: string
    noCharacters: string
    noActiveStorylines: string
    noChampionships: string
    unknown: string
  }
}

const germanTranslations: Translations = {
  mainMenu: {
    title: "RINGMASTER",
    subtitle: "HAUPTMENÜ",
    currentSeries: "AKTUELLE PROMOTION:",
    newGame: "NEUES SPIEL STARTEN",
    newGameStarting: "STARTE NEUES SPIEL...",
    loadGame: "SAVEGAME LADEN",
    loadGameLoading: "LADE SAVEGAME...",
    confirmNewGame: "Neues Spiel starten?",
    confirmNewGameMessage: "Bist du sicher, dass du ein neues Spiel starten möchtest? Alle aktuellen Daten gehen verloren!",
    errorNewGame: "Fehler beim Starten eines neuen Spiels. Bitte versuche es erneut.",
    errorSelectJson: "Bitte wähle eine .json-Datei aus.",
    errorLoadGame: "Fehler beim Laden des Savegames",
    errorLoadGameMessage: "Fehler beim Laden des Savegames. Bitte versuche es erneut.",
  },

  navigation: {
    mainMenu: "Hauptmenü",
    dashboard: "Dashboard",
    characters: "Wrestler",
    relationships: "Beziehungen",
    arcs: "Championships",
    storylines: "Storylines",
    scenes: "Segmente",
    episodes: "Events",
    deploymentPlanning: "Roster Management",
    booking: "Segment History",
    storySummaries: "Storyline Wrap-Up",
    characterAnalysis: "Character History",
    storyAnalysis: "Story Continuation Ideas",
    settings: "Einstellungen",
    statsFormat: "{{characters}} Wrestler | {{episodes}} Events",
  },

  dashboard: {
    loading: "Lädt...",
    welcomeTitle: "Willkommen bei Ringmaster",
    welcomeDescription: "Erstelle deine erste Promotion um mit der Planung von Wrestlern, Storylines und Events zu beginnen.",
    createSeries: "Neue Promotion erstellen",
    characters: "Wrestler",
    relationships: "Beziehungen",
    storylines: "Storylines",
    episodes: "Events",
    charactersCreated: "Angelegt",
    relationshipsDefined: "Definiert",
    activeStorylines: "aktiv",
    episodesInProgress: "in Planung",
    quickActions: "Schnellaktionen",
    createCharacter: "Wrestler anlegen",
    createStoryline: "Storyline erstellen",
    writeScene: "Segment erstellen",
    planEpisode: "Event planen",
    recentCharacters: "Neueste Wrestler",
    showAll: "Alle anzeigen",
    noCharacters: "Noch keine Wrestler angelegt.",
    activeStorylinesTitle: "Aktive Storylines",
    noActiveStorylines: "Keine aktiven Storylines.",
    charactersCount: "Wrestler",
    characterArcs: "Championships",
    noCharacterArcs: "Noch keine Championships definiert.",
    unknownCharacter: "Unbekannt",
    active: "aktiv",
  },

  characters: {
    formTitle: "Wrestler",
    editTitle: "Wrestler bearbeiten",
    createTitle: "Neuer Wrestler",
    name: "Name",
    position: "Position",
    alignment: "Alignment",
    status: "Status",
    description: "Beschreibung",
    backstory: "Hintergrundgeschichte",
    traits: "Charaktereigenschaften",
    addTrait: "Hinzufügen",
    image: "Bild",
    uploadImage: "Bild hochladen",
    changeImage: "Bild ändern",
    imageRequirements: "JPG, PNG oder GIF. Max 5MB.",
    storedInIndexedDB: "Gespeichert in IndexedDB.",
    fallbackBase64: "Fallback: Base64.",
    preview: "Vorschau",
    imageTooLarge: "Bild ist zu groß. Maximale Größe: 5MB",
    save: "Speichern",
    cancel: "Abbrechen",
    create: "Erstellen",
    editDescription: "Bearbeite die Details dieses Wrestlers.",
    createDescription: "Erstelle einen neuen Wrestler für deine Promotion.",
    namePlaceholder: "z.B. The Rock",
    descriptionPlaceholder: "Eine kurze Beschreibung des Wrestlers...",
    backstoryPlaceholder: "Die Geschichte und Vergangenheit des Wrestlers...",
    traitPlaceholder: "z.B. charismatisch, athletisch...",
    positions: {
      main_event: "Main Event",
      upper_card: "Upper Card",
      mid_card: "Mid Card",
      lower_card: "Lower Card",
      jobber: "Jobber",
      road_agent: "Road Agent",
      manager: "Manager",
      staff: "Staff",
      commentary: "Commentary",
      referee: "Referee",
    },
    alignments: {
      face: "Face",
      heel: "Heel",
      tweener: "Tweener",
    },
    statuses: {
      active: "Aktiv",
      injured: "Verletzt",
      suspended: "Gesperrt",
      retired: "Im Ruhestand",
      inactive: "Inaktiv",
    },
  },

  scenes: {
    formTitle: "Segment",
    editTitle: "Segment bearbeiten",
    createTitle: "Neues Segment erstellen",
    title: "Titel",
    description: "Beschreibung",
    location: "Ort",
    mood: "Stimmung",
    timeOfDay: "Tageszeit",
    notes: "Notizen",
    duration: "Dauer",
    durationMinutes: "Minuten",
    storyline: "Storyline",
    characters: "Wrestlers",
    save: "Speichern",
    cancel: "Abbrechen",
    timesOfDay: {
      morning: "Morgen",
      afternoon: "Nachmittag",
      evening: "Abend",
      night: "Nacht",
    },
    editDescription: "Bearbeite die Details dieses Segments.",
    createDescription: "Erstelle ein neues Segment für dein Event.",
    titlePlaceholder: "z.B. Championship Match",
    descriptionPlaceholder: "Beschreibe was in diesem Segment passiert...",
    locationPlaceholder: "z.B. Ring",
    moodPlaceholder: "z.B. Spannend, Intensiv",
    notesPlaceholder: "Zusätzliche Notizen zum Segment...",
    noLocationsAvailable: "Keine Orte verfügbar",
    noMoodsAvailable: "Keine Stimmungen verfügbar",
    selectCharacters: "Wrestler auswählen",
    selectStoryline: "Storyline auswählen",
  },

  episodes: {
    formTitle: "Event",
    editTitle: "Event bearbeiten",
    createTitle: "Neues Event erstellen",
    seasonNumber: "Tour-Nummer",
    episodeNumber: "Event-Nummer",
    title: "Titel",
    synopsis: "Zusammenfassung",
    status: "Status",
    notes: "Notizen",
    airDate: "Event-Datum",
    image: "Bild",
    save: "Speichern",
    cancel: "Abbrechen",
    statuses: {
      planning: "Planung",
      writing: "In Arbeit",
      filming: "Produktion",
      editing: "Post-Produktion",
      aired: "Abgeschlossen",
    },
    editDescription: "Bearbeite die Details dieses Events.",
    createDescription: "Erstelle ein neues Event für deine Promotion.",
    season: "Tour",
    episode: "Event",
    uploadImage: "Bild hochladen",
    changeImage: "Bild ändern",
    imageRequirements: "JPG, PNG oder GIF. Max 5MB.",
    preview: "Vorschau",
    imageTooLarge: "Bild ist zu groß. Maximale Größe: 5MB",
  },

  relationships: {
    formTitle: "Beziehung",
    editTitle: "Beziehung bearbeiten",
    createTitle: "Neue Beziehung erstellen",
    character1: "Wrestler 1",
    character2: "Wrestler 2",
    type: "Beziehungstyp",
    description: "Beschreibung",
    strength: "Stärke",
    save: "Speichern",
    cancel: "Abbrechen",
    types: {
      tag_team: "Tag Team",
      stable: "Stable",
      manager: "Manager",
      rivalry: "Rivalität",
      friendship: "Freundschaft",
    },
    editDescription: "Bearbeite die Details dieser Beziehung.",
    createDescription: "Erstelle eine neue Beziehung zwischen Wrestlern.",
    selectCharacter: "Wrestler auswählen",
    relationshipStrength: "Beziehungsstärke",
    veryWeak: "Sehr schwach",
    weak: "Schwach",
    moderate: "Moderat",
    strong: "Stark",
    veryStrong: "Sehr stark",
  },

  storylines: {
    formTitle: "Storyline",
    editTitle: "Storyline bearbeiten",
    createTitle: "Neue Storyline",
    title: "Titel",
    description: "Beschreibung",
    type: "Typ",
    characterIds: "Wrestler",
    color: "Farbe",
    status: "Status",
    save: "Speichern",
    cancel: "Abbrechen",
    types: {
      main: "Main Story",
      subplot: "Side Story",
    },
    statuses: {
      active: "Aktiv",
      completed: "Abgeschlossen",
      paused: "Pausiert",
    },
    colors: {
      lightRed: "Hellrot",
      orange: "Orange",
      yellow: "Gelb",
      lightGreen: "Hellgrün",
      turquoise: "Türkis",
      skyBlue: "Himmelblau",
      darkBlue: "Dunkelblau",
      navy: "Navy",
      purple: "Lila",
      magenta: "Magenta",
      pink: "Pink",
      fuchsia: "Fuchsia",
      brown: "Braun",
      oliveGreen: "Olivgrün",
      gray: "Grau",
      white: "Weiß",
    },
  },

  saveButton: {
    title: "Speichern",
    successTitle: "Gespeichert!",
    successDescription: "Ihr Ringmaster wurde erfolgreich gespeichert.",
    errorTitle: "Fehler beim Speichern",
    errorDescription: "Speichern fehlgeschlagen. Bitte versuchen Sie es erneut.",
  },

  common: {
    loading: "Lädt...",
    error: "Fehler",
    save: "Speichern",
    cancel: "Abbrechen",
    delete: "Löschen",
    edit: "Bearbeiten",
    add: "Hinzufügen",
    remove: "Entfernen",
    yes: "Ja",
    no: "Nein",
    ok: "OK",
    close: "Schließen",
    characters: "Wrestler",
    episodes: "Events",
    scenes: "Segmente",
    storylines: "Storylines",
    relationships: "Beziehungen",
    arcs: "Championships",
    search: "Suchen",
    filter: "Filtern",
    sort: "Sortieren",
    sortBy: "Sortieren nach",
    show: "Anzeigen",
    hide: "Verstecken",
    open: "Öffnen",
    create: "Erstellen",
    new: "Neu",
    empty: "Leer",
    none: "Keine",
    all: "Alle",
    select: "Auswählen",
    selected: "Ausgewählt",
    available: "Verfügbar",
    intensity: "Intensität",
    weak: "Schwach",
    strong: "Stark",
    stories: "Stories",
    description: "Beschreibung",
    background: "Hintergrund",
    traits: "Eigenschaften",
    notes: "Notizen",
    duration: "Dauer",
    minutes: "Minuten",
    date: "Datum",
    status: "Status",
    type: "Typ",
    color: "Farbe",
    upload: "Hochladen",
    image: "Bild",
    title: "Titel",
    copy: "Kopieren",
    copied: "Kopiert",
    paste: "Einfügen",
    generate: "Generieren",
    confirm: "Bestätigen",
    warning: "Warnung",
    info: "Info",
    help: "Hilfe",
    of: "von",
    from: "von",
    to: "bis",
    by: "nach",
    at: "bei",
    in: "in",
    on: "auf",
    with: "mit",
    for: "für",
    and: "und",
    or: "oder",
  },

  ui: {
    loadingStates: {
      loading: "Lädt...",
      saving: "Speichert...",
      deleting: "Löscht...",
      creating: "Erstellt...",
      updating: "Aktualisiert...",
      uploading: "Lädt hoch...",
      exporting: "Exportiert...",
      importing: "Importiert...",
      generating: "Generiert...",
    },
    emptyStates: {
      noCharacters: "Keine Wrestler vorhanden.",
      noScenes: "Keine Segmente vorhanden.",
      noEpisodes: "Keine Events vorhanden.",
      noStorylines: "Keine Storylines vorhanden.",
      noRelationships: "Keine Beziehungen vorhanden.",
      noArcs: "Keine Championships vorhanden.",
      noResults: "Keine Ergebnisse gefunden.",
      noData: "Keine Daten verfügbar.",
      createFirst: "Erstelle zuerst welche.",
      noCharacterReviews: "Keine abgeschlossenen Storylines mit Charakterrückblicken für diesen Charakter.",
    },
    placeholders: {
      search: "Suchen...",
      select: "Auswählen...",
      enterText: "Text eingeben...",
      enterDescription: "Beschreibung eingeben...",
      enterNotes: "Notizen eingeben...",
      chooseFile: "Datei auswählen...",
    },
    confirmations: {
      deleteItem: "Möchten Sie dieses Element wirklich löschen?",
      deleteCharacter: "Möchten Sie diesen Wrestler wirklich löschen?",
      deleteScene: "Möchten Sie dieses Segment wirklich löschen?",
      deleteEpisode: "Möchten Sie dieses Event wirklich löschen?",
      deleteStoryline: "Möchten Sie diese Storyline wirklich löschen?",
      deleteRelationship: "Möchten Sie diese Beziehung wirklich löschen?",
      replaceData: "Der Import ersetzt alle aktuellen Daten vollständig.",
      generateScenes: "Möchten Sie Segmente generieren?",
    },
    errors: {
      required: "Dieses Feld ist erforderlich.",
      invalid: "Ungültige Eingabe.",
      notFound: "Nicht gefunden.",
      network: "Netzwerkfehler.",
      fileTooLarge: "Datei ist zu groß.",
      unsupportedFile: "Nicht unterstützter Dateityp.",
      indexedDBUnavailable: "IndexedDB ist nicht verfügbar.",
      importFailed: "Import fehlgeschlagen.",
      exportFailed: "Export fehlgeschlagen.",
    },
    success: {
      saved: "Erfolgreich gespeichert.",
      deleted: "Erfolgreich gelöscht.",
      created: "Erfolgreich erstellt.",
      updated: "Erfolgreich aktualisiert.",
      imported: "Erfolgreich importiert.",
      exported: "Erfolgreich exportiert.",
      copied: "In Zwischenablage kopiert.",
    },
  },
}

const englishTranslations: Translations = {
  mainMenu: {
    title: "RINGMASTER",
    subtitle: "MAIN MENU",
    currentSeries: "CURRENT PROMOTION:",
    newGame: "START NEW GAME",
    newGameStarting: "STARTING NEW GAME...",
    loadGame: "LOAD SAVEGAME",
    loadGameLoading: "LOADING SAVEGAME...",
    confirmNewGame: "Start new game?",
    confirmNewGameMessage: "Are you sure you want to start a new game? All current data will be lost!",
    errorNewGame: "Error starting new game. Please try again.",
    errorSelectJson: "Please select a .json file.",
    errorLoadGame: "Error loading savegame",
    errorLoadGameMessage: "Error loading savegame. Please try again.",
  },

  navigation: {
    mainMenu: "Main Menu",
    dashboard: "Dashboard",
    characters: "Wrestlers",
    relationships: "Relationships",
    arcs: "Championships",
    storylines: "Storylines",
    scenes: "Segments",
    episodes: "Events",
    deploymentPlanning: "Roster Management",
    booking: "Segment History",
    storySummaries: "Storyline Wrap-Up",
    characterAnalysis: "Character History",
    storyAnalysis: "Story Continuation Ideas",
    settings: "Settings",
    statsFormat: "{{characters}} Wrestlers | {{episodes}} Events",
  },

  dashboard: {
    loading: "Loading...",
    welcomeTitle: "Welcome to Ringmaster",
    welcomeDescription: "Create your first promotion to start planning wrestlers, storylines and events.",
    createSeries: "Create New Promotion",
    characters: "Wrestlers",
    relationships: "Relationships",
    storylines: "Storylines",
    episodes: "Events",
    charactersCreated: "Created",
    relationshipsDefined: "Defined",
    activeStorylines: "active",
    episodesInProgress: "in planning",
    quickActions: "Quick Actions",
    createCharacter: "Create Wrestler",
    createStoryline: "Create Storyline",
    writeScene: "Create Segment",
    planEpisode: "Plan Event",
    recentCharacters: "Recent Wrestlers",
    showAll: "Show All",
    noCharacters: "No wrestlers created yet.",
    activeStorylinesTitle: "Active Storylines",
    noActiveStorylines: "No active storylines.",
    charactersCount: "Wrestlers",
    characterArcs: "Championships",
    noCharacterArcs: "No championships defined yet.",
    unknownCharacter: "Unknown",
    active: "active",
  },

  characters: {
    formTitle: "Wrestler",
    editTitle: "Edit Wrestler",
    createTitle: "New Wrestler",
    name: "Name",
    position: "Position",
    alignment: "Alignment",
    status: "Status",
    description: "Description",
    backstory: "Backstory",
    traits: "Character Traits",
    addTrait: "Add",
    image: "Image",
    uploadImage: "Upload Image",
    changeImage: "Change Image",
    imageRequirements: "JPG, PNG or GIF. Max 5MB.",
    storedInIndexedDB: "Stored in IndexedDB.",
    fallbackBase64: "Fallback: Base64.",
    preview: "Preview",
    imageTooLarge: "Image is too large. Maximum size: 5MB",
    save: "Save",
    cancel: "Cancel",
    create: "Create",
    editDescription: "Edit the details of this character.",
    createDescription: "Create a new wrestler for your promotion.",
    namePlaceholder: "e.g. The Rock",
    descriptionPlaceholder: "A brief description of the wrestler...",
    backstoryPlaceholder: "The wrestler's story and past...",
    traitPlaceholder: "e.g. charismatic, athletic...",
    positions: {
      main_event: "Main Event",
      upper_card: "Upper Card",
      mid_card: "Mid Card",
      lower_card: "Lower Card",
      jobber: "Jobber",
      road_agent: "Road Agent",
      manager: "Manager",
      staff: "Staff",
      commentary: "Commentary",
      referee: "Referee",
    },
    alignments: {
      face: "Face",
      heel: "Heel",
      tweener: "Tweener",
    },
    statuses: {
      active: "Active",
      injured: "Injured",
      suspended: "Suspended",
      retired: "Retired",
      inactive: "Inactive",
    },
  },

  scenes: {
    formTitle: "Segment",
    editTitle: "Edit Segment",
    createTitle: "Create New Segment",
    title: "Title",
    description: "Description",
    location: "Location",
    mood: "Mood",
    timeOfDay: "Time of Day",
    notes: "Notes",
    duration: "Duration",
    durationMinutes: "minutes",
    storyline: "Storyline",
    characters: "Wrestlers",
    save: "Save",
    cancel: "Cancel",
    timesOfDay: {
      morning: "Morning",
      afternoon: "Afternoon",
      evening: "Evening",
      night: "Night",
    },
    editDescription: "Edit the details of this segment.",
    createDescription: "Create a new segment for your event.",
    titlePlaceholder: "e.g. Championship Match",
    descriptionPlaceholder: "Describe what happens in this segment...",
    locationPlaceholder: "e.g. Ring",
    moodPlaceholder: "e.g. Intense, Dramatic",
    notesPlaceholder: "Additional notes about the segment...",
    noLocationsAvailable: "No locations available",
    noMoodsAvailable: "No moods available",
    selectCharacters: "Select Wrestlers",
    selectStoryline: "Select Storyline",
  },

  episodes: {
    formTitle: "Event",
    editTitle: "Edit Event",
    createTitle: "Create New Event",
    seasonNumber: "Tour Number",
    episodeNumber: "Event Number",
    title: "Title",
    synopsis: "Synopsis",
    status: "Status",
    notes: "Notes",
    airDate: "Event Date",
    image: "Image",
    save: "Save",
    cancel: "Cancel",
    statuses: {
      planning: "Planning",
      writing: "In Progress",
      filming: "Production",
      editing: "Post-Production",
      aired: "Completed",
    },
    editDescription: "Edit the details of this event.",
    createDescription: "Create a new event for your promotion.",
    season: "Tour",
    episode: "Event",
    uploadImage: "Upload Image",
    changeImage: "Change Image",
    imageRequirements: "JPG, PNG or GIF. Max 5MB.",
    preview: "Preview",
    imageTooLarge: "Image is too large. Maximum size: 5MB",
  },

  relationships: {
    formTitle: "Relationship",
    editTitle: "Edit Relationship",
    createTitle: "Create New Relationship",
    character1: "Wrestler 1",
    character2: "Wrestler 2",
    type: "Relationship Type",
    description: "Description",
    strength: "Strength",
    save: "Save",
    cancel: "Cancel",
    types: {
      tag_team: "Tag Team",
      stable: "Stable",
      manager: "Manager",
      rivalry: "Rivalry",
      friendship: "Friendship",
    },
    editDescription: "Edit the details of this relationship.",
    createDescription: "Create a new relationship between wrestlers.",
    selectCharacter: "Select Wrestler",
    relationshipStrength: "Relationship Strength",
    veryWeak: "Very Weak",
    weak: "Weak",
    moderate: "Moderate",
    strong: "Strong",
    veryStrong: "Very Strong",
  },

  storylines: {
    formTitle: "Storyline",
    editTitle: "Edit Storyline",
    createTitle: "New Storyline",
    title: "Title",
    description: "Description",
    type: "Type",
    characterIds: "Wrestlers",
    color: "Color",
    status: "Status",
    save: "Save",
    cancel: "Cancel",
    types: {
      main: "Main Story",
      subplot: "Side Story",
    },
    statuses: {
      active: "Active",
      completed: "Completed",
      paused: "Paused",
    },
    colors: {
      lightRed: "Light Red",
      orange: "Orange",
      yellow: "Yellow",
      lightGreen: "Light Green",
      turquoise: "Turquoise",
      skyBlue: "Sky Blue",
      darkBlue: "Dark Blue",
      navy: "Navy",
      purple: "Purple",
      magenta: "Magenta",
      pink: "Pink",
      fuchsia: "Fuchsia",
      brown: "Brown",
      oliveGreen: "Olive Green",
      gray: "Gray",
      white: "White",
    },
  },

  saveButton: {
    title: "Save",
    successTitle: "Saved!",
    successDescription: "Your Ringmaster has been successfully saved.",
    errorTitle: "Save Error",
    errorDescription: "Saving failed. Please try again.",
  },

  common: {
    loading: "Loading...",
    error: "Error",
    save: "Save",
    cancel: "Cancel",
    delete: "Delete",
    edit: "Edit",
    add: "Add",
    remove: "Remove",
    yes: "Yes",
    no: "No",
    ok: "OK",
    close: "Close",
    characters: "Wrestlers",
    episodes: "Events",
    scenes: "Segments",
    storylines: "Storylines",
    relationships: "Relationships",
    arcs: "Championships",
    search: "Search",
    filter: "Filter",
    sort: "Sort",
    sortBy: "Sort by",
    show: "Show",
    hide: "Hide",
    open: "Open",
    create: "Create",
    new: "New",
    empty: "Empty",
    none: "None",
    all: "All",
    select: "Select",
    selected: "Selected",
    available: "Available",
    intensity: "Intensity",
    weak: "Weak",
    strong: "Strong",
    stories: "Stories",
    description: "Description",
    background: "Background",
    traits: "Traits",
    notes: "Notes",
    duration: "Duration",
    minutes: "minutes",
    date: "Date",
    status: "Status",
    type: "Type",
    color: "Color",
    upload: "Upload",
    image: "Image",
    title: "Title",
    copy: "Copy",
    copied: "Copied",
    paste: "Paste",
    generate: "Generate",
    confirm: "Confirm",
    warning: "Warning",
    info: "Info",
    help: "Help",
    of: "of",
    from: "from",
    to: "to",
    by: "by",
    at: "at",
    in: "in",
    on: "on",
    with: "with",
    for: "for",
    and: "and",
    or: "or",
  },

  ui: {
    loadingStates: {
      loading: "Loading...",
      saving: "Saving...",
      deleting: "Deleting...",
      creating: "Creating...",
      updating: "Updating...",
      uploading: "Uploading...",
      exporting: "Exporting...",
      importing: "Importing...",
      generating: "Generating...",
    },
    emptyStates: {
      noCharacters: "No wrestlers available.",
      noScenes: "No segments available.",
      noEpisodes: "No events available.",
      noStorylines: "No storylines available.",
      noRelationships: "No relationships available.",
      noArcs: "No character arcs available.",
      noResults: "No results found.",
      noData: "No data available.",
      createFirst: "Create some first.",
      noCharacterReviews: "No completed storylines with character reviews for this character.",
    },
    placeholders: {
      search: "Search...",
      select: "Select...",
      enterText: "Enter text...",
      enterDescription: "Enter description...",
      enterNotes: "Enter notes...",
      chooseFile: "Choose file...",
    },
    confirmations: {
      deleteItem: "Are you sure you want to delete this item?",
      deleteCharacter: "Delete this wrestler?",
      deleteScene: "Delete this segment?",
      deleteEpisode: "Delete this event?",
      deleteStoryline: "Are you sure you want to delete this storyline?",
      deleteRelationship: "Are you sure you want to delete this relationship?",
      replaceData: "Import will completely replace all current data.",
      generateScenes: "Generate segments?",
    },
    errors: {
      required: "This field is required.",
      invalid: "Invalid input.",
      notFound: "Not found.",
      network: "Network error.",
      fileTooLarge: "File is too large.",
      unsupportedFile: "Unsupported file type.",
      indexedDBUnavailable: "IndexedDB is not available.",
      importFailed: "Import failed.",
      exportFailed: "Export failed.",
    },
    success: {
      saved: "Successfully saved.",
      deleted: "Successfully deleted.",
      created: "Successfully created.",
      updated: "Successfully updated.",
      imported: "Successfully imported.",
      exported: "Successfully exported.",
      copied: "Copied to clipboard.",
    },
  },
}

const translations: Record<Language, Translations> = {
  de: germanTranslations,
  en: englishTranslations,
}

interface LanguageContextType {
  language: Language
  setLanguage: (language: Language) => void
  t: Translations
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>("de")

  useEffect(() => {
    // Load language from localStorage
    const savedLanguage = localStorage.getItem("ringmaster-language") as Language
    if (savedLanguage && (savedLanguage === "de" || savedLanguage === "en")) {
      setLanguage(savedLanguage)
    }
  }, [])

  useEffect(() => {
    // Save language to localStorage
    localStorage.setItem("ringmaster-language", language)

    // Update document language
    document.documentElement.lang = language
  }, [language])

  const value = {
    language,
    setLanguage,
    t: translations[language],
  }

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  )
}

export function useLanguage() {
  const context = useContext(LanguageContext)
  if (context === undefined) {
    throw new Error("useLanguage must be used within a LanguageProvider")
  }
  return context
}