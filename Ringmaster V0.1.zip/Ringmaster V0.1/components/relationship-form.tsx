"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Checkbox } from "@/components/ui/checkbox"
import { Badge } from "@/components/ui/badge"
import { useSeries } from "@/lib/series-context"
import type { Relationship } from "@/lib/types"

interface RelationshipFormProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  relationship?: Relationship
}

const typeLabels: Record<Relationship["type"], string> = {
  tag_team: "Tag Team",
  stable: "Stable",
  manager: "Manager",
  rivalry: "Rivalität",
  friendship: "Freundschaft",
  // romantic: "Romanze",
  // "ex-romantic": "Ex-Romanze",
  // family: "Familie",
  // professional: "Professionell",
  // enemy: "Feindschaft"
}

export function RelationshipForm({ open, onOpenChange, relationship }: RelationshipFormProps) {
  const { data, addRelationship, updateRelationship } = useSeries()
  const [characterIds, setCharacterIds] = useState<string[]>([])
  const [type, setType] = useState<Relationship["type"]>("tag_team")
  const [description, setDescription] = useState("")
  const [intensity, setIntensity] = useState(5)
  const [teamName, setTeamName] = useState("")
  const [isActive, setIsActive] = useState(true)

  const isEditing = !!relationship

  useEffect(() => {
    if (relationship) {
      setCharacterIds(relationship.characterIds)
      setType(relationship.type)
      setDescription(relationship.description)
      setIntensity(relationship.intensity)
      setTeamName(relationship.teamName || "")
      setIsActive(relationship.isActive ?? true)
    } else {
      resetForm()
    }
  }, [relationship, open])

  const resetForm = () => {
    setCharacterIds([])
    setType("tag_team")
    setDescription("")
    setIntensity(5)
    setTeamName("")
    setIsActive(true)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    // Validierung je nach Typ (nur für neue Beziehungen)
    if (!isEditing) {
      const minMembers = type === "stable" ? 2 : 2
      if ((characterIds?.length || 0) < minMembers) return
      
      // Für Tag Teams und Manager: genau 2 erforderlich
      if ((type === "tag_team" || type === "manager") && (characterIds?.length || 0) !== 2) return
      
      // Für andere Typen: mindestens 1 erforderlich
      if ((type === "rivalry" || type === "friendship") && 
          (characterIds?.length || 0) < 1) return
    }

    const relationshipData = {
      characterIds: characterIds || [],
      type,
      description: description.trim(),
      intensity,
      episodes: relationship?.episodes || [],
      evolution: relationship?.evolution || [],
      teamName: (type === "tag_team" || type === "stable") ? teamName.trim() : undefined,
      isActive: (type === "tag_team" || type === "stable") ? isActive : undefined,
    }

    if (isEditing) {
      updateRelationship({
        ...relationship,
        ...relationshipData,
      })
    } else {
      addRelationship(relationshipData)
    }

    onOpenChange(false)
  }

  // Get available characters (not already selected) and sort alphabetically
  const availableCharacters = data.characters
    .filter((c) => !(characterIds || []).includes(c.id))
    .sort((a, b) => a.name.localeCompare(b.name))

  // Helper to add/remove character
  const addCharacter = (characterId: string) => {
    // Wrestling-Typen haben Limits
    if (type === "tag_team" && (characterIds?.length || 0) >= 2) return
    if (type === "manager" && (characterIds?.length || 0) >= 2) return
    // Stables können beliebig viele Mitglieder haben
    // Andere Typen (enemy, friendship, etc.) können beliebig viele Mitglieder haben
    setCharacterIds(prev => [...(prev || []), characterId])
  }

  const removeCharacter = (characterId: string) => {
    setCharacterIds(prev => (prev || []).filter(id => id !== characterId))
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{isEditing ? "Beziehung bearbeiten" : "Neue Beziehung erstellen"}</DialogTitle>
          <DialogDescription>
            {isEditing
              ? "Bearbeite die Details dieser Charakterbeziehung."
              : `Erstelle eine neue ${typeLabels[type]} Beziehung.`}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Typ-Auswahl */}
          <div className="space-y-2">
            <Label>Art der Beziehung</Label>
            <Select value={type} onValueChange={(v) => {
              setType(v as Relationship["type"])
              setCharacterIds([]) // Reset characters when type changes
            }}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(typeLabels).map(([value, label]) => (
                  <SelectItem key={value} value={value}>
                    {label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Charakter-Auswahl */}
          <div className="space-y-2">
            <Label>
              {type === "stable" ? "Stable-Mitglieder" : 
               type === "tag_team" ? "Tag Team Partner" : 
               type === "manager" ? "Wrestler & Manager" :
               "Beteiligte Charaktere"}
            </Label>
            
            {/* Ausgewählte Charaktere */}
            {(characterIds?.length || 0) > 0 && (
              <div className="flex flex-wrap gap-2 mb-2">
                {characterIds?.map((characterId) => {
                  const character = data.characters.find(c => c.id === characterId)
                  return character ? (
                    <Badge key={characterId} variant="secondary" className="flex items-center gap-1">
                      {character.name}
                      <button
                        type="button"
                        onClick={() => removeCharacter(characterId)}
                        className="ml-1 text-xs hover:text-destructive"
                      >
                        ×
                      </button>
                    </Badge>
                  ) : null
                })}
              </div>
            )}

            {/* Charakter hinzufügen */}
            {availableCharacters.length > 0 && (
              <Select onValueChange={addCharacter}>
                <SelectTrigger>
                  <SelectValue placeholder={
                    type === "tag_team" && (characterIds?.length || 0) >= 2 ? "Tag Team ist voll" :
                    type === "manager" && (characterIds?.length || 0) >= 2 ? "Manager-Beziehung ist voll" :
                    "Mitglied hinzufügen..."
                  } />
                </SelectTrigger>
                <SelectContent>
                  {availableCharacters.map((char) => (
                    <SelectItem key={char.id} value={char.id}>
                      {char.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}

            <div className="text-xs text-muted-foreground">
              {type === "stable" ? `Mindestens 2 Mitglieder erforderlich (${characterIds?.length || 0} ausgewählt)` :
               type === "tag_team" ? `Genau 2 Partner erforderlich (${characterIds?.length || 0} ausgewählt)` :
               type === "manager" ? `Wrestler und Manager erforderlich (${characterIds?.length || 0} ausgewählt)` :
               `Mindestens 1 Mitglied erforderlich (${characterIds?.length || 0} ausgewählt)`}
            </div>
          </div>

          {/* Wrestling-specific fields */}
          {(type === "tag_team" || type === "stable") && (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>{type === "tag_team" ? "Teamname" : "Stablename"}</Label>
                <input
                  type="text"
                  value={teamName}
                  onChange={(e) => setTeamName(e.target.value)}
                  placeholder={type === "tag_team" ? "z.B. The Hardy Boyz" : "z.B. The New Day"}
                  className="w-full px-3 py-2 border border-input bg-background rounded-md text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                />
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="is-active"
                  checked={isActive}
                  onCheckedChange={(checked: boolean) => setIsActive(checked)}
                />
                <label
                  htmlFor="is-active"
                  className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                >
                  Aktiv
                </label>
              </div>
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="description">Beschreibung</Label>
            <Textarea
              id="description"
              placeholder="Beschreibe die Beziehung zwischen den Charakteren..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
            />
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label>Intensität</Label>
              <span className="text-sm text-muted-foreground">{intensity}/10</span>
            </div>
            <Slider value={[intensity]} onValueChange={(v) => setIntensity(v[0])} min={1} max={10} step={1} />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>Schwach</span>
              <span>Stark</span>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Abbrechen
            </Button>
            <Button type="submit" disabled={
              !isEditing && (
                (type === "stable" && (characterIds?.length || 0) < 2) ||
                ((type === "tag_team" || type === "manager") && (characterIds?.length || 0) !== 2) ||
                ((type === "rivalry" || type === "friendship") && 
                  (characterIds?.length || 0) < 1)
              )
            }>
              {isEditing ? "Speichern" : "Erstellen"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
