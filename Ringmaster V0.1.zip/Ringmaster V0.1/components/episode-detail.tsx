"use client"

import type React from "react"
import { useState, useMemo, useCallback } from "react"
import { CustomModal } from "@/components/custom-modal"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { useSeries } from "@/lib/series-context"
import type { Event, Segment } from "@/lib/types"
import { CharacterAvatar } from "@/components/character-avatar"
import { EventReportModal } from "@/components/event-report"
import { ProvisionalReportModal } from "@/components/provisional-report"
import { useEventStyle } from "@/lib/event-style-context"
import { Plus, GripVertical, X, Clock, MapPin, Users, Calendar, ImageIcon, SortAsc, FileText, Eye } from "lucide-react"

interface EpisodeDetailProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  episode: Event
}

const statusLabels: Record<Event["status"], string> = {
  planning: "In Planung",
  writing: "In Arbeit",
  production: "Produktion",
  completed: "Abgeschlossen",
}

export function EpisodeDetail({ open, onOpenChange, episode: initialEpisode }: EpisodeDetailProps) {
  const { data, updateEpisode, addSceneToEpisode, removeSceneFromEpisode, sortEpisodeScenesByTimeOfDay } = useSeries()
  const { eventStyle } = useEventStyle()
  const [draggedScene, setDraggedScene] = useState<string | null>(null)
  const [showReportModal, setShowReportModal] = useState(false)
  const [showProvisionalModal, setShowProvisionalModal] = useState(false)

  // Episode immer aus dem aktuellen data-State holen, aber sicherstellen dass sie existiert
  const episode = useMemo(() => {
    const currentEpisode = data.episodes?.find((e) => e.id === initialEpisode.id)
    return currentEpisode || initialEpisode
  }, [data.episodes, initialEpisode.id, initialEpisode])

  // Sicherstellen dass die Episode gültig ist
  if (!episode) {
    return null
  }

  // Szenen mit useMemo berechnen, um unnötige Re-Berechnungen zu vermeiden
  const episodeScenes = useMemo(() => {
    if (!episode.sceneIds || !data.segments) return []
    const scenes = episode.sceneIds
      .map((id: string) => data.segments.find((s: Segment) => s.id === id))
      .filter((s): s is Segment => s !== undefined)
    return scenes
  }, [episode.sceneIds, data.segments])

  // Nur aktive Storylines verwenden
  const activeStorylines = useMemo(() => {
    return data.storylines?.filter(storyline => storyline.status === 'active') || []
  }, [data.storylines])

  const availableScenesByStoryline = useMemo(() => {
    // Alle Szenen sammeln, die bereits in irgendeiner Episode sind
    const allUsedSceneIds = new Set(
      data.episodes?.flatMap((ep: Event) => ep.sceneIds) || []
    )
    // Nur Szenen anzeigen, die noch nicht in irgendeiner Episode sind
    const availableScenes = data.segments?.filter((s: Segment) => !allUsedSceneIds.has(s.id)) || []

    // Für jede aktive Storyline die verfügbaren Szenen sammeln
    const grouped = new Map<string, Segment[]>()
    activeStorylines.forEach(storyline => {
      const storylineScenes = availableScenes.filter((scene: Segment) => scene.storylineIds?.includes(storyline.id) || false)
      grouped.set(storyline.id, storylineScenes)
    })

    return grouped
  }, [data.segments, data.episodes, activeStorylines])

  // Abwärtskompatibilität für andere Stellen im Code
  const availableScenes = useMemo(() => {
    return Array.from(availableScenesByStoryline.values()).flat()
  }, [availableScenesByStoryline])

  const totalDuration = useMemo(() => {
    return episodeScenes.reduce((sum: number, s: Segment) => sum + s.duration, 0)
  }, [episodeScenes])

  // Funktion zur Übersetzung der Tageszeit
  const getTimeOfDayLabel = (timeOfDay: string) => {
    switch (timeOfDay) {
      case "morning": return "Morgens"
      case "afternoon": return "Nachmittags"
      case "evening": return "Abends"
      case "night": return "Nachts"
      default: return timeOfDay
    }
  }

  const handleDragStart = useCallback((sceneId: string) => {
    setDraggedScene(sceneId)
  }, [])

  const handleDragOver = useCallback((e: React.DragEvent, targetIndex: number) => {
    e.preventDefault()
    if (!draggedScene) return

    const currentIndex = episode.sceneIds.indexOf(draggedScene)
    if (currentIndex === targetIndex) return

    const newSceneIds = [...episode.sceneIds]
    newSceneIds.splice(currentIndex, 1)
    newSceneIds.splice(targetIndex, 0, draggedScene)

    updateEpisode({
      ...episode,
      sceneIds: newSceneIds,
    })
  }, [draggedScene, episode, updateEpisode])

  const handleDragEnd = useCallback(() => {
    setDraggedScene(null)
  }, [])

  const handleAddScene = useCallback((sceneId: string) => {
    addSceneToEpisode(episode.id, sceneId)
  }, [episode.id, addSceneToEpisode])

  const handleRemoveScene = useCallback((sceneId: string) => {
    removeSceneFromEpisode(episode.id, sceneId)
  }, [episode.id, removeSceneFromEpisode])

  return (
    <CustomModal open={open} onOpenChange={onOpenChange}>
      <div className="h-full min-w-0 flex flex-col p-6">
        {/* Header */}
        <div className="flex items-start gap-4 mb-4">
          {episode.imageUrl ? (
            <img
              src={episode.imageUrl || "/placeholder.svg"}
              alt={episode.title}
              className={`object-cover rounded-lg shrink-0 transition-all duration-200 hover:scale-105 ${
                eventStyle === "style1" 
                  ? "w-20 h-14 md:w-24 md:h-16" 
                  : "w-32 h-20 md:w-40 md:h-24"
              }`}
            />
          ) : (
            <div className={`bg-muted rounded-lg flex items-center justify-center shrink-0 ${
              eventStyle === "style1" 
                ? "w-20 h-14 md:w-24 md:h-16" 
                : "w-32 h-20 md:w-40 md:h-24"
            }`}>
              <ImageIcon className={`text-muted-foreground ${
                eventStyle === "style1" 
                  ? "h-5 w-5 md:h-6 md:w-6" 
                  : "h-8 w-8 md:h-10 md:w-10"
              }`} />
            </div>
          )}
          <div className="flex-1">
            <h2 className="text-xl font-semibold">
              {episode.eventType} #{episode.eventNumber}: {episode.title}
            </h2>
            <div className="flex justify-end mt-2 gap-2">
              {episode.completionReport && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowReportModal(true)}
                >
                  <FileText className="h-4 w-4 mr-2" />
                  Bericht anzeigen
                </Button>
              )}
              {episode.status === "planning" && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowProvisionalModal(true)}
                >
                  <Eye className="h-4 w-4 mr-2" />
                  Provisorischer Bericht
                </Button>
              )}
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  console.log('Button clicked, episode.id:', episode.id)
                  sortEpisodeScenesByTimeOfDay(episode.id)
                }}
                disabled={episodeScenes.length === 0}
              >
                <SortAsc className="h-4 w-4 mr-2" />
                Nach Tageszeit sortieren
              </Button>
            </div>
            <div className="flex items-center gap-2 mt-1 flex-wrap">
              <Badge variant="outline">{statusLabels[episode.status]}</Badge>
              <span className="text-sm text-muted-foreground">
                {episodeScenes.length} Szenen | {totalDuration} Min.
              </span>
              {episode.airDate && (
                <span className="text-sm text-muted-foreground flex items-center gap-1">
                  <Calendar className="h-3 w-3" />
                  {new Date(episode.airDate).toLocaleDateString("de-DE")}
                </span>
              )}
            </div>
          </div>
        </div>

        <p className="text-sm text-muted-foreground leading-relaxed mb-4">
          {episode.status === "completed" 
            ? "Dieses Event wurde abgeschlossen. Du kannst den automatisch generierten Bericht einsehen."
            : "Verwalte die Szenen dieser Episode. Ziehe Szenen um die Reihenfolge zu ändern oder füge neue Szenen hinzu."
          }
        </p>

        {episode.synopsis && <p className="text-sm text-muted-foreground leading-relaxed mb-4">{episode.synopsis}</p>}

        <Separator className="mb-4" />

        {episode.status === "completed" ? (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center">
              <FileText className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">Event abgeschlossen</h3>
              <p className="text-muted-foreground mb-4">Dieses Event wurde bereits durchgeführt.</p>
              <Button
                onClick={() => setShowReportModal(true)}
                className="gap-2"
              >
                <FileText className="h-4 w-4" />
                Bericht anzeigen
              </Button>
            </div>
          </div>
        ) : (
          <div className="flex-1 flex gap-4 min-h-0 min-w-0">
            {/* Episode Scenes */}
            <div className="flex-none w-80 flex flex-col">
              <h3 className="font-semibold text-foreground mb-3">Szenen in dieser Episode</h3>
              <div className="flex-1 overflow-y-auto border rounded" style={{ height: '500px', maxHeight: '80vh' }}>
                {episodeScenes.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-8">
                    Noch keine Szenen. Füge Szenen von rechts hinzu.
                  </p>
                ) : (
                  <div className="space-y-2 p-2">
                    {episodeScenes.map((scene: Segment, index: number) => {
                      const storyline = data.storylines.find((s) => s.id && scene.storylineIds?.includes(s.id))
                      const characters = data.characters
                        .filter((c) => scene.characterIds.includes(c.id))
                        .sort((a, b) => a.name.localeCompare(b.name))
                      return (
                        <div
                          key={scene.id}
                          draggable
                          onDragStart={() => handleDragStart(scene.id)}
                          onDragOver={(e) => handleDragOver(e, index)}
                          onDragEnd={handleDragEnd}
                          className={`p-3 rounded-lg border bg-card cursor-grab active:cursor-grabbing transition-colors ${
                            draggedScene === scene.id ? "opacity-50" : ""
                          }`}
                        >
                          <div className="flex items-start gap-2">
                            <GripVertical className="h-4 w-4 text-muted-foreground mt-1 shrink-0" />
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-2">
                                  <span className="text-xs font-mono text-muted-foreground">{index + 1}.</span>
                                  {storyline && (
                                    <div className="h-2 w-2 rounded-full" style={{ backgroundColor: storyline.color }} />
                                  )}
                                  <span className="font-medium text-sm text-foreground line-clamp-2 break-words">{scene.title}</span>
                                </div>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-6 w-6"
                                  onClick={() => handleRemoveScene(scene.id)}
                                >
                                  <X className="h-3 w-3" />
                                </Button>
                              </div>
                              <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                                <span>{scene.duration} Min.</span>
                              </div>
                              {scene.description && (
                                <p className="text-xs text-muted-foreground mt-2 line-clamp-3">
                                  {scene.description}
                                </p>
                              )}
                              {characters.length > 0 && (
                                <div className="flex -space-x-2">
                                  {characters.slice(0, 4).map((character) => (
                                    <CharacterAvatar
                                      key={character.id}
                                      character={character}
                                      size="xs"
                                      className="border-2 border-card"
                                    />
                                  ))}
                                  {characters.length > 4 && (
                                    <div className="h-5 w-5 rounded-full bg-muted border-2 border-card flex items-center justify-center">
                                      <span className="text-xs">+{characters.length - 4}</span>
                                    </div>
                                  )}
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                )}
              </div>
            </div>

            {/* Available Scenes by Storyline */}
            <div className="flex-1 min-h-0 min-w-0 flex flex-col">
              <h3 className="font-semibold text-foreground mb-3">Verfügbare Szenen nach Storylines</h3>
              <div
                className="flex-1 min-h-0 min-w-0 w-full max-w-full border rounded overflow-x-auto overflow-y-hidden"
                style={{ height: "500px", maxHeight: "80vh" }}
              >
                {activeStorylines.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-8">
                    Keine aktiven Storylines vorhanden. Aktiviere Storylines in den Einstellungen.
                  </p>
                ) : (
                  <div className="flex gap-4 p-2 w-max">
                    {activeStorylines.map((storyline) => {
                      const scenes = availableScenesByStoryline.get(storyline.id) || []
                      return (
                        <div key={storyline.id} className="flex-none w-64 flex flex-col">
                          <div className="flex items-center gap-2 mb-2 pb-2 border-b">
                            <div
                              className="h-3 w-3 rounded-full shrink-0"
                              style={{ backgroundColor: storyline.color }}
                            />
                            <h4 className="font-medium text-sm text-foreground line-clamp-2 break-words">
                              {storyline.title}
                            </h4>
                            <span className="text-xs text-muted-foreground ml-auto">
                              {scenes.length}
                            </span>
                          </div>
                          <div className="flex-1 min-h-0 space-y-2 overflow-y-auto">
                            {scenes.length === 0 ? (
                              <p className="text-xs text-muted-foreground text-center py-4">
                                Keine verfügbaren Szenen
                              </p>
                            ) : (
                              scenes.map((scene) => {
                                const sceneCharacters = data.characters
                                  .filter((c) => scene.characterIds.includes(c.id))
                                  .sort((a, b) => a.name.localeCompare(b.name))
                                return (
                                  <div
                                    key={scene.id}
                                    className="p-2 rounded-lg border bg-muted/30 hover:bg-muted/50 transition-colors"
                                  >
                                    <div className="flex items-start justify-between">
                                      <div className="flex-1 min-w-0">
                                        <span className="font-medium text-sm text-foreground line-clamp-2 break-words">
                                          {scene.title}
                                        </span>
                                        <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                                          <span>{scene.duration} Min.</span>
                                        </div>
                                        {scene.description && (
                                          <p className="text-xs text-muted-foreground mt-2 line-clamp-3">
                                            {scene.description}
                                          </p>
                                        )}
                                        {sceneCharacters.length > 0 && (
                                          <div className="flex -space-x-2">
                                            {sceneCharacters.slice(0, 4).map((character) => (
                                              <CharacterAvatar
                                                key={character.id}
                                                character={character}
                                                size="xs"
                                                className="border-2 border-card"
                                              />
                                            ))}
                                            {sceneCharacters.length > 4 && (
                                              <div className="h-5 w-5 rounded-full bg-muted border-2 border-card flex items-center justify-center">
                                                <span className="text-xs">+{sceneCharacters.length - 4}</span>
                                              </div>
                                            )}
                                          </div>
                                        )}
                                      </div>
                                      <Button
                                        variant="ghost"
                                        size="icon"
                                        className="h-6 w-6 shrink-0"
                                        onClick={() => handleAddScene(scene.id)}
                                      >
                                        <Plus className="h-3 w-3" />
                                      </Button>
                                    </div>
                                  </div>
                                )
                              })
                            )}
                          </div>
                        </div>
                      )
                    })}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Event Report Modal */}
      {episode.completionReport && (
        <EventReportModal
          open={showReportModal}
          onOpenChange={setShowReportModal}
          event={episode}
        />
      )}

      {/* Provisional Report Modal */}
      {episode.status === "planning" && (
        <ProvisionalReportModal
          open={showProvisionalModal}
          onOpenChange={setShowProvisionalModal}
          event={episode}
        />
      )}
    </CustomModal>
  )
}
