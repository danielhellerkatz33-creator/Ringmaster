"use client";

import { useRef, useState, type ChangeEvent } from "react";
import { Play, Upload, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { SkinToggle } from "@/components/ui/skin-toggle";
import { useSeries } from "@/lib/series-context";
import { useLanguage } from "@/hooks/use-language";
import { indexedDBStorage } from "@/lib/indexeddb-storage";
import { importSavegame } from "@/lib/savegame/import";

export function MainMenu() {
  const { data } = useSeries();
  const { t } = useLanguage();
  const [isStartingNewGame, setIsStartingNewGame] = useState(false);
  const [isLoadingGame, setIsLoadingGame] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleNewGame = async () => {
    if ((data.series && data.series.length > 0) || data.characters.length > 0) {
      const confirmed = window.confirm(t.mainMenu.confirmNewGameMessage);
      if (!confirmed) return;
    }

    setIsStartingNewGame(true);
    try {
      await indexedDBStorage.clearAllData();
      window.location.href = "/";
    } catch (error) {
      console.error("Error starting new game:", error);
      alert(t.mainMenu.errorNewGame);
      setIsStartingNewGame(false);
    }
  };

  const handleLoadGame = () => {
    fileInputRef.current?.click();
  };

  const handleFileSelect = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.name.endsWith(".json")) {
      alert(t.mainMenu.errorSelectJson);
      return;
    }

    setIsLoadingGame(true);

    try {
      const result = await importSavegame(file, (step) => {
        console.log("Import Schritt:", step);
      });

      if (result.success) {
        window.location.href = "/";
      } else {
        alert(`${t.mainMenu.errorLoadGame}: ${result.error}`);
      }
    } catch (error) {
      console.error("Fehler beim Laden des Savegames:", error);
      alert(t.mainMenu.errorLoadGameMessage);
    } finally {
      setIsLoadingGame(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-background via-background to-muted/20">
      <div className="w-full max-w-lg">
        {/* Header Card */}
        <div className="bg-card rounded-2xl shadow-2xl border border-border overflow-hidden mb-6">
          <div className="relative h-48 bg-gradient-to-br from-primary/10 via-primary/5 to-transparent">
            <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
            {/* Skin Toggle oben rechts */}
            <div className="absolute top-4 right-4 z-10">
              <SkinToggle />
            </div>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <h1 className="text-4xl font-bold bg-gradient-to-r from-primary via-primary/90 to-primary/80 bg-clip-text text-transparent mb-2">
                  RINGMASTER
                </h1>
                <p className="text-muted-foreground font-medium">
                  {t.mainMenu.subtitle}
                </p>
              </div>
            </div>
          </div>

          {data.series && data.series.length > 0 && (
            <div className="px-6 py-4 bg-muted/30 border-t border-border/30">
              <div className="flex items-center justify-center">
                <div className="bg-primary/10 text-primary px-3 py-1 rounded-full text-sm font-medium">
                  {t.mainMenu.currentSeries} {data.series[0].title}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Action Buttons Card */}
        <div className="bg-card rounded-2xl shadow-xl border border-border p-8">
          <input
            ref={fileInputRef}
            type="file"
            accept=".json"
            onChange={handleFileSelect}
            className="hidden"
          />

          <div className="space-y-4">
            <Button
              size="lg"
              className="modern-primary-button w-full h-16 text-lg font-semibold rounded-xl bg-gradient-to-r from-primary to-primary/90 hover:from-primary/95 hover:to-primary/85 transition-all duration-300 hover:scale-[1.02] hover:shadow-lg shadow-md"
              onClick={handleNewGame}
              disabled={isStartingNewGame}
            >
              {isStartingNewGame ? (
                <Loader2 className="h-6 w-6 mr-3 animate-spin" />
              ) : (
                <Play className="h-6 w-6 mr-3" />
              )}
              {isStartingNewGame ? t.mainMenu.newGameStarting : t.mainMenu.newGame}
            </Button>

            <Button
              size="lg"
              variant="outline"
              className="modern-secondary-button w-full h-16 text-lg font-semibold rounded-xl border-2 border-primary/30 hover:bg-primary/5 hover:border-primary/60 transition-all duration-300 hover:scale-[1.02] hover:shadow-lg shadow-md"
              onClick={handleLoadGame}
              disabled={isLoadingGame}
            >
              {isLoadingGame ? (
                <Loader2 className="h-6 w-6 mr-3 animate-spin" />
              ) : (
                <Upload className="h-6 w-6 mr-3" />
              )}
              {isLoadingGame ? t.mainMenu.loadGameLoading : t.mainMenu.loadGame}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}