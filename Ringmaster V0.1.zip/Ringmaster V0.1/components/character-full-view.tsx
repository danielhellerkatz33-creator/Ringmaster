"use client"

import { useState, useEffect, useMemo } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { CharacterHeroStage } from "@/components/character-hero-stage"
import { useLanguage } from "@/lib/i18n/language-context"
import { useSeries } from "@/lib/series-context"
import { getChampionshipHistory, getTotalReigns } from "@/lib/championship-utils"
import { ChevronLeft, ChevronRight } from "lucide-react"
import type { Character, Storyline } from "@/lib/types"

interface CharacterFullViewProps {
  character: Character
}

const formatDate = (date: Date | string): string => {
  const dateObj = date instanceof Date ? date : new Date(date)
  return dateObj.toLocaleDateString()
}

const parseCharacterSummaries = (summary: string, characters: Character[]): any[] => {
  const sections: any[] = []

  // Finde alle Charakter-Absätze mit Regex
  const pattern = /([A-Z][a-zäöüÄÖÜß]+(?:[\.\-\s]+[A-Z][a-zäöüÄÖÜß]+)*):\s*([^]*?)(?=\n\n[A-Z][a-zäöüÄÖÜß]+(?:[\.\-\s]+[A-Z][a-zäöüÄÖÜß]+)*:|$(?![\r\n]))/g

  let match
  while ((match = pattern.exec(summary)) !== null) {
    const characterName = match[1].trim()
    const content = match[2].trim()

    // Finde passenden Charakter
    const character = characters.find(c => c.name === characterName)

    sections.push({
      character,
      characterName,
      content,
      hasValidCharacter: !!character
    })
  }

  return sections
}

export function CharacterFullView({ character }: CharacterFullViewProps) {
  const { t } = useLanguage()
  const { data } = useSeries()
  
  // Championship-History berechnen
  const championshipHistory = useMemo(() => 
    getChampionshipHistory(character.id, data.characterArcs || []), 
    [character.id, data.characterArcs]
  )
  const totalReigns = useMemo(() => 
    getTotalReigns(character.id, data.characterArcs || []), 
    [character.id, data.characterArcs]
  )
  const [currentReviewIndex, setCurrentReviewIndex] = useState(0)

  const relationships = (data.relationships || []).filter(
    (r) => r.characterIds && r.characterIds.includes(character.id),
  )

  const arcs = (data.characterArcs || []).filter((a) => a.characterId === character.id)
  const storylines = (data.storylines || []).filter((s) => s.characterIds && s.characterIds.includes(character.id))
  const scenes = (data.segments || []).filter((s) => s.characterIds && s.characterIds.includes(character.id))

  // Abgeschlossene Storylines mit Charakterrückblicken für diesen Charakter
  const completedStorylinesWithCharacterReviews = (data.storylines || [])
    .filter((s) => s.status === "completed" && s.characterReview && s.characterIds && s.characterIds.includes(character.id))
    .map((storyline) => ({
      storyline,
      characterSummary: parseCharacterSummaries(storyline.characterReview!, data.characters || [])
        .find(section => section.characterName === character.name)
    }))
    .filter(item => item.characterSummary)

  // Navigation für Charakterrückblicke
  const goToPreviousReview = () => {
    setCurrentReviewIndex((prev) =>
      prev > 0 ? prev - 1 : completedStorylinesWithCharacterReviews.length - 1
    )
  }

  const goToNextReview = () => {
    setCurrentReviewIndex((prev) =>
      prev < completedStorylinesWithCharacterReviews.length - 1 ? prev + 1 : 0
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Stage */}
      <CharacterHeroStage character={character} />

      {/* Content Area */}
      <div className="max-w-4xl mx-auto px-6 lg:px-8 py-8 space-y-8">
        {/* Hometown */}
        {character.hometown && (
          <div>
            <h4 className="text-sm font-semibold text-foreground mb-2">Heimatstadt</h4>
            <p className="text-sm text-muted-foreground leading-relaxed">📍 {character.hometown}</p>
          </div>
        )}

        {/* Championship History */}
        {championshipHistory.length > 0 && (
          <div>
            <h4 className="text-sm font-semibold text-foreground mb-3">Championship History</h4>
            <div className="space-y-3">
              {/* Statistik */}
              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                <span>🏆 Total Reigns: {totalReigns}</span>
              </div>
              
              {/* Championship-Liste */}
              <div className="space-y-2">
                {championshipHistory.map((champ, index) => (
                  <div key={`${champ.id}-${index}`} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                    <div className="flex items-center gap-3">
                      <span className="text-lg">
                        {champ.type === 'current' ? '🏆' : '🥈'}
                      </span>
                      <div>
                        <p className="font-medium text-sm">{champ.title}</p>
                        <p className="text-xs text-muted-foreground">
                          {champ.type === 'current' ? 'Current Champion' : 
                           champ.dateWon && champ.dateLost ? 
                           `${formatDate(champ.dateWon)} - ${formatDate(champ.dateLost)}` :
                           champ.dateWon ? `Since ${formatDate(champ.dateWon)}` : 'Former Champion'
                          }
                          {champ.defenses !== undefined && champ.defenses > 0 && ` • ${champ.defenses} defenses`}
                        </p>
                      </div>
                    </div>
                    <Badge 
                      variant={champ.type === 'current' ? 'default' : 'outline'}
                      className={champ.type === 'current' ? 'bg-yellow-500/20 text-yellow-600 border-yellow-500/30' : ''}
                    >
                      {champ.type === 'current' ? 'Current' : 'Former'}
                    </Badge>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        <Separator />

        {/* Charakterrückblicke */}
        <div>
          <h4 className="text-sm font-semibold text-foreground mb-3">Charakterrückblicke</h4>
          {completedStorylinesWithCharacterReviews.length === 0 ? (
            <p className="text-sm text-muted-foreground">{t.ui.emptyStates.noCharacterReviews}</p>
          ) : (
            <div className="relative">
              {/* Navigation Buttons */}
              {completedStorylinesWithCharacterReviews.length > 1 && (
                <>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={goToPreviousReview}
                    className="absolute left-0 top-1/2 -translate-y-1/2 z-10 h-8 w-8 p-0 rounded-full shadow-md"
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={goToNextReview}
                    className="absolute right-0 top-1/2 -translate-y-1/2 z-10 h-8 w-8 p-0 rounded-full shadow-md"
                  >
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </>
              )}

              {/* Current Review */}
              <div className="px-10">
                {(() => {
                  const { storyline, characterSummary } = completedStorylinesWithCharacterReviews[currentReviewIndex]
                  return (
                    <div
                      className="p-4 rounded-lg bg-card border shadow-sm"
                      style={{ borderLeftColor: storyline.color, borderLeftWidth: '4px' }}
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-start gap-3">
                          <div
                            className="h-4 w-4 rounded-full mt-1 shrink-0"
                            style={{ backgroundColor: storyline.color }}
                          />
                          <div>
                            <h5 className="text-base font-semibold text-foreground mb-1">{storyline.title}</h5>
                            <p className="text-xs text-muted-foreground">Charakterrückblick</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant="secondary" className="text-xs shrink-0">
                            {storyline.type === "main" ? "Haupthandlung" :
                             storyline.type === "subplot" ? "Nebenhandlung" : "Story Arc"}
                          </Badge>
                          {completedStorylinesWithCharacterReviews.length > 1 && (
                            <span className="text-xs text-muted-foreground">
                              {currentReviewIndex + 1} / {completedStorylinesWithCharacterReviews.length}
                            </span>
                          )}
                        </div>
                      </div>
                      {characterSummary && (
                        <div className="pt-2 border-t border-border/50">
                          <p className="text-sm text-muted-foreground leading-loose max-w-4xl">
                            {characterSummary.content}
                          </p>
                        </div>
                      )}
                    </div>
                  )
                })()}
              </div>
            </div>
          )}
        </div>

        {/* Character Arcs */}
        {arcs.length > 0 && (
          <div>
            <h4 className="text-sm font-semibold text-foreground mb-3">Character Arcs</h4>
            <div className="space-y-2">
              {arcs.map((arc) => (
                <div key={arc.id} className="p-3 rounded-lg bg-muted/30">
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-medium text-foreground text-sm">{arc.title}</span>
                    <Badge variant={arc.status === "active" ? "default" : "outline"} className="text-xs capitalize">
                      {arc.status}
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground">{arc.description}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}