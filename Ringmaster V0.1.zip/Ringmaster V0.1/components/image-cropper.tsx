"use client"

import { useState, useCallback } from "react"
import Cropper from 'react-easy-crop'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Label } from "@/components/ui/label"
import { RotateCcw, RotateCw, ZoomIn, ZoomOut, Check, X } from "lucide-react"
import { useLanguage } from "@/hooks/use-language"

interface ImageCropperProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  imageSrc: string
  onCropComplete: (croppedImageBlob: Blob) => void
  aspect?: number // width/height ratio
}

interface Area {
  x: number
  y: number
  width: number
  height: number
}

export function ImageCropper({
  open,
  onOpenChange,
  imageSrc,
  onCropComplete,
  aspect = 16/9
}: ImageCropperProps) {
  const { t } = useLanguage()
  const [crop, setCrop] = useState({ x: 0, y: 0 })
  const [zoom, setZoom] = useState(1)
  const [rotation, setRotation] = useState(0)
  const [croppedAreaPixels, setCroppedAreaPixels] = useState<Area | null>(null)

  const onCropChange = useCallback((crop: { x: number; y: number }) => {
    setCrop(crop)
  }, [])

  const onZoomChange = useCallback((zoom: number) => {
    setZoom(zoom)
  }, [])

  const onRotationChange = useCallback((rotation: number) => {
    setRotation(rotation)
  }, [])

  const onCropAreaChange = useCallback(
    (_: any, croppedAreaPixels: Area) => {
      setCroppedAreaPixels(croppedAreaPixels)
    },
    []
  )

  const createCroppedImage = useCallback(async (): Promise<Blob | null> => {
    if (!croppedAreaPixels) return null

    return new Promise((resolve) => {
      const canvas = document.createElement('canvas')
      const ctx = canvas.getContext('2d')
      const image = new Image()

      image.onload = () => {
        // Calculate canvas size based on cropped area
        canvas.width = croppedAreaPixels.width
        canvas.height = croppedAreaPixels.height

        // Apply rotation if needed
        if (rotation !== 0) {
          ctx?.translate(canvas.width / 2, canvas.height / 2)
          ctx?.rotate((rotation * Math.PI) / 180)
          ctx?.translate(-canvas.width / 2, -canvas.height / 2)
        }

        // Draw the cropped image
        ctx?.drawImage(
          image,
          croppedAreaPixels.x,
          croppedAreaPixels.y,
          croppedAreaPixels.width,
          croppedAreaPixels.height,
          0,
          0,
          croppedAreaPixels.width,
          croppedAreaPixels.height
        )

        canvas.toBlob(resolve, 'image/jpeg', 0.95)
      }

      image.src = imageSrc
    })
  }, [imageSrc, croppedAreaPixels, rotation])

  const handleSave = async () => {
    const croppedBlob = await createCroppedImage()
    if (croppedBlob) {
      onCropComplete(croppedBlob)
      onOpenChange(false)
      // Reset state
      setCrop({ x: 0, y: 0 })
      setZoom(1)
      setRotation(0)
      setCroppedAreaPixels(null)
    }
  }

  const handleCancel = () => {
    onOpenChange(false)
    // Reset state
    setCrop({ x: 0, y: 0 })
    setZoom(1)
    setRotation(0)
    setCroppedAreaPixels(null)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle>{t.characters.image} {t.common.edit}</DialogTitle>
          <DialogDescription>
            Schneide dein Bild zu, zoome und rotiere es nach Belieben.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Crop Area */}
          <div className="relative h-96 bg-muted rounded-lg overflow-hidden">
            <Cropper
              image={imageSrc}
              crop={crop}
              zoom={zoom}
              rotation={rotation}
              aspect={aspect}
              onCropChange={onCropChange}
              onZoomChange={onZoomChange}
              onRotationChange={onRotationChange}
              onCropAreaChange={onCropAreaChange}
              classes={{
                containerClassName: 'h-full',
                cropAreaClassName: 'border-2 border-primary',
              }}
            />
          </div>

          {/* Controls */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Zoom */}
            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <ZoomIn className="h-4 w-4" />
                Zoom: {zoom.toFixed(1)}x
              </Label>
              <Slider
                value={[zoom]}
                onValueChange={(value) => setZoom(value[0])}
                min={0.5}
                max={3}
                step={0.1}
                className="w-full"
              />
            </div>

            {/* Rotation */}
            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <RotateCw className="h-4 w-4" />
                Rotation: {rotation}°
              </Label>
              <Slider
                value={[rotation]}
                onValueChange={(value) => setRotation(value[0])}
                min={-180}
                max={180}
                step={1}
                className="w-full"
              />
            </div>

            {/* Quick Rotation Buttons */}
            <div className="space-y-2">
              <Label>Schnell-Rotation</Label>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setRotation(r => r - 90)}
                >
                  <RotateCcw className="h-4 w-4 mr-1" />
                  -90°
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setRotation(r => r + 90)}
                >
                  <RotateCw className="h-4 w-4 mr-1" />
                  +90°
                </Button>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-2 pt-4 border-t">
            <Button variant="outline" onClick={handleCancel}>
              <X className="h-4 w-4 mr-2" />
{t.common.cancel}
            </Button>
            <Button onClick={handleSave} disabled={!croppedAreaPixels}>
              <Check className="h-4 w-4 mr-2" />
              Bild zuschneiden & speichern
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}