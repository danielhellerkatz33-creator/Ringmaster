"use client"

import { useState, useEffect } from "react"
import { CharacterAvatar } from "@/components/character-avatar"
import { Badge } from "@/components/ui/badge"
import { useLanguage } from "@/hooks/use-language"
import { useSeries } from "@/lib/series-context"
import { BookOpen, TrendingUp, Film, Heart, Trophy } from "lucide-react"
import { getTotalReigns } from "@/lib/championship-utils"
import type { Character } from "@/lib/types"

interface CharacterHeroStageProps {
  character: Character
}

const positionLabels: Record<Character["position"], string> = {
  main_event: "Main Event",
  upper_card: "Upper Card",
  mid_card: "Mid Card",
  lower_card: "Lower Card",
  jobber: "Jobber",
  road_agent: "Road Agent",
  manager: "Manager",
  staff: "Staff",
  commentary: "Commentary",
  referee: "Referee",
}

const alignmentLabels: Record<Character["alignment"], string> = {
  face: "Face",
  heel: "Heel",
  tweener: "Tweener",
}

const statusLabels: Record<Character["status"], string> = {
  active: "Active",
  injured: "Injured",
  suspended: "Suspended",
  retired: "Retired",
  inactive: "Inactive",
}

interface StatCardProps {
  value: number
  label: string
  icon: React.ComponentType<{ className?: string }>
  maxValue: number
}

function StatCard({ value, label, icon: Icon, maxValue }: StatCardProps) {
  const percentage = Math.min((value / maxValue) * 100, 100)

  return (
    <div className="bg-card/50 rounded-lg p-4 border border-border/50 transition-all duration-300 hover:bg-card/80 hover:shadow-sm">
      <div className="flex items-center justify-between mb-2">
        <span className="text-2xl font-bold text-foreground">{value}</span>
        <span className="text-xs text-muted-foreground">{label}</span>
      </div>
      <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
        <div
          className="h-full bg-primary transition-all duration-700 ease-out rounded-full"
          style={{ width: `${percentage}%` }}
        />
      </div>
    </div>
  )
}

export function CharacterHeroStage({ character }: CharacterHeroStageProps) {
  const { t } = useLanguage()
  const { data } = useSeries()
  const [isCompact, setIsCompact] = useState(false)

  // Calculate stats
  const relationships = (data.relationships || []).filter(
    (r) => r.characterIds && r.characterIds.includes(character.id)
  ).length

  const totalReigns = getTotalReigns(character.id, data.characterArcs || [])

  const scenes = (data.segments || []).filter((s) => s.characterIds && s.characterIds.includes(character.id)).length

  const completedStorylinesWithCharacterReviews = (data.storylines || [])
    .filter((s) => s.status === "completed" && s.characterReview && s.characterIds && s.characterIds.includes(character.id))
    .length

  // Calculate first and last episode for character
  const sortedEpisodes = [...(data.episodes || [])]
    .filter((episode) => episode.status === "completed")
    .sort((a, b) => a.eventNumber - b.eventNumber)

  const characterScenes = (data.segments || []).filter((scene) =>
    scene.characterIds && scene.characterIds.includes(character.id)
  )

  const characterSegments = sortedEpisodes.flatMap((episode) =>
    episode.sceneIds
      .map((sceneId) => (data.segments || []).find((s) => s.id === sceneId))
      .filter((s): s is any => s !== undefined && s.characterIds && s.characterIds.includes(character.id))
  )

  const characterSceneIds = new Set(characterSegments.map((s) => s.id))

  const characterEpisodes = sortedEpisodes.filter((episode) =>
    episode.sceneIds.some((sceneId) => characterSceneIds.has(sceneId)),
  )

  const firstEpisode = characterEpisodes[0]
  const lastEpisode = characterEpisodes[characterEpisodes.length - 1]

  // Calculate timeline visualization
  const totalEpisodes = sortedEpisodes.length
  const firstEpisodeIndex = firstEpisode ? sortedEpisodes.findIndex(ep => ep.id === firstEpisode.id) : -1
  const lastEpisodeIndex = lastEpisode ? sortedEpisodes.findIndex(ep => ep.id === lastEpisode.id) : -1

  // Calculate the span of episodes where character appears
  let timelineStart = 0
  let timelineWidth = 0
  if (firstEpisodeIndex >= 0 && lastEpisodeIndex >= 0) {
    timelineStart = (firstEpisodeIndex / totalEpisodes) * 100
    timelineWidth = ((lastEpisodeIndex - firstEpisodeIndex + 1) / totalEpisodes) * 100
  }

  // Handle compact mode with smooth transitions
  useEffect(() => {
    let ticking = false

    const handleScroll = () => {
      if (!ticking) {
        requestAnimationFrame(() => {
          setIsCompact(window.scrollY > 80)
          ticking = false
        })
        ticking = true
      }
    }

    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  return (
    <div
      className={`character-hero-stage sticky top-0 z-40 bg-background border-b border-border shadow-lg transition-all duration-500 ease-out ${
        isCompact ? 'is-compact' : ''
      }`}
    >
      <div className={`min-h-[30vh] max-h-[40vh] grid lg:grid-cols-2 gap-8 p-6 lg:p-8 transition-all duration-500 ease-out ${
        isCompact ? 'min-h-[20vh] max-h-[25vh] p-4' : ''
      }`}>
        {/* Portrait Panel */}
        <div className="flex items-center justify-center lg:justify-start">
          <div className={`transition-transform duration-500 ease-out ${isCompact ? 'scale-90' : ''}`}>
            <CharacterAvatar
              key={character.id + character.avatarBlobId + character.updatedAt}
              name={character.name}
              imageUrl={character.imageUrl}
              character={character}
              size="xl"
              className={`rounded-2xl shadow-2xl border-4 border-background h-32 w-32 md:h-40 md:w-40 lg:h-48 lg:w-48 xl:h-64 xl:w-64 text-3xl md:text-4xl lg:text-5xl xl:text-6xl ${isCompact ? 'lg:h-40 lg:w-40 lg:text-4xl xl:h-48 xl:w-48 xl:text-5xl' : ''}`}
            />
          </div>
        </div>

        {/* Identity Panel + Stats Panel */}
        <div className="flex flex-col justify-center space-y-6">
          {/* Identity */}
          <div className="space-y-3">
            <div>
              <h1 className={`font-bold text-foreground transition-all duration-500 ease-out ${
                isCompact ? 'text-3xl' : 'text-5xl lg:text-6xl'
              }`}>
                {character.name}
              </h1>
              <div className="flex gap-1 mt-1">
                <Badge variant="outline" className="text-xs">
                  {positionLabels[character.position]}
                </Badge>
                <Badge 
                  className={`text-xs border-0 ${
                    character.alignment === 'face' ? 'bg-blue-500/20 text-blue-500' :
                    character.alignment === 'heel' ? 'bg-red-500/20 text-red-500' :
                    'bg-gray-500/20 text-gray-500'
                  }`}
                >
                  {alignmentLabels[character.alignment]}
                </Badge>
                <Badge 
                  variant={character.status === 'active' ? 'default' : 'secondary'}
                  className="text-xs"
                >
                  {statusLabels[character.status]}
                </Badge>
              </div>
              {character.hometown && (
                <p className={`mt-3 text-sm text-muted-foreground line-clamp-2 max-h-10 overflow-hidden transition-all duration-500 ease-out ${
                  isCompact ? 'text-xs max-h-8' : ''
                }`}>
                  📍 {character.hometown}
                </p>
              )}
            </div>

            {/* Mini Timeline */}
            <div className="flex items-center gap-4">
              <span className="text-sm text-muted-foreground">
                First: {firstEpisode ? `E${firstEpisode.eventNumber}` : '—'}
              </span>
              <div className="flex-1 h-2 bg-muted rounded-full relative overflow-hidden">
                {firstEpisode && lastEpisode && (
                  <div
                    className="absolute top-0 h-full bg-primary rounded-full transition-all duration-500"
                    style={{
                      left: `${timelineStart}%`,
                      width: `${timelineWidth}%`
                    }}
                  />
                )}
              </div>
              <span className="text-sm text-muted-foreground">
                Last: {lastEpisode ? `E${lastEpisode.eventNumber}` : '—'}
              </span>
            </div>
          </div>

          {/* Stats Panel */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <StatCard
              value={completedStorylinesWithCharacterReviews}
              label={t.common.stories}
              icon={BookOpen}
              maxValue={10}
            />
            <StatCard
              value={totalReigns}
              label="Championships"
              icon={Trophy}
              maxValue={15}
            />
            <StatCard
              value={scenes}
              label={t.common.scenes}
              icon={Film}
              maxValue={120}
            />
            <StatCard
              value={relationships}
              label={t.common.relationships}
              icon={Heart}
              maxValue={30}
            />
          </div>
        </div>
      </div>
    </div>
  )
}