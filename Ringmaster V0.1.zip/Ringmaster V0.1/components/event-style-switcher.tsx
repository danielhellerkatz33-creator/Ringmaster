"use client"

import { Button } from "@/components/ui/button"
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select"
import { useEventStyle } from "@/lib/event-style-context"
import { LayoutGrid, LayoutList } from "lucide-react"

export function EventStyleSwitcher() {
  const { eventStyle, setEventStyle } = useEventStyle()

  return (
    <div className="flex items-center gap-2">
      <span className="text-sm font-medium">Event-Stil:</span>
      <Select value={eventStyle} onValueChange={(value: "style1" | "style2") => setEventStyle(value)}>
        <SelectTrigger className="w-32">
          <SelectValue placeholder="Style 2" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="style1">
            <div className="flex items-center gap-2">
              <LayoutGrid className="h-4 w-4" />
              Style 1
            </div>
          </SelectItem>
          <SelectItem value="style2">
            <div className="flex items-center gap-2">
              <LayoutList className="h-4 w-4" />
              Style 2
            </div>
          </SelectItem>
        </SelectContent>
      </Select>
    </div>
  )
}
