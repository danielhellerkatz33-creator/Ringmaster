"use client"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { useSeries } from "@/lib/series-context"
import { useLanguage } from "@/hooks/use-language"
import type { Location } from "@/lib/types"

interface LocationFormProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  location?: Location
}

export function LocationForm({ open, onOpenChange, location }: LocationFormProps) {
  const { addLocation, updateLocation } = useSeries()
  const { t } = useLanguage()
  const [name, setName] = useState(location?.name || "")
  const [description, setDescription] = useState(location?.description || "")
  const [isActive, setIsActive] = useState(location?.isActive ?? true)

  const isEditing = !!location

  useEffect(() => {
    if (open) {
      if (location) {
        setName(location.name)
        setDescription(location.description)
        setIsActive(location.isActive)
      } else {
        setName("")
        setDescription("")
        setIsActive(true)
      }
    }
  }, [open, location])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!name.trim()) return

    if (isEditing && location) {
      updateLocation({
        ...location,
        name: name.trim(),
        description: description.trim(),
        isActive,
      })
    } else {
      addLocation({
        name: name.trim(),
        description: description.trim(),
        isActive,
      })
    }

    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{isEditing ? "Drehort bearbeiten" : "Neuer Drehort"}</DialogTitle>
          <DialogDescription>
            {isEditing ? "Bearbeite die Details des Drehortes." : "Erstelle einen neuen Drehort für deine Serie."}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Name *</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="z.B. Haus Becker, Schule, Park..."
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Beschreibung</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Optionale Beschreibung des Drehortes..."
              rows={3}
            />
          </div>

          <div className="flex items-center space-x-2">
            <Switch
              id="isActive"
              checked={isActive}
              onCheckedChange={setIsActive}
            />
            <Label htmlFor="isActive">Aktiv</Label>
          </div>
          <p className="text-sm text-muted-foreground">
            Nur aktive Drehorte sind bei der Szenenerstellung im Dropdown verfügbar.
          </p>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
{t.common.cancel}
            </Button>
            <Button type="submit" disabled={!name.trim()}>
{isEditing ? t.common.save : t.common.create}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}