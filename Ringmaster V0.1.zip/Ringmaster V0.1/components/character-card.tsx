"use client"

import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { MoreVertical, Pencil, Trash2, Eye } from "lucide-react"
import { useLanguage } from "@/lib/i18n/language-context"
import { CharacterAvatar } from "@/components/character-avatar"
import { formatChampionshipBadges } from "@/lib/championship-utils"

import type { Character } from "@/lib/types"
interface CharacterCardProps {
  character: Character
  relationshipCount: number
  storylineCount: number
  championships?: any[] // CharacterArc[] mit Championship-Daten
  onEdit: () => void
  onDelete: () => void
  onView: () => void
}

const positionLabels: Record<Character["position"], string> = {
  main_event: "Main Event",
  upper_card: "Upper Card",
  mid_card: "Mid Card",
  lower_card: "Lower Card",
  jobber: "Jobber",
  road_agent: "Road Agent",
  manager: "Manager",
  staff: "Staff",
  commentary: "Commentary",
  referee: "Referee",
}

const alignmentLabels: Record<Character["alignment"], string> = {
  face: "Face",
  heel: "Heel",
  tweener: "Tweener",
}

const statusLabels: Record<Character["status"], string> = {
  active: "Active",
  injured: "Injured",
  suspended: "Suspended",
  retired: "Retired",
  inactive: "Inactive",
}

export function CharacterCard({ character, relationshipCount, storylineCount, championships, onEdit, onDelete, onView }: CharacterCardProps) {
  const { t } = useLanguage()
  
  // Championship-Badges berechnen
  const championshipBadges = championships ? formatChampionshipBadges(character.id, championships) : { current: [], former: '' }
  
  return (
    <Card
      className="group hover:border-primary/50 transition-colors bg-card cursor-pointer min-h-[280px]"
      onClick={onView}
    >
      <CardHeader className="flex flex-row items-start justify-between space-y-0 pb-3">
        <div className="flex items-center gap-3">
          <CharacterAvatar key={character.id + character.avatarBlobId + character.updatedAt} name={character.name} imageUrl={character.imageUrl} character={character} size="lg" />
          <div>
            <h3 className="font-semibold text-foreground leading-tight">{character.name}</h3>
            <div className="flex gap-1 mt-1">
              <Badge variant="outline" className="text-xs">
                {positionLabels[character.position]}
              </Badge>
              <Badge 
                className={`text-xs border-0 ${
                  character.alignment === 'face' ? 'bg-blue-500/20 text-blue-500' :
                  character.alignment === 'heel' ? 'bg-red-500/20 text-red-500' :
                  'bg-gray-500/20 text-gray-500'
                }`}
              >
                {alignmentLabels[character.alignment]}
              </Badge>
              <Badge 
                variant={character.status === 'active' ? 'default' : 'secondary'}
                className="text-xs"
              >
                {statusLabels[character.status]}
              </Badge>
            </div>
          </div>
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity"
              onClick={(e) => e.stopPropagation()}
            >
              <MoreVertical className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={onView}>
              <Eye className="h-4 w-4 mr-2" />
              Ansehen
            </DropdownMenuItem>
            <DropdownMenuItem onClick={onEdit}>
              <Pencil className="h-4 w-4 mr-2" />
              Bearbeiten
            </DropdownMenuItem>
            <DropdownMenuItem onClick={onDelete} className="text-destructive focus:text-destructive">
              <Trash2 className="h-4 w-4 mr-2" />
              Löschen
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </CardHeader>
      <CardContent className="pt-0 px-4 pb-4">
        {character.hometown && (
          <p className="text-sm text-muted-foreground mb-3">📍 {character.hometown}</p>
        )}
        
        {/* Championship-Badges */}
        {(championshipBadges.current.length > 0 || championshipBadges.former) && (
          <div className="flex flex-wrap gap-1 mb-3">
            {championshipBadges.current.map((badge, index) => (
              <Badge key={`current-${index}`} className="bg-yellow-500/20 text-yellow-600 border-yellow-500/30 text-xs">
                {badge}
              </Badge>
            ))}
            {championshipBadges.former && (
              <Badge variant="outline" className="text-xs">
                {championshipBadges.former}
              </Badge>
            )}
          </div>
        )}
        
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span>{relationshipCount} {t.common.relationships.toLowerCase()}</span>
          <span>{storylineCount} {t.common.storylines.toLowerCase()}</span>
        </div>
      </CardContent>
    </Card>
  )
}
