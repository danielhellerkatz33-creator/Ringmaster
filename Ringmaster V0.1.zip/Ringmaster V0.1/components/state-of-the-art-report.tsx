"use client"

import React, { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { 
  FileText, 
  Download, 
  Copy, 
  Check, 
  BarChart3, 
  Clock, 
  Users, 
  Calendar,
  TrendingUp
} from "lucide-react"
import { useSeries } from "@/lib/series-context"
import { generateStateOfTheArtReport, exportReportAsText, exportReportAsJSON } from "@/lib/state-of-the-art-report"
import type { StateOfTheArtReport } from "@/lib/types"
import { useToast } from "@/hooks/use-toast"

interface StateOfTheArtReportProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function StateOfTheArtReportDialog({ open, onOpenChange }: StateOfTheArtReportProps) {
  const { data } = useSeries()
  const { toast } = useToast()
  const [report, setReport] = useState<StateOfTheArtReport | null>(null)
  const [copied, setCopied] = useState(false)

  // Bericht generieren wenn Dialog öffnet
  React.useEffect(() => {
    if (open && data) {
      try {
        const generatedReport = generateStateOfTheArtReport(data)
        setReport(generatedReport)
      } catch (error) {
        console.error("Fehler beim Generieren des Berichts:", error)
        toast({
          title: "Fehler",
          description: "Der Bericht konnte nicht generiert werden.",
          variant: "destructive"
        })
      }
    }
  }, [open, data, toast])

  const handleCopyToClipboard = async () => {
    if (!report) return
    
    try {
      await navigator.clipboard.writeText(exportReportAsText(report))
      setCopied(true)
      toast({
        title: "Kopiert!",
        description: "Der Bericht wurde in die Zwischenablage kopiert."
      })
      
      // Reset nach 2 Sekunden
      setTimeout(() => setCopied(false), 2000)
    } catch (error) {
      toast({
        title: "Fehler",
        description: "Konnte nicht in die Zwischenablage kopieren.",
        variant: "destructive"
      })
    }
  }

  const handleDownloadText = () => {
    if (!report) return
    
    const text = exportReportAsText(report)
    const blob = new Blob([text], { type: "text/plain;charset=utf-8" })
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.href = url
    link.download = `state-of-the-art-report-${new Date().toISOString().split('T')[0]}.txt`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    URL.revokeObjectURL(url)
    
    toast({
      title: "Download gestartet",
      description: "Der Bericht wird als Textdatei heruntergeladen."
    })
  }

  const handleDownloadJSON = () => {
    if (!report) return
    
    const json = exportReportAsJSON(report)
    const blob = new Blob([json], { type: "application/json;charset=utf-8" })
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.href = url
    link.download = `state-of-the-art-report-${new Date().toISOString().split('T')[0]}.json`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    URL.revokeObjectURL(url)
    
    toast({
      title: "Download gestartet",
      description: "Der Bericht wird als JSON-Datei heruntergeladen."
    })
  }

  if (!report) {
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-4xl max-h-[90vh]">
          <div className="flex items-center justify-center h-64">
            <div className="animate-pulse text-muted-foreground">Generiere Bericht...</div>
          </div>
        </DialogContent>
      </Dialog>
    )
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-6xl max-h-[90vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            State of The Art Storyline Bericht
          </DialogTitle>
        </DialogHeader>

        <div className="flex flex-col h-[80vh]">
          {/* Export Buttons */}
          <div className="flex gap-2 mb-4">
            <Button
              variant="outline"
              size="sm"
              onClick={handleCopyToClipboard}
              className="gap-2"
            >
              {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
              {copied ? "Kopiert!" : "Kopieren"}
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={handleDownloadText}
              className="gap-2"
            >
              <Download className="h-4 w-4" />
              Text (.txt)
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={handleDownloadJSON}
              className="gap-2"
            >
              <Download className="h-4 w-4" />
              JSON (.json)
            </Button>
          </div>

          {/* Tabs */}
          <Tabs defaultValue="overview" className="flex-1 overflow-hidden">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="overview" className="gap-2">
                <BarChart3 className="h-4 w-4" />
                Übersicht
              </TabsTrigger>
              <TabsTrigger value="storylines" className="gap-2">
                <FileText className="h-4 w-4" />
                Storylines
              </TabsTrigger>
              <TabsTrigger value="events" className="gap-2">
                <Calendar className="h-4 w-4" />
                Events
              </TabsTrigger>
              <TabsTrigger value="report" className="gap-2">
                <FileText className="h-4 w-4" />
                Vollständiger Bericht
              </TabsTrigger>
            </TabsList>

            {/* Übersicht Tab */}
            <TabsContent value="overview" className="flex-1 overflow-hidden">
              <ScrollArea className="h-full pr-4">
                <div className="space-y-6">
                  {/* Metriken */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="bg-muted/50 p-4 rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <FileText className="h-4 w-4 text-primary" />
                        <span className="text-sm font-medium">Aktive Storylines</span>
                      </div>
                      <div className="text-2xl font-bold">{report.totalActiveStorylines}</div>
                    </div>
                    <div className="bg-muted/50 p-4 rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <BarChart3 className="h-4 w-4 text-primary" />
                        <span className="text-sm font-medium">Gesamte Segmente</span>
                      </div>
                      <div className="text-2xl font-bold">{report.totalSegments}</div>
                    </div>
                    <div className="bg-muted/50 p-4 rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <Clock className="h-4 w-4 text-primary" />
                        <span className="text-sm font-medium">Gebuchte Zeit</span>
                      </div>
                      <div className="text-2xl font-bold">{report.totalBookedTime} Min.</div>
                    </div>
                    <div className="bg-muted/50 p-4 rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <Calendar className="h-4 w-4 text-primary" />
                        <span className="text-sm font-medium">Events mit Platz</span>
                      </div>
                      <div className="text-2xl font-bold">
                        {report.events.filter(e => e.availableDuration > 0).length}
                      </div>
                    </div>
                  </div>

                  {/* Quick Stats */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Quick Stats</h3>
                    
                    {/* Storylines mit wenig Segmenten */}
                    <div>
                      <h4 className="text-sm font-medium mb-2 text-muted-foreground">Storylines die mehr Segmente brauchen:</h4>
                      <div className="space-y-2">
                        {report.storylines
                          .filter(s => s.segments.length < 3)
                          .map(storyline => (
                            <div key={storyline.storyline.id} className="flex items-center justify-between p-2 bg-muted/30 rounded">
                              <span className="text-sm">{storyline.storyline.title}</span>
                              <Badge variant="outline">{storyline.segments.length} Segmente</Badge>
                            </div>
                          ))}
                        {report.storylines.filter(s => s.segments.length < 3).length === 0 && (
                          <p className="text-sm text-muted-foreground">Alle Storylines haben ausreichend Segmente</p>
                        )}
                      </div>
                    </div>

                    {/* Events mit verfügbarer Zeit */}
                    <div>
                      <h4 className="text-sm font-medium mb-2 text-muted-foreground">Events mit verfügbarer Zeit:</h4>
                      <div className="space-y-2">
                        {report.events
                          .filter(e => e.availableDuration > 0)
                          .map(event => (
                            <div key={event.event.id} className="flex items-center justify-between p-2 bg-muted/30 rounded">
                              <span className="text-sm">{event.event.title}</span>
                              <Badge variant="outline">{event.availableDuration} Min. verfügbar</Badge>
                            </div>
                          ))}
                        {report.events.filter(e => e.availableDuration > 0).length === 0 && (
                          <p className="text-sm text-muted-foreground">Keine Events mit verfügbarer Zeit</p>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </ScrollArea>
            </TabsContent>

            {/* Storylines Tab */}
            <TabsContent value="storylines" className="flex-1 overflow-hidden">
              <ScrollArea className="h-full pr-4">
                <div className="space-y-4">
                  {report.storylines.map((storylineReport, index) => (
                    <div key={storylineReport.storyline.id} className="border rounded-lg p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h3 className="font-semibold flex items-center gap-2">
                            <div
                              className="h-3 w-3 rounded-full"
                              style={{ backgroundColor: storylineReport.storyline.color }}
                            />
                            {storylineReport.storyline.title}
                          </h3>
                          <p className="text-sm text-muted-foreground">
                            {storylineReport.storyline.type === 'main' ? 'Main Story' : 'Side Story'} • 
                            {storylineReport.segments.length} Segmente • 
                            {storylineReport.totalSegmentTime} Minuten
                          </p>
                        </div>
                        <Badge variant={storylineReport.storyline.status === 'active' ? 'default' : 'outline'}>
                          {storylineReport.storyline.status === 'active' ? 'Aktiv' : storylineReport.storyline.status}
                        </Badge>
                      </div>

                      {/* Charaktere */}
                      <div className="mb-3">
                        <h4 className="text-sm font-medium mb-2">Charaktere:</h4>
                        <div className="flex flex-wrap gap-1">
                          {storylineReport.characters.map(character => (
                            <Badge key={character.id} variant="secondary" className="text-xs">
                              {character.name}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      {/* Event-Zuordnungen */}
                      {storylineReport.eventAssignments.length > 0 && (
                        <div className="mb-3">
                          <h4 className="text-sm font-medium mb-2">Event-Zuordnungen:</h4>
                          <div className="space-y-1">
                            {storylineReport.eventAssignments.map(assignment => (
                              <div key={assignment.eventId} className="text-sm text-muted-foreground">
                                • {assignment.eventType} #{assignment.eventNumber}: {assignment.eventTitle} ({assignment.totalBookedTime} Min.)
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Verfügbare Events */}
                      {storylineReport.availableEvents.length > 0 && (
                        <div>
                          <h4 className="text-sm font-medium mb-2">Verfügbare Events für Fortsetzung:</h4>
                          <div className="space-y-1">
                            {storylineReport.availableEvents.map(event => {
                              const timeAllocation = report.events.find(e => e.event.id === event.id)
                              return (
                                <div key={event.id} className="text-sm text-muted-foreground">
                                  • {event.eventType} #{event.eventNumber}: {event.title} ({timeAllocation?.availableDuration || 0} Min. verfügbar)
                                </div>
                              )
                            })}
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </TabsContent>

            {/* Events Tab */}
            <TabsContent value="events" className="flex-1 overflow-hidden">
              <ScrollArea className="h-full pr-4">
                <div className="space-y-4">
                  {report.events.map((eventAllocation, index) => (
                    <div key={eventAllocation.event.id} className="border rounded-lg p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h3 className="font-semibold">
                            {eventAllocation.event.eventType} #{eventAllocation.event.eventNumber}: {eventAllocation.event.title}
                          </h3>
                          <p className="text-sm text-muted-foreground">
                            Status: {eventAllocation.event.status === 'planning' ? 'In Planung' : eventAllocation.event.status}
                          </p>
                        </div>
                        <Badge variant={eventAllocation.availableDuration > 0 ? 'default' : 'outline'}>
                          {eventAllocation.availableDuration > 0 ? `${eventAllocation.availableDuration} Min. verfügbar` : 'Voll'}
                        </Badge>
                      </div>

                      {/* Zeit-Allokation */}
                      <div className="mb-3">
                        <div className="flex items-center justify-between text-sm mb-1">
                          <span>Zeit-Allokation</span>
                          <span>{eventAllocation.bookedDuration}/{eventAllocation.totalDuration} Minuten</span>
                        </div>
                        <div className="w-full bg-muted rounded-full h-2">
                          <div 
                            className="bg-primary h-2 rounded-full" 
                            style={{ width: `${(eventAllocation.bookedDuration / eventAllocation.totalDuration) * 100}%` }}
                          />
                        </div>
                      </div>

                      {/* Zugewiesene Storylines */}
                      {eventAllocation.assignedStorylines.length > 0 && (
                        <div>
                          <h4 className="text-sm font-medium mb-2">Zugewiesene Storylines:</h4>
                          <div className="flex flex-wrap gap-1">
                            {eventAllocation.assignedStorylines.map(storylineId => {
                              const storyline = report.storylines.find(s => s.storyline.id === storylineId)
                              return storyline ? (
                                <Badge key={storylineId} variant="secondary" className="text-xs">
                                  {storyline.storyline.title}
                                </Badge>
                              ) : null
                            })}
                          </div>
                        </div>
                      )}

                      {eventAllocation.availableDuration > 0 && (
                        <div className="mt-3 p-2 bg-green-50 dark:bg-green-900/20 rounded text-sm">
                          <strong>EMPFEHLUNG:</strong> {eventAllocation.availableDuration} Minuten für neue Segmente verfügbar
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </TabsContent>

            {/* Vollständiger Bericht Tab */}
            <TabsContent value="report" className="flex-1 overflow-hidden">
              <ScrollArea className="h-full pr-4">
                <pre className="text-xs font-mono whitespace-pre-wrap bg-muted/30 p-4 rounded">
                  {exportReportAsText(report)}
                </pre>
              </ScrollArea>
            </TabsContent>
          </Tabs>
        </div>
      </DialogContent>
    </Dialog>
  )
}
