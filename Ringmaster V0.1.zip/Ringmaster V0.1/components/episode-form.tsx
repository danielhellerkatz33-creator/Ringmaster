"use client"

import type React from "react"
import { useState, useEffect, useRef } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useSeries } from "@/lib/series-context"
import { useEventStyle } from "@/lib/event-style-context"
import type { Event } from "@/lib/types"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Upload, X, ImageIcon, CheckCircle } from "lucide-react"

interface EpisodeFormProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  episode?: Event
}

export function EpisodeForm({ open, onOpenChange, episode }: EpisodeFormProps) {
  const { data, addEpisode, updateEpisode } = useSeries()
  const { eventStyle } = useEventStyle()
  const [eventType, setEventType] = useState<"Weekly TV" | "PPV" | "TV-Special">("Weekly TV")
  const [eventNumber, setEventNumber] = useState(1)
  const [title, setTitle] = useState("")
  const [status, setStatus] = useState<Event["status"]>("planning")
  const [notes, setNotes] = useState("")
  const [airDate, setAirDate] = useState("")
  const [imageUrl, setImageUrl] = useState("")
  const [showCompletionDialog, setShowCompletionDialog] = useState(false)
  const [pendingStatus, setPendingStatus] = useState<Event["status"] | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const isEditing = !!episode

  useEffect(() => {
    if (episode) {
      setEventType(episode.eventType || "Weekly TV")
      setEventNumber(episode.eventNumber)
      setTitle(episode.title || "")
      setStatus(episode.status)
      setNotes(episode.notes)
      setAirDate(episode.airDate ? new Date(episode.airDate).toISOString().split("T")[0] : "")
      setImageUrl(episode.imageUrl || "")
    } else {
      // Auto-increment event number
      const existingEpisodes = data.episodes.filter((e) => (e.eventType || "Weekly TV") === eventType)
      setEventNumber(existingEpisodes.length + 1)
      setTitle("")
      setNotes("")
      setStatus("planning")
      setAirDate("")
      setImageUrl("")
    }
  }, [episode, open, data.episodes, eventType])

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setImageUrl(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleRemoveImage = () => {
    setImageUrl("")
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  const handleStatusChange = (newStatus: Event["status"]) => {
    if (newStatus === "completed" && status !== "completed") {
      setPendingStatus(newStatus)
      setShowCompletionDialog(true)
    } else {
      setStatus(newStatus)
    }
  }

  const confirmStatusChange = () => {
    if (pendingStatus) {
      setStatus(pendingStatus)
      setPendingStatus(null)
    }
    setShowCompletionDialog(false)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    const episodeData = {
      eventType,
      eventNumber,
      title: title.trim() || `${eventType} #${eventNumber}`,
      synopsis: "",
      status,
      notes: notes.trim(),
      sceneIds: episode?.sceneIds || [],
      airDate: airDate ? new Date(airDate) : undefined,
      imageUrl: imageUrl || undefined,
    }

    if (isEditing) {
      updateEpisode({
        ...episode,
        ...episodeData,
      })
    } else {
      addEpisode(episodeData)
    }

    onOpenChange(false)
  }

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>{isEditing ? "Event bearbeiten" : "Neues Event erstellen"}</DialogTitle>
            <DialogDescription>
              {isEditing
                ? "Bearbeite die Details dieses Events."
                : "Erstelle ein neues Event für deine Promotion."
              }
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-2">
              <Label>Titelbild</Label>
              <div className="flex items-start gap-4">
                {imageUrl ? (
                  <div className="relative">
                    <img
                      src={imageUrl || "/placeholder.svg"}
                      alt="Titelbild"
                      className={`object-cover rounded-lg transition-all duration-200 hover:scale-105 ${
                        eventStyle === "style1" 
                          ? "w-28 h-18 md:w-32 md:h-20" 
                          : "w-36 h-22 md:w-40 md:h-24"
                      }`}
                    />
                    <Button
                      type="button"
                      variant="destructive"
                      size="icon"
                      className="absolute -top-2 -right-2 h-6 w-6"
                      onClick={handleRemoveImage}
                    >
                      <X className="h-3 w-3" />
                    </Button>
                  </div>
                ) : (
                  <div
                    className={`border-2 border-dashed border-muted-foreground/25 rounded-lg flex flex-col items-center justify-center cursor-pointer hover:border-muted-foreground/50 transition-colors ${
                      eventStyle === "style1" 
                        ? "w-28 h-18 md:w-32 md:h-20" 
                        : "w-36 h-22 md:w-40 md:h-24"
                    }`}
                    onClick={() => fileInputRef.current?.click()}
                  >
                    <ImageIcon className={`text-muted-foreground mb-1 ${
                      eventStyle === "style1" 
                        ? "h-6 w-6 md:h-6 md:w-6" 
                        : "h-7 w-7 md:h-8 md:w-8"
                    }`} />
                    <span className="text-xs text-muted-foreground">Hochladen</span>
                  </div>
                )}
                <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
                {!imageUrl && (
                  <Button type="button" variant="outline" size="sm" onClick={() => fileInputRef.current?.click()}>
                    <Upload className="h-4 w-4 mr-2" />
                    Bild wählen
                  </Button>
                )}
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="title">Event-Name</Label>
              <Input
                id="title"
                placeholder="z.B. WrestleMania, SummerSlam, oder leer lassen für Auto-Generierung"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="eventType">Event-Typ</Label>
                <Select value={eventType} onValueChange={(value: "Weekly TV" | "PPV" | "TV-Special") => setEventType(value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Weekly TV">Weekly TV</SelectItem>
                    <SelectItem value="PPV">PPV</SelectItem>
                    <SelectItem value="TV-Special">TV-Special</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="episode">Event-Nummer</Label>
                <Input
                  id="episode"
                  type="number"
                  min={1}
                  value={eventNumber}
                  onChange={(e) => setEventNumber(Number.parseInt(e.target.value) || 1)}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="airDate">Event-Datum</Label>
              <Input id="airDate" type="date" value={airDate} onChange={(e) => setAirDate(e.target.value)} />
            </div>

            <div className="space-y-2">
              <Label>Status</Label>
              <Select value={status} onValueChange={(v) => handleStatusChange(v as Event["status"])}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="planning">In Planung</SelectItem>
                  <SelectItem value="writing">In Arbeit</SelectItem>
                  <SelectItem value="production">Produktion</SelectItem>
                  <SelectItem value="completed">Abgeschlossen</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">Notizen</Label>
              <Textarea
                id="notes"
                placeholder="Zusätzliche Notizen..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={2}
              />
            </div>

            <div className="flex justify-end gap-2 pt-4">
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                Abbrechen
              </Button>
              <Button type="submit">
                {isEditing ? "Speichern" : "Erstellen"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Bestätigungsdialog für Event-Abschluss */}
      <AlertDialog open={showCompletionDialog} onOpenChange={setShowCompletionDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Event abschließen?</AlertDialogTitle>
            <AlertDialogDescription>
              Wenn du dieses Event auf "Abgeschlossen" setzt, wird automatisch ein detaillierter Bericht erstellt, der:
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="space-y-3 my-4">
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle className="h-4 w-4 text-green-500" />
              <span>Alle Segmente zusammenfassen</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle className="h-4 w-4 text-green-500" />
              <span>Character-Auftritte analysieren</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle className="h-4 w-4 text-green-500" />
              <span>Storyline-Fortschritt dokumentieren</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle className="h-4 w-4 text-green-500" />
              <span>Automatische Zusammenfassung erstellen</span>
            </div>
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => {
              setShowCompletionDialog(false)
              setPendingStatus(null)
            }}>
              Abbrechen
            </AlertDialogCancel>
            <AlertDialogAction onClick={confirmStatusChange}>
              Event abschließen und Bericht erstellen
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}
