"use client"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { useSeries } from "@/lib/series-context"
import { useLanguage } from "@/hooks/use-language"
import type { Mood } from "@/lib/types"

interface MoodFormProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  mood?: Mood
}

export function MoodForm({ open, onOpenChange, mood }: MoodFormProps) {
  const { addMood, updateMood } = useSeries()
  const { t } = useLanguage()
  const [name, setName] = useState(mood?.name || "")
  const [description, setDescription] = useState(mood?.description || "")
  const [isActive, setIsActive] = useState(mood?.isActive ?? true)

  const isEditing = !!mood

  useEffect(() => {
    if (open) {
      if (mood) {
        setName(mood.name)
        setDescription(mood.description)
        setIsActive(mood.isActive)
      } else {
        setName("")
        setDescription("")
        setIsActive(true)
      }
    }
  }, [open, mood])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!name.trim()) return

    if (isEditing && mood) {
      updateMood({
        ...mood,
        name: name.trim(),
        description: description.trim(),
        isActive,
      })
    } else {
      addMood({
        name: name.trim(),
        description: description.trim(),
        isActive,
      })
    }

    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{isEditing ? "Stimmung bearbeiten" : "Neue Stimmung"}</DialogTitle>
          <DialogDescription>
            {isEditing ? "Bearbeite die Details der Stimmung." : "Erstelle eine neue Stimmung für deine Serie."}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Name *</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="z.B. Angespannt, Fröhlich, Düster..."
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Beschreibung</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Optionale Beschreibung der Stimmung..."
              rows={3}
            />
          </div>

          <div className="flex items-center space-x-2">
            <Switch
              id="isActive"
              checked={isActive}
              onCheckedChange={setIsActive}
            />
            <Label htmlFor="isActive">Aktiv</Label>
          </div>
          <p className="text-sm text-muted-foreground">
            Nur aktive Stimmungen sind bei der Szenenerstellung im Dropdown verfügbar.
          </p>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
{t.common.cancel}
            </Button>
            <Button type="submit" disabled={!name.trim()}>
{isEditing ? t.common.save : t.common.create}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}