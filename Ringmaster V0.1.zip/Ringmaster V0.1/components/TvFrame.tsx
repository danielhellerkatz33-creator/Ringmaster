"use client";

import type { ReactNode } from "react";

export function TvFrame({ children }: { children: ReactNode }) {
  return (
    <div className="tv-wrap">
      <div className="tv-frame">
        <div className="tv-screen-cutout">
          <div className="tv-screen-inner">{children}</div>
        </div>
        <div className="tv-glass" />
      </div>
    </div>
  );
}