"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { X } from "lucide-react"
import { useSeries } from "@/lib/series-context"
import type { Storyline } from "@/lib/types"

interface StorylineFormProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  storyline?: Storyline
}

const colorOptions = [
  { value: "#ff4757", label: "Hellrot" },
  { value: "#ff793f", label: "Orange" },
  { value: "#ffb142", label: "Gelb" },
  { value: "#37d67a", label: "Hellgrün" },
  { value: "#34ace0", label: "Türkis" },
  { value: "#3742fa", label: "Himmelblau" },
  { value: "#2f3542", label: "Dunkelblau" },
  { value: "#1e3799", label: "Navy" },
  { value: "#9c88ff", label: "Lila" },
  { value: "#c44569", label: "Magenta" },
  { value: "#f8a5c2", label: "Pink" },
  { value: "#e84393", label: "Fuchsia" },
  { value: "#a4b0be", label: "Braun" },
  { value: "#7bed9f", label: "Olivgrün" },
  { value: "#57606f", label: "Grau" },
  { value: "#ffffff", label: "Weiß" },
]

export function StorylineForm({ open, onOpenChange, storyline }: StorylineFormProps) {
  const { data, addStoryline, updateStoryline } = useSeries()
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [type, setType] = useState<Storyline["type"]>("main")
  const [status, setStatus] = useState<Storyline["status"]>("planning")
  const [color, setColor] = useState(colorOptions[0].value)
  const [selectedCharacters, setSelectedCharacters] = useState<string[]>([])
  const [storylineQuestions, setStorylineQuestions] = useState("")

  const isEditing = !!storyline

  useEffect(() => {
    if (storyline) {
      setTitle(storyline.title)
      setDescription(storyline.description)
      setType(storyline.type)
      setStatus(storyline.status)
      setColor(storyline.color)
      setSelectedCharacters(storyline.characterIds)
      setStorylineQuestions(storyline.storylineQuestions || "")
    } else {
      resetForm()
    }
  }, [storyline, open])

  const resetForm = () => {
    setTitle("")
    setDescription("")
    setType("main")
    setStatus("planning")
    setColor(colorOptions[0].value)
    setSelectedCharacters([])
    setStorylineQuestions("")
  }

  const toggleCharacter = (charId: string) => {
    setSelectedCharacters((prev) => (prev.includes(charId) ? prev.filter((id) => id !== charId) : [...prev, charId]))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!title.trim()) return

    const storylineData = {
      title: title.trim(),
      description: description.trim(),
      type,
      status,
      color,
      characterIds: selectedCharacters,
      storylineQuestions: storylineQuestions.trim() || undefined,
    }

    if (isEditing) {
      updateStoryline({
        ...storyline,
        ...storylineData,
      })
    } else {
      addStoryline(storylineData)
    }

    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{isEditing ? "Storyline bearbeiten" : "Neue Storyline erstellen"}</DialogTitle>
          <DialogDescription>
            {isEditing
              ? "Bearbeite die Details dieser Storyline."
              : "Erstelle eine neue Storyline für deine Promotion."
            }
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="space-y-2">
            <Label htmlFor="title">Titel</Label>
            <Input
              id="title"
              placeholder="z.B. Walters Transformation"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Beschreibung</Label>
            <Textarea
              id="description"
              placeholder="Beschreibe den Handlungsstrang..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="storylineQuestions">Fragenkatalog zur Story</Label>
            <Textarea
              id="storylineQuestions"
              placeholder="Füge hier einen beantworteten Fragenkatalog ein, der ChatGPT bei der Generierung neuer Segmente hilft..."
              value={storylineQuestions}
              onChange={(e) => setStorylineQuestions(e.target.value)}
              rows={6}
              className="text-sm"
            />
            <p className="text-xs text-muted-foreground">
              Dieser Fragenkatalog wird im State Of The Art Bericht verwendet und hilft ChatGPT bei der Generierung neuer Segmente.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Typ</Label>
              <Select value={type} onValueChange={(v) => setType(v as Storyline["type"])}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="main">Main Story</SelectItem>
                  <SelectItem value="subplot">Side Story</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Status</Label>
              <Select value={status} onValueChange={(v) => setStatus(v as Storyline["status"])}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="planning">In Planung</SelectItem>
                  <SelectItem value="active">Aktiv</SelectItem>
                  <SelectItem value="paused">Pausiert</SelectItem>
                  <SelectItem value="completed">Abgeschlossen</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Farbe</Label>
            <div className="grid grid-cols-8 gap-2">
              {colorOptions.map((opt) => (
                <button
                  key={opt.value}
                  type="button"
                  className={`h-8 w-8 rounded-full border-2 transition-all ${
                    color === opt.value ? "border-foreground scale-110" : "border-transparent"
                  }`}
                  style={{ backgroundColor: opt.value }}
                  onClick={() => setColor(opt.value)}
                />
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Label>Beteiligte Charaktere</Label>
            {data.characters.length === 0 ? (
              <p className="text-sm text-muted-foreground">Erstelle zuerst Charaktere.</p>
            ) : (
              <div className="flex flex-wrap gap-2">
                {[...data.characters]
                  .filter((char) => char.status === "active")
                  .sort((a, b) => a.name.localeCompare(b.name))
                  .map((char) => (
                  <Badge
                    key={char.id}
                    variant={selectedCharacters.includes(char.id) ? "default" : "outline"}
                    className="cursor-pointer"
                    onClick={() => toggleCharacter(char.id)}
                  >
                    {char.name}
                    {selectedCharacters.includes(char.id) && <X className="h-3 w-3 ml-1" />}
                  </Badge>
                ))}
              </div>
            )}
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Abbrechen
            </Button>
            <Button type="submit" disabled={!title.trim()}>
              {isEditing ? "Speichern" : "Erstellen"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
