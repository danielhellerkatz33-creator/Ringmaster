'use client'

import * as React from 'react'
import { Monitor, Sun, Palette, Heart, Trophy, Zap, Flame, Users, Guitar, Star, Zap as NxtIcon } from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { useSkin, type Skin } from '@/lib/skin-context'
import { useLanguage } from '@/hooks/use-language'

const skinConfig = {
  dark: {
    icon: Monitor,
    label: 'Dark',
    description: 'Klassisches dunkles Design'
  },
  light: {
    icon: Sun,
    label: 'Light',
    description: 'Elegantes Lila-Design'
  },
  retro: {
    icon: Palette,
    label: 'Retro-90s',
    description: '1992 Redaktionscomputer'
  },
  soap: {
    icon: Heart,
    label: 'Daily Soap',
    description: 'Wohnliches GZSZ-Gefühl'
  },
  arena: {
    icon: Trophy,
    label: 'Arena',
    description: 'Spotlight-Ästhetik mit Rodeo-Farben'
  },
  championship: {
    icon: Star,
    label: 'Championship',
    description: 'Luxuriöse Goldtöne wie Titelgürtel'
  },
  attitude: {
    icon: Flame,
    label: 'Attitude Era',
    description: '90s WWF - rau und kantig'
  },
  lucha: {
    icon: Users,
    label: 'Lucha Libre',
    description: 'Mexikanische Farben und Masken'
  },
  indie: {
    icon: Guitar,
    label: 'Indie Wrestling',
    description: 'Roh & unpoliert wie High School Gym'
  },
  puroresu: {
    icon: Zap,
    label: 'Puroresu',
    description: 'Japanisches Stoisch-Dojo Design'
  },
  nxt: {
    icon: NxtIcon,
    label: 'Modern NXT',
    description: 'Jugendlich energiegeladen in Gelb-Schwarz'
  }
} as const

export function SkinToggle() {
  const { skin, setSkin } = useSkin()
  const { t } = useLanguage()

  const currentSkin = skinConfig[skin]
  const CurrentIcon = currentSkin.icon

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="outline"
          size="sm"
          className="modern-secondary-button h-10 px-3 rounded-full border-2 border-border/50 hover:border-primary/30 transition-all duration-300 hover:scale-105"
          title="Skin wechseln"
        >
          <CurrentIcon className="h-4 w-4 mr-2" />
          <span className="hidden sm:inline text-sm font-medium">
            {currentSkin.label}
          </span>
          <span className="sm:hidden text-sm font-medium">
            {currentSkin.label.slice(0, 1)}
          </span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        {(Object.entries(skinConfig) as [Skin, typeof skinConfig[Skin]][]).map(([skinKey, config]) => {
          const Icon = config.icon
          const isActive = skin === skinKey

          return (
            <DropdownMenuItem
              key={skinKey}
              onClick={() => setSkin(skinKey)}
              className={`flex items-center gap-3 p-3 cursor-pointer ${
                isActive ? 'bg-accent text-accent-foreground' : ''
              }`}
            >
              <Icon className="h-4 w-4" />
              <div className="flex flex-col">
                <span className="font-medium text-sm">{config.label}</span>
                <span className="text-xs text-muted-foreground">{config.description}</span>
              </div>
              {isActive && (
                <div className="ml-auto w-2 h-2 rounded-full bg-primary" />
              )}
            </DropdownMenuItem>
          )
        })}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}