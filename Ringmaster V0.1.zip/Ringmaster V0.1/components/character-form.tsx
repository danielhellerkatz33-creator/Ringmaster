"use client"

import type React from "react"
import { useState, useRef, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { X, Upload } from "lucide-react"
import { useSeries } from "@/lib/series-context"
import type { Character } from "@/lib/types"

interface CharacterFormProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  character?: Character
}

const roleOptions = [
  { value: "protagonist", label: "Protagonist" },
  { value: "antagonist", label: "Antagonist" },
  { value: "supporting", label: "Nebenrolle" },
  { value: "recurring", label: "Wiederkehrend" },
  { value: "guest", label: "Gastrolle" },
  { value: "paused", label: "Pause" },
  { value: "deceased", label: "Verstorben" },
  { value: "inactive", label: "Inaktiv" },
]

export function CharacterForm({ open, onOpenChange, character }: CharacterFormProps) {
  const { addCharacter, updateCharacter, uploadAvatar, getAvatarUrl, storageReady } = useSeries()
  const [name, setName] = useState(character?.name || "")
  const [position, setPosition] = useState<Character["position"]>(character?.position || "mid_card")
  const [alignment, setAlignment] = useState<Character["alignment"]>(character?.alignment || "face")
  const [status, setStatus] = useState<Character["status"]>(character?.status || "active")
  const [hometown, setHometown] = useState(character?.hometown || "")
  const [imageUrl, setImageUrl] = useState<string | undefined>(character?.imageUrl)
  const [avatarBlobId, setAvatarBlobId] = useState<string | undefined>(character?.avatarBlobId)
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null)
  const [isUploading, setIsUploading] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const isEditing = !!character

  useEffect(() => {
    if (open) {
      if (character) {
        setName(character.name)
        setPosition(character.position)
        setAlignment(character.alignment)
        setStatus(character.status)
        setHometown(character.hometown || "")
        setImageUrl(character.imageUrl)
        setAvatarBlobId(character.avatarBlobId)

        // Load avatar from IndexedDB if available
        if (character.avatarBlobId && storageReady) {
          getAvatarUrl(character).then((url) => {
            // Clean up previous URL to prevent memory leaks
            if (avatarUrl) {
              URL.revokeObjectURL(avatarUrl)
            }
            setAvatarUrl(url)
          })
        } else {
          // Clean up URL when not using blob
          if (avatarUrl) {
            URL.revokeObjectURL(avatarUrl)
          }
          setAvatarUrl(null)
        }
      } else {
        resetForm()
      }
    }
  }, [open, character, storageReady, getAvatarUrl])

  // Clean up URLs on unmount
  useEffect(() => {
    return () => {
      if (avatarUrl) {
        URL.revokeObjectURL(avatarUrl)
      }
    }
  }, [avatarUrl])

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    if (!file.type.startsWith("image/")) {
      return
    }

    // Check file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      alert("Bild ist zu groß. Maximale Größe: 5MB")
      return
    }

    if (storageReady && character) {
      // Use IndexedDB for storage
      setIsUploading(true)
      try {
        const blobId = await uploadAvatar(character.id, file)
        setAvatarBlobId(blobId) // Store blobId locally to prevent stale props overwrite
        // Clean up previous URL and create new one
        if (avatarUrl) {
          URL.revokeObjectURL(avatarUrl)
        }
        const url = URL.createObjectURL(file)
        setAvatarUrl(url)
        setImageUrl(undefined) // Clear external URL when using blob
      } catch (error) {
        console.error("Failed to upload avatar:", error)
        // Fallback to base64
        const reader = new FileReader()
        reader.onloadend = () => {
          setImageUrl(reader.result as string)
          setAvatarBlobId(undefined) // Clear blobId since we're using base64
        }
        reader.readAsDataURL(file)
      } finally {
        setIsUploading(false)
      }
    } else {
      // Fallback to base64 for new characters or when IndexedDB is not ready
      const reader = new FileReader()
      reader.onloadend = () => {
        setImageUrl(reader.result as string)
        setAvatarBlobId(undefined) // Clear blobId since we're using base64
      }
      reader.readAsDataURL(file)
    }
  }

  const removeImage = () => {
    setImageUrl(undefined)
    setAvatarBlobId(undefined)
    if (avatarUrl) {
      URL.revokeObjectURL(avatarUrl)
    }
    setAvatarUrl(null)
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      e.preventDefault()
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!name.trim()) return


    const characterData = {
      name: name.trim(),
      position,
      alignment,
      status,
      hometown: hometown.trim() || undefined,
      imageUrl,
      // Use local avatarBlobId state to prevent stale props overwrite
      ...(avatarBlobId && { avatarBlobId }),
    }

    if (isEditing) {
      updateCharacter({
        ...character,
        ...characterData,
      })
    } else {
      addCharacter(characterData)
    }

    onOpenChange(false)
    resetForm()
  }

  const resetForm = () => {
    setName("")
    setPosition("mid_card")
    setAlignment("face")
    setStatus("active")
    setHometown("")
    setImageUrl(undefined)
    setAvatarBlobId(undefined)
    if (avatarUrl) {
      URL.revokeObjectURL(avatarUrl)
    }
    setAvatarUrl(null)
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{isEditing ? "Charakter bearbeiten" : "Neuen Charakter erstellen"}</DialogTitle>
          <DialogDescription>
            {isEditing
              ? "Bearbeite die Details dieses Charakters."
              : "Erstelle einen neuen Charakter für deine Serie."
            }
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="space-y-2">
            <Label>Profilbild</Label>
            <div className="flex items-center gap-4">
              {(imageUrl || avatarUrl) ? (
                <div className="relative">
                  <div className="h-20 w-20 rounded-full overflow-hidden">
                    <img src={avatarUrl || imageUrl || "/placeholder.svg"} alt="Vorschau" className="h-full w-full object-cover" />
                  </div>
                  <Button
                    type="button"
                    variant="destructive"
                    size="icon"
                    className="absolute -top-1 -right-1 h-6 w-6"
                    onClick={removeImage}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </div>
              ) : (
                <div
                  className="h-20 w-20 rounded-full bg-muted border-2 border-dashed border-muted-foreground/25 flex items-center justify-center cursor-pointer hover:border-primary/50 transition-colors"
                  onClick={() => !isUploading && fileInputRef.current?.click()}
                >
                  <Upload className="h-6 w-6 text-muted-foreground" />
                </div>
              )}
              <div className="flex-1">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                  disabled={isUploading}
                />
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => !isUploading && fileInputRef.current?.click()}
                  disabled={isUploading}
                >
                  {isUploading ? "Lädt..." : (imageUrl || avatarUrl) ? "Bild ändern" : "Bild hochladen"}
                </Button>
                <p className="text-xs text-muted-foreground mt-1">
                  JPG, PNG oder GIF. Max 5MB.
                  {storageReady ? " Gespeichert in IndexedDB." : " Fallback: Base64."}
                </p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Name</Label>
              <Input
                id="name"
                placeholder="z.B. Walter White"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="position">Position</Label>
              <Select value={position} onValueChange={(v) => setPosition(v as Character["position"])}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="main_event">Main Event</SelectItem>
                  <SelectItem value="upper_card">Upper Card</SelectItem>
                  <SelectItem value="mid_card">Mid Card</SelectItem>
                  <SelectItem value="lower_card">Lower Card</SelectItem>
                  <SelectItem value="jobber">Jobber</SelectItem>
                  <SelectItem value="road_agent">Road Agent</SelectItem>
                  <SelectItem value="manager">Manager</SelectItem>
                  <SelectItem value="staff">Staff</SelectItem>
                  <SelectItem value="commentary">Commentary</SelectItem>
                  <SelectItem value="referee">Referee</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="alignment">Alignment</Label>
              <Select value={alignment} onValueChange={(v) => setAlignment(v as Character["alignment"])}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="face">Face</SelectItem>
                  <SelectItem value="heel">Heel</SelectItem>
                  <SelectItem value="tweener">Tweener</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Select value={status} onValueChange={(v) => setStatus(v as Character["status"])}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="injured">Injured</SelectItem>
                  <SelectItem value="suspended">Suspended</SelectItem>
                  <SelectItem value="retired">Retired</SelectItem>
                  <SelectItem value="inactive">Inactive</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="hometown">Heimatstadt/Staat</Label>
            <Input
              id="hometown"
              placeholder="z.B. Los Angeles, Kalifornien"
              value={hometown}
              onChange={(e) => setHometown(e.target.value)}
            />
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Abbrechen
            </Button>
            <Button type="submit" disabled={!name.trim()}>
              {isEditing ? "Speichern" : "Erstellen"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
