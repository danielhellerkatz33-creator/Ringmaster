import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { CharacterAvatar } from "@/components/character-avatar"
import { Users, ScrollText, CheckCircle2, Circle, Eye, Copy, MessageSquare } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import type { Storyline, Character, Segment } from "@/lib/types"
import Link from "next/link"
import { useState } from "react"

interface StorySummaryCardProps {
  storyline: Storyline
  characters: Character[]
  scenes: Segment[]
  onViewDetails?: () => void
}

const typeLabels: Record<Storyline["type"], string> = {
  main: "Haupthandlung",
  subplot: "Nebenhandlung",
}

const typeColors: Record<Storyline["type"], string> = {
  main: "bg-blue-500",
  subplot: "bg-green-500",
}

export function StorySummaryCard({ storyline, characters, scenes, onViewDetails }: StorySummaryCardProps) {
  const { toast } = useToast()
  const [copied, setCopied] = useState(false)
  const hasSummary = !!storyline.summary
  const hasCharacterReview = !!storyline.characterReview

  const getCompletionStatus = () => {
    if (hasSummary && hasCharacterReview) return "complete"
    if (hasSummary || hasCharacterReview) return "partial"
    return "empty"
  }

  const completionStatus = getCompletionStatus()

  const getStatusIcon = () => {
    switch (completionStatus) {
      case "complete":
        return <CheckCircle2 className="h-4 w-4 text-green-500" />
      case "partial":
        return <Circle className="h-4 w-4 text-yellow-500 fill-yellow-500" />
      case "empty":
        return <Circle className="h-4 w-4 text-red-500" />
    }
  }

  const getStatusText = () => {
    switch (completionStatus) {
      case "complete":
        return "Vollständig"
      case "partial":
        return "Teilweise"
      case "empty":
        return "Leer"
    }
  }

  const copyForChatGPT = async () => {
    try {
      let content = `# ${storyline.title}\n\n`

      if (storyline.description) {
        content += `## Beschreibung\n${storyline.description}\n\n`
      }

      if (hasCharacterReview) {
        content += `## Charakterrückblick\n${storyline.characterReview}\n\n`
      }

      if (hasSummary) {
        content += `## Zusammenfassung\n${storyline.summary}\n\n`
      }

      content += `## Statistiken\n- Charaktere: ${characters.length}\n- Szenen: ${scenes.length}\n- Typ: ${typeLabels[storyline.type]}\n\n`

      await navigator.clipboard.writeText(content)

      // Visuelles Feedback auf dem Button
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)

      toast({
        title: "Für ChatGPT kopiert",
        description: "Story-Inhalte wurden in die Zwischenablage kopiert.",
      })
    } catch (error) {
      console.error("Failed to copy to clipboard:", error)
      toast({
        title: "Fehler beim Kopieren",
        description: "Die Inhalte konnten nicht kopiert werden.",
        variant: "destructive",
      })
    }
  }

  return (
    <Card className="hover:shadow-md transition-shadow cursor-pointer group relative z-10">
      <CardContent className="p-4">
        {/* Header mit Titel und Status */}
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-start gap-3 flex-1 min-w-0">
            <div
              className={`h-3 w-3 rounded-full mt-1.5 shrink-0 ${typeColors[storyline.type]}`}
            />
            <div className="flex-1 min-w-0">
              <h3 className="font-medium text-foreground leading-tight truncate group-hover:text-primary transition-colors">
                {storyline.title}
              </h3>
              <div className="flex items-center gap-2 mt-1">
                <Badge variant="outline" className="text-xs">
                  {typeLabels[storyline.type]}
                </Badge>
                <div className="flex items-center gap-1 text-xs text-muted-foreground">
                  {getStatusIcon()}
                  {getStatusText()}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Beschreibung */}
        {storyline.description && (
          <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
            {storyline.description}
          </p>
        )}

        {/* Charaktere Avatare */}
        {characters.length > 0 && (
          <div className="flex -space-x-2 mb-3">
            {characters.slice(0, 3).map((char) => (
              <CharacterAvatar
                key={char.id}
                name={char.name}
                imageUrl={char.imageUrl}
                character={char}
                size="sm"
                className="border-2 border-card ring-1 ring-background"
              />
            ))}
            {characters.length > 3 && (
              <div className="h-7 w-7 rounded-full bg-muted border-2 border-card flex items-center justify-center ring-1 ring-background">
                <span className="text-xs font-medium">+{characters.length - 3}</span>
              </div>
            )}
          </div>
        )}

        {/* Statistiken */}
        <div className="flex items-center justify-between text-xs text-muted-foreground mb-4">
          <div className="flex items-center gap-1">
            <Users className="h-3 w-3" />
            <span>{characters.length} Charaktere</span>
          </div>
          <div className="flex items-center gap-1">
            <ScrollText className="h-3 w-3" />
            <span>{scenes.length} Szenen</span>
          </div>
        </div>

        {/* Inhalts-Indikatoren */}
        <div className="flex items-center gap-2 mb-4">
          <div className={`flex items-center gap-1 text-xs px-2 py-1 rounded-full ${
            hasSummary ? "bg-accent/10 text-accent-foreground border border-accent/20" : "bg-muted text-muted-foreground"
          }`}>
            <ScrollText className="h-3 w-3" />
            Zusammenfassung
          </div>
          <div className={`flex items-center gap-1 text-xs px-2 py-1 rounded-full ${
            hasCharacterReview ? "bg-primary/10 text-primary border border-primary/20" : "bg-muted text-muted-foreground"
          }`}>
            <Users className="h-3 w-3" />
            Charakterrückblick
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-2">
          {(hasSummary || hasCharacterReview) && (
            <Button
              variant="outline"
              size="sm"
              onClick={copyForChatGPT}
              className={`gap-2 flex-1 transition-all duration-200 hover:scale-[1.02] active:scale-95 ${
                copied
                  ? 'bg-accent/20 border-accent text-accent-foreground hover:bg-accent/30'
                  : 'hover:bg-accent/10 hover:border-accent hover:text-accent-foreground hover:shadow-sm'
              }`}
            >
              {copied ? (
                <CheckCircle2 className="h-4 w-4 animate-pulse" />
              ) : (
                <MessageSquare className="h-4 w-4" />
              )}
              {copied ? 'Kopiert!' : 'Für ChatGPT kopieren'}
            </Button>
          )}
          <Link href={`/story-summaries/${storyline.id}`} className="flex-1">
            <Button
              variant="outline"
              size="sm"
              className="gap-2 w-full transition-all duration-200 hover:scale-[1.02] hover:bg-accent/10 hover:border-accent hover:text-accent-foreground hover:shadow-sm active:scale-95"
              onClick={onViewDetails}
            >
              <Eye className="h-4 w-4" />
              Details ansehen
            </Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  )
}