"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { CharacterCard } from "@/components/character-card"
import { StatsCard } from "@/components/stats-card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import { Search, TrendingUp, Users, Heart, BookOpen } from "lucide-react"
import { Checkbox } from "@/components/ui/checkbox"
import { useLanguage } from "@/lib/i18n/language-context"

import type { Character } from "@/lib/types"
interface CharacterDashboardProps {
  characters: Character[]
  relationships: any[] // TODO: Add proper type
  championships?: any[] // CharacterArc[] mit Championship-Daten
  onEdit: (character: Character) => void
  onDelete: (id: string) => void
}

export function CharacterDashboard({ characters, relationships, championships, onEdit, onDelete }: CharacterDashboardProps) {
  const [search, setSearch] = useState("")
  const [roleFilter, setRoleFilter] = useState<string>("all")
  const [excludeInactiveDeceased, setExcludeInactiveDeceased] = useState(false)
  const [statusFilters, setStatusFilters] = useState({
    active: true,
    injured: false,
    suspended: false,
    retired: false,
    inactive: false
  })

  // Ensure at least one status is always selected
  const handleStatusFilterChange = (status: keyof typeof statusFilters, checked: boolean) => {
    const newFilters = { ...statusFilters, [status]: checked }
    
    // Prevent deselecting all statuses
    if (!Object.values(newFilters).some(isChecked => isChecked)) {
      return // Don't allow all checkboxes to be unchecked
    }
    
    setStatusFilters(newFilters)
  }
  const router = useRouter()
  const { t } = useLanguage()

  // Helper function to get relationship count
  const getRelationshipCount = (characterId: string) => {
    return relationships.filter((r) => {
      // Handle both old and new data structure
      const characterIds = r.characterIds || 
        ((r as any).characterId1 && (r as any).characterId2 ? 
          [(r as any).characterId1, (r as any).characterId2] : [])
      return characterIds.includes(characterId)
    }).length
  }

  // Filter and sort characters
  const filteredCharacters = characters
    .filter((char) => {
      const matchesSearch = char.name.toLowerCase().includes(search.toLowerCase())
      const matchesPosition = roleFilter === "all" || char.position === roleFilter
      const matchesStatus = Object.entries(statusFilters)
        .filter(([_, isChecked]) => isChecked)
        .some(([status]) => char.status === status)
      return matchesSearch && matchesPosition && matchesStatus
    })
    .sort((a, b) => a.name.localeCompare(b.name))

  // Calculate statistics
  const totalCharacters = characters.length
  const positionStats = characters.reduce((acc, char) => {
    acc[char.position] = (acc[char.position] || 0) + 1
    return acc
  }, {} as Record<string, number>)

  const mainEventCount = positionStats.main_event || 0
  const upperCardCount = positionStats.upper_card || 0
  const midCardCount = positionStats.mid_card || 0
  const lowerCardCount = positionStats.lower_card || 0
  const jobberCount = positionStats.jobber || 0

  return (
    <div className="flex flex-col lg:grid lg:grid-cols-4 gap-6">
      {/* Statistics Sidebar */}
      <div className="lg:col-span-1 space-y-4 order-2 lg:order-1">
        {/* Mobile: Horizontal scroll for stats cards */}
        <div className="flex lg:flex-col gap-4 overflow-x-auto lg:overflow-x-visible pb-2 lg:pb-0 min-w-0">
          <div className="flex-shrink-0 w-48 lg:w-full">
            <StatsCard
              title="Gesamt"
              value={totalCharacters.toString()}
              icon={Users}
              description={t.common.characters}
            />
          </div>

          <div className="flex-shrink-0 w-48 lg:w-full">
            <StatsCard
              title="Main Event"
              value={mainEventCount.toString()}
              icon={TrendingUp}
              description={`${Math.round((mainEventCount / totalCharacters) * 100) || 0}% aller ${t.common.characters.toLowerCase()}`}
            />
          </div>

          <div className="flex-shrink-0 w-48 lg:w-full">
            <StatsCard
              title="Upper Card"
              value={upperCardCount.toString()}
              icon={TrendingUp}
              description={`${Math.round((upperCardCount / totalCharacters) * 100) || 0}% aller ${t.common.characters.toLowerCase()}`}
            />
          </div>

          <div className="flex-shrink-0 w-48 lg:w-full">
            <StatsCard
              title="Mid Card"
              value={midCardCount.toString()}
              icon={TrendingUp}
              description={`${Math.round((midCardCount / totalCharacters) * 100) || 0}% aller ${t.common.characters.toLowerCase()}`}
            />
          </div>
        </div>

        {/* Position Distribution */}
        <div className="bg-card rounded-lg p-4 border hidden lg:block">
          <h3 className="font-semibold mb-3">Positions-Verteilung</h3>
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Main Event</span>
              <div className="flex items-center gap-2">
                <div className="w-16 h-2 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full bg-amber-500"
                    style={{ width: `${(mainEventCount / totalCharacters) * 100}%` }}
                  />
                </div>
                <span className="text-sm font-medium w-6 text-right">{mainEventCount}</span>
              </div>
            </div>

            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Upper Card</span>
              <div className="flex items-center gap-2">
                <div className="w-16 h-2 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full bg-purple-500"
                    style={{ width: `${(upperCardCount / totalCharacters) * 100}%` }}
                  />
                </div>
                <span className="text-sm font-medium w-6 text-right">{upperCardCount}</span>
              </div>
            </div>

            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Mid Card</span>
              <div className="flex items-center gap-2">
                <div className="w-16 h-2 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full bg-blue-500"
                    style={{ width: `${(midCardCount / totalCharacters) * 100}%` }}
                  />
                </div>
                <span className="text-sm font-medium w-6 text-right">{midCardCount}</span>
              </div>
            </div>

            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Lower Card</span>
              <div className="flex items-center gap-2">
                <div className="w-16 h-2 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full bg-green-500"
                    style={{ width: `${(lowerCardCount / totalCharacters) * 100}%` }}
                  />
                </div>
                <span className="text-sm font-medium w-6 text-right">{lowerCardCount}</span>
              </div>
            </div>

            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Jobber</span>
              <div className="flex items-center gap-2">
                <div className="w-16 h-2 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gray-500"
                    style={{ width: `${(jobberCount / totalCharacters) * 100}%` }}
                  />
                </div>
                <span className="text-sm font-medium w-6 text-right">{jobberCount}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="lg:col-span-3 space-y-4 order-1 lg:order-2">
        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex gap-4 flex-1">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Wrestler suchen..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9"
              />
            </div>
            <Select value={roleFilter} onValueChange={setRoleFilter}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder={t.common.all} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t.common.all}</SelectItem>
                <SelectItem value="main_event">Main Event</SelectItem>
                <SelectItem value="upper_card">Upper Card</SelectItem>
                <SelectItem value="mid_card">Mid Card</SelectItem>
                <SelectItem value="lower_card">Lower Card</SelectItem>
                <SelectItem value="jobber">Jobber</SelectItem>
                <SelectItem value="road_agent">Road Agent</SelectItem>
                <SelectItem value="manager">Manager</SelectItem>
                <SelectItem value="staff">Staff</SelectItem>
                <SelectItem value="commentary">Commentary</SelectItem>
                <SelectItem value="referee">Referee</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex flex-col gap-2">
            <span className="text-sm font-medium">Status-Filter:</span>
            <div className="flex flex-wrap gap-3">
              <div className="flex items-center gap-2">
                <Checkbox
                  id="status-active"
                  checked={statusFilters.active}
                  onCheckedChange={(checked) => handleStatusFilterChange('active', checked === true)}
                />
                <label
                  htmlFor="status-active"
                  className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                >
                  Active
                </label>
              </div>
              <div className="flex items-center gap-2">
                <Checkbox
                  id="status-injured"
                  checked={statusFilters.injured}
                  onCheckedChange={(checked) => handleStatusFilterChange('injured', checked === true)}
                />
                <label
                  htmlFor="status-injured"
                  className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                >
                  Injured
                </label>
              </div>
              <div className="flex items-center gap-2">
                <Checkbox
                  id="status-suspended"
                  checked={statusFilters.suspended}
                  onCheckedChange={(checked) => handleStatusFilterChange('suspended', checked === true)}
                />
                <label
                  htmlFor="status-suspended"
                  className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                >
                  Suspended
                </label>
              </div>
              <div className="flex items-center gap-2">
                <Checkbox
                  id="status-retired"
                  checked={statusFilters.retired}
                  onCheckedChange={(checked) => handleStatusFilterChange('retired', checked === true)}
                />
                <label
                  htmlFor="status-retired"
                  className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                >
                  Retired
                </label>
              </div>
              <div className="flex items-center gap-2">
                <Checkbox
                  id="status-inactive"
                  checked={statusFilters.inactive}
                  onCheckedChange={(checked) => handleStatusFilterChange('inactive', checked === true)}
                />
                <label
                  htmlFor="status-inactive"
                  className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                >
                  Inactive
                </label>
              </div>
            </div>
          </div>
        </div>

        {/* Character Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-2 2xl:grid-cols-3 gap-6 min-h-[400px]">
          {filteredCharacters.map((character) => (
            <div
              key={character.id}
              className="cursor-pointer"
              onClick={() => router.push(`/characters/${character.id}`)}
            >
              <CharacterCard
                character={character}
                relationshipCount={getRelationshipCount(character.id)}
                storylineCount={0}
                championships={championships}
                onEdit={() => onEdit(character)}
                onDelete={() => onDelete(character.id)}
                onView={() => router.push(`/characters/${character.id}`)}
              />
            </div>
          ))}
        </div>
      </div>

    </div>
  )
}