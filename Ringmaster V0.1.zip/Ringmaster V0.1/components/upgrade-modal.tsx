"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Crown, Lock, Check, Star, LogIn } from "lucide-react"
import { getCurrentPlan, PLANS, formatLimitText } from "@/lib/plans"
import { useAuth } from "@/lib/auth-context"
import { stripePromise, createCheckoutSession } from "@/lib/stripe"

interface UpgradeModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  limitType?: string
  currentCount?: number
  maxCount?: number
}

export function UpgradeModal({ 
  open, 
  onOpenChange, 
  limitType = "wrestlers", 
  currentCount = 0, 
  maxCount = 50 
}: UpgradeModalProps) {
  const router = useRouter()
  const { user, isPro } = useAuth()
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  
  const currentPlan = getCurrentPlan(isPro)
  const proPlan = PLANS.pro

  const handleUpgrade = async () => {
    // If user is not logged in, redirect to login
    if (!user) {
      onOpenChange(false)
      router.push('/auth')
      return
    }

    // Check if Stripe is configured
    if (!stripePromise) {
      setError('Stripe ist nicht konfiguriert. Bitte kontaktiere den Support.')
      return
    }

    setIsLoading(true)
    setError('')

    try {
      // Create checkout session
      const sessionId = await createCheckoutSession(user.id, user.email)
      
      // Get Stripe instance and redirect to checkout
      const stripe = await stripePromise
      if (stripe) {
        window.location.href = `/checkout?sessionId=${sessionId}`
      }
    } catch (error) {
      console.error('Stripe checkout error:', error)
      setError('Ein Fehler ist aufgetreten. Bitte versuche es später erneut.')
    } finally {
      setIsLoading(false)
    }
  }

  const handleLogin = () => {
    onOpenChange(false)
    router.push('/auth')
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Crown className="h-5 w-5 text-yellow-500" />
            {user ? 'Upgrade auf Ringmaster Pro' : 'Login für Pro-Features'}
          </DialogTitle>
          <DialogDescription>
            {!user ? (
              <>Melde dich an um deine Limits aufzuheben und alle Pro-Features freizuschalten.</>
            ) : (
              <>
                {limitType === "wrestlers" && (
                  <>Du hast das Limit von {maxCount} Wrestlern erreicht. Upgrade für unbegrenzte Möglichkeiten.</>
                )}
                {limitType === "activeStorylines" && (
                  <>Du hast das Limit von {maxCount} aktiven Storylines erreicht. Upgrade für unbegrenzte Storylines.</>
                )}
                {limitType === "segments" && (
                  <>Du hast das Limit von {maxCount} Segmenten erreicht. Upgrade für unbegrenzte Segmente.</>
                )}
                {limitType === "episodes" && (
                  <>Du hast das Limit von {maxCount} Events erreicht. Upgrade für unbegrenzte Events.</>
                )}
              </>
            )}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {/* Current Status */}
          <div className="bg-muted/50 rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium">Aktueller Status</span>
              <Badge variant="secondary">{currentPlan.name}</Badge>
            </div>
            <div className="text-sm text-muted-foreground">
              {formatLimitText(limitType, currentCount, maxCount)}
            </div>
          </div>

          {/* Pro Features */}
          <div className="space-y-3">
            <h3 className="font-semibold flex items-center gap-2">
              <Star className="h-4 w-4 text-yellow-500" />
              Pro Features
            </h3>
            <div className="grid gap-2">
              <div className="flex items-center gap-2 text-sm">
                <Check className="h-4 w-4 text-green-500" />
                <span>Unbegrenzt viele Wrestler</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Check className="h-4 w-4 text-green-500" />
                <span>Unbegrenzt viele Storylines</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Check className="h-4 w-4 text-green-500" />
                <span>Unbegrenzt viele Segmente</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Check className="h-4 w-4 text-green-500" />
                <span>Unbegrenzt viele Events</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Check className="h-4 w-4 text-green-500" />
                <span>Zukünftige Pro-Features</span>
              </div>
            </div>
          </div>

          {/* Pricing */}
          <div className="bg-gradient-to-r from-yellow-50 to-orange-50 dark:from-yellow-900/20 dark:to-orange-900/20 rounded-lg p-4 border border-yellow-200 dark:border-yellow-800">
            <div className="text-center">
              <div className="text-3xl font-bold text-gray-900 dark:text-gray-100">
                4,99€
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-400">
                Einmalzahlung - lebenslanger Zugang
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3">
            {!user ? (
              <>
                <Button 
                  onClick={handleLogin}
                  className="flex-1"
                >
                  <LogIn className="h-4 w-4 mr-2" />
                  Einloggen
                </Button>
                <Button variant="outline" onClick={() => onOpenChange(false)}>
                  Später
                </Button>
              </>
            ) : (
              <>
                <Button 
                  onClick={handleUpgrade}
                  className="flex-1 bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <div className="h-4 w-4 mr-2 animate-spin rounded-full border-2 border-white border-t-transparent" />
                  ) : (
                    <Crown className="h-4 w-4 mr-2" />
                  )}
                  Jetzt für 4,99€ upgraden
                </Button>
                <Button variant="outline" onClick={() => onOpenChange(false)}>
                  Später
                </Button>
              </>
            )}
          </div>

          {/* Developer Mode Notice */}
          {process.env.NEXT_PUBLIC_DEVELOPER_MODE === 'true' && (
            <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-3 border border-blue-200 dark:border-blue-800">
              <div className="flex items-center gap-2 text-sm text-blue-700 dark:text-blue-300">
                <Lock className="h-4 w-4" />
                <span>Developer Mode aktiv - Limits sind aufgehoben</span>
              </div>
            </div>
          )}

          {/* Future Login Notice */}
          <div className="text-xs text-muted-foreground text-center">
            In Phase 2 wird ein Login für den Upgrade-Prozess hinzugefügt.
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
