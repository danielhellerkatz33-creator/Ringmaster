"use client"

import { useSeries } from "@/lib/series-context"
import { createBackup, restoreFromBackup } from "@/lib/migration"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Download, Upload, Database, AlertCircle } from "lucide-react"
import { useState } from "react"

export function StorageStatus() {
  const { storageReady } = useSeries()
  const [isBackingUp, setIsBackingUp] = useState(false)
  const [isRestoring, setIsRestoring] = useState(false)
  const [lastBackup, setLastBackup] = useState<string | null>(null)

  const handleBackup = async () => {
    setIsBackingUp(true)
    try {
      const backup = await createBackup()
      const blob = new Blob([backup], { type: "application/json" })
      const url = URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = `ringmaster-backup-${new Date().toISOString().split('T')[0]}.json`
      a.click()
      URL.revokeObjectURL(url)
      setLastBackup(new Date().toLocaleString())
    } catch (error) {
      console.error("Backup failed:", error)
      alert("Backup fehlgeschlagen")
    } finally {
      setIsBackingUp(false)
    }
  }

  const handleRestore = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    setIsRestoring(true)
    try {
      const text = await file.text()
      const success = await restoreFromBackup(text)
      if (success) {
        alert("Backup erfolgreich wiederhergestellt. Seite wird neu geladen.")
        window.location.reload()
      } else {
        alert("Wiederherstellung fehlgeschlagen")
      }
    } catch (error) {
      console.error("Restore failed:", error)
      alert("Wiederherstellung fehlgeschlagen")
    } finally {
      setIsRestoring(false)
      // Reset file input
      event.target.value = ""
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Database className="h-5 w-5" />
          Speicher-Status
        </CardTitle>
        <CardDescription>
          Verwaltung Ihrer Ringmaster Daten und Backups
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center gap-2">
          <Badge variant={storageReady ? "default" : "destructive"}>
            {storageReady ? "IndexedDB" : "localStorage"}
          </Badge>
          {storageReady ? (
            <span className="text-sm text-muted-foreground">
              Moderne Datenspeicherung aktiv
            </span>
          ) : (
            <span className="text-sm text-muted-foreground flex items-center gap-1">
              <AlertCircle className="h-4 w-4" />
              Fallback-Modus aktiv
            </span>
          )}
        </div>

        {storageReady && (
          <div className="text-sm text-muted-foreground">
            <p>• Größenlimit: ~1GB+</p>
            <p>• Blob-Speicherung für Avatare</p>
            <p>• Automatische Migration von localStorage</p>
            <p>• Transaktionale Sicherheit</p>
          </div>
        )}

        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handleBackup}
            disabled={isBackingUp || isRestoring}
          >
            <Download className="h-4 w-4 mr-2" />
            {isBackingUp ? "Erstelle Backup..." : "Backup erstellen"}
          </Button>

          <div className="relative">
            <input
              type="file"
              accept=".json"
              onChange={handleRestore}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              disabled={isBackingUp || isRestoring}
            />
            <Button
              variant="outline"
              size="sm"
              disabled={isBackingUp || isRestoring}
            >
              <Upload className="h-4 w-4 mr-2" />
              {isRestoring ? "Stelle wieder her..." : "Backup laden"}
            </Button>
          </div>
        </div>

        {lastBackup && (
          <p className="text-xs text-muted-foreground">
            Letztes Backup: {lastBackup}
          </p>
        )}
      </CardContent>
    </Card>
  )
}