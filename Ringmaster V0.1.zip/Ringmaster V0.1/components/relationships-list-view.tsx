"use client"

import { useState, useMemo } from "react"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { MoreVertical, Pencil, Trash2, ArrowRight, Search } from "lucide-react"
import type { Relationship, Character } from "@/lib/types"
import { CharacterAvatar } from "@/components/character-avatar"

const typeLabels: Record<Relationship["type"], string> = {
  tag_team: "Tag Team",
  stable: "Stable",
  manager: "Manager",
  rivalry: "Rivalität",
  friendship: "Freundschaft",
}

const typeColors: Record<Relationship["type"], string> = {
  tag_team: "bg-purple-500/20 text-purple-500",
  stable: "bg-orange-500/20 text-orange-500",
  manager: "bg-indigo-500/20 text-indigo-500",
  rivalry: "bg-red-500/20 text-red-500",
  friendship: "bg-green-500/20 text-green-500",
}

interface RelationshipsListViewProps {
  relationships: Relationship[]
  characters: Character[]
  onEdit: (relationship: Relationship) => void
  onDelete: (id: string) => void
}

export function RelationshipsListView({
  relationships,
  characters,
  onEdit,
  onDelete
}: RelationshipsListViewProps) {
  const [searchTerm, setSearchTerm] = useState("")
  const [sortBy, setSortBy] = useState<"type" | "intensity" | "character">("type")

  const getCharacter = (id: string) => characters.find((c) => c.id === id)

  const filteredAndSortedRelationships = useMemo(() => {
    let filtered = relationships.filter((rel) => {
      // Get first two characters for display
      const char1 = getCharacter(rel.characterIds[0])
      const char2 = getCharacter(rel.characterIds[1])
      if (!char1) return false // At least first character is required

      const searchLower = searchTerm.toLowerCase()
      const characterNames = rel.characterIds
        .map(id => getCharacter(id)?.name || "")
        .filter(name => name)
        .join(" ")
      
      return (
        characterNames.toLowerCase().includes(searchLower) ||
        typeLabels[rel.type].toLowerCase().includes(searchLower) ||
        rel.description.toLowerCase().includes(searchLower)
      )
    })

    // Sort
    filtered.sort((a, b) => {
      switch (sortBy) {
        case "type":
          return typeLabels[a.type].localeCompare(typeLabels[b.type])
        case "intensity":
          return b.intensity - a.intensity
        case "character":
          const charA1 = getCharacter(a.characterIds[0])
          const charB1 = getCharacter(b.characterIds[0])
          return (charA1?.name || "").localeCompare(charB1?.name || "")
        default:
          return 0
      }
    })

    return filtered
  }, [relationships, characters, searchTerm, sortBy])

  return (
    <div className="space-y-4">
      {/* Header mit Sortierung und Suche */}
      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
        <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center">
          <Select value={sortBy} onValueChange={(value) => setSortBy(value as typeof sortBy)}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Sortieren nach" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="type">Nach Typ</SelectItem>
              <SelectItem value="intensity">Nach Intensität</SelectItem>
              <SelectItem value="character">Nach Charakter</SelectItem>
            </SelectContent>
          </Select>

          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Beziehungen suchen..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-64"
            />
          </div>
        </div>

        <div className="text-sm text-muted-foreground">
          {filteredAndSortedRelationships.length} von {relationships.length} Beziehungen
        </div>
      </div>

      {/* Kompakte Zeilen */}
      <div className="space-y-2">
        {filteredAndSortedRelationships.map((rel) => {
          const char1 = getCharacter(rel.characterIds[0])
          const char2 = getCharacter(rel.characterIds[1])
          if (!char1) return null

          return (
            <Card key={rel.id} className="p-3 hover:bg-muted/50 transition-colors">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3 flex-1 min-w-0">
                  <CharacterAvatar name={char1.name} imageUrl={char1.imageUrl} character={char1} size="sm" />
                  <Badge variant="outline" className={typeColors[rel.type]}>
                    {typeLabels[rel.type]}
                  </Badge>
                  {char2 && (
                    <>
                      <ArrowRight className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                      <CharacterAvatar name={char2.name} imageUrl={char2.imageUrl} character={char2} size="sm" />
                    </>
                  )}
                  <div className="flex-1 min-w-0">
                    <span className="font-medium text-sm truncate block">
                      {char1.name}{char2 ? ` ↔ ${char2.name}` : ""}
                      {rel.characterIds.length > 2 && ` +${rel.characterIds.length - 2}`}
                    </span>
                    {rel.description && (
                      <p className="text-xs text-muted-foreground line-clamp-1 mt-1">
                        {rel.description}
                      </p>
                    )}
                    
                    {/* Wrestling-specific fields */}
                    {(rel.type === "tag_team" || rel.type === "stable") && (
                      <div className="flex items-center gap-1 mt-1 flex-wrap">
                        {rel.teamName && (
                          <Badge variant="outline" className="text-xs">
                            {rel.teamName}
                          </Badge>
                        )}
                        <Badge 
                          variant={rel.isActive ? "default" : "secondary"} 
                          className="text-xs"
                        >
                          {rel.isActive ? "Aktiv" : "Inaktiv"}
                        </Badge>
                        
                        {/* Show stable members */}
                        {rel.type === "stable" && rel.characterIds.length > 2 && (
                          <>
                            <span className="text-xs text-muted-foreground ml-2">{rel.characterIds.length} Mitglieder</span>
                            {rel.characterIds.slice(0, 3).map((memberId) => {
                              const member = characters.find(c => c.id === memberId)
                              return member ? (
                                <Badge key={memberId} variant="secondary" className="text-xs">
                                  {member.name}
                                </Badge>
                              ) : null
                            })}
                            {rel.characterIds.length > 3 && (
                              <Badge variant="secondary" className="text-xs">
                                +{rel.characterIds.length - 3} weitere
                              </Badge>
                            )}
                          </>
                        )}
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-3 flex-shrink-0">
                  {/* Intensität als kompakte Punkte */}
                  <div className="flex items-center gap-0.5">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <div
                        key={i}
                        className={`h-1.5 w-1.5 rounded-full ${
                          i < Math.ceil(rel.intensity / 2) ? "bg-primary" : "bg-muted"
                        }`}
                      />
                    ))}
                  </div>

                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => onEdit(rel)}>
                        <Pencil className="h-4 w-4 mr-2" />
                        Bearbeiten
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        onClick={() => onDelete(rel.id)}
                        className="text-destructive focus:text-destructive"
                      >
                        <Trash2 className="h-4 w-4 mr-2" />
                        Löschen
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
            </Card>
          )
        })}

        {filteredAndSortedRelationships.length === 0 && (
          <div className="text-center py-8 text-muted-foreground">
            {searchTerm ? "Keine Beziehungen gefunden." : "Keine Beziehungen vorhanden."}
          </div>
        )}
      </div>
    </div>
  )
}