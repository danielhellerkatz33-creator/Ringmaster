"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { useSeries } from "@/lib/series-context"
import { useAuth } from "@/lib/auth-context"
import {
  Film,
  Users,
  BookOpen,
  Layers,
  LayoutDashboard,
  Heart,
  ChevronLeft,
  ChevronRight,
  Tv,
  TrendingUp,
  CalendarCheck,
  Download,
  Brain,
  Network,
  FileText,
  Settings,
  Menu,
  BarChart3,
  Calendar,
  Trophy,
  History,
  Square,
  User,
} from "lucide-react"

const navItems = [
  { href: "/account", label: "Account", icon: User },
  { href: "/main-menu", label: "Hauptmenü", icon: Menu },
  { href: "/", label: "Dashboard", icon: LayoutDashboard },
  { href: "/characters", label: "Wrestler", icon: Users },
  { href: "/contract-availability", label: "Contracts", icon: Square },
  { href: "/relationships", label: "Beziehungen", icon: Heart },
  { href: "/arcs", label: "Championships", icon: Trophy },
  { href: "/storylines", label: "Storylines", icon: BookOpen },
  { href: "/episodes", label: "Events", icon: Calendar },
  { href: "/scenes", label: "Segmente", icon: Layers },
  { href: "/deployment-planning", label: "Roster Management", icon: BarChart3 },
  { href: "/booking", label: "Segment History", icon: History },
  { href: "/story-summaries", label: "Storyline Wrap-Up", icon: FileText },
  { href: "/character-analysis", label: "Character History", icon: Brain },
  { href: "/story-analysis", label: "Story Continuation Ideas", icon: Network },
  { href: "/backup", label: "Backup", icon: Download },
  { href: "/settings", label: "Einstellungen", icon: Settings },
]

export function Sidebar() {
  const [collapsed, setCollapsed] = useState(false)
  const pathname = usePathname()
  const { data } = useSeries()
  const { user, isPro } = useAuth()

  return (
    <aside
      className={cn(
        "flex flex-col h-screen bg-sidebar border-r border-sidebar-border transition-all duration-300",
        collapsed ? "w-16" : "w-64",
      )}
    >
      <div className="flex items-center justify-between p-4 border-b border-sidebar-border">
        {!collapsed && (
          <div className="flex items-center gap-2">
            <img src="/icons/wrestling-icon.svg" alt="Wrestling" className="h-6 w-6 brightness-0 invert" />
            <span className="font-semibold text-sidebar-foreground truncate">
              {data.series && data.series.length > 0 ? data.series[0].title : "Ringmaster"}
            </span>
          </div>
        )}
        {collapsed && <img src="/icons/wrestling-icon.svg" alt="Wrestling" className="h-6 w-6 brightness-0 invert mx-auto" />}
        <Button
          variant="ghost"
          size="icon"
          className={cn("h-8 w-8 text-sidebar-foreground", collapsed && "mx-auto")}
          onClick={() => setCollapsed(!collapsed)}
        >
          {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
        </Button>
      </div>

      <nav className="flex-1 p-2 space-y-1">
        {navItems.map((item) => {
          const isActive = pathname === item.href
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors",
                isActive
                  ? "bg-sidebar-accent text-sidebar-accent-foreground"
                  : "text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent/50",
              )}
            >
              <item.icon className="h-5 w-5 shrink-0" />
              {!collapsed && <span>{item.label}</span>}
            </Link>
          )
        })}
      </nav>

      {!collapsed && (
        <div className="p-4 border-t border-sidebar-border space-y-2">
          <div className="text-xs text-sidebar-foreground/50">
            {data.characters.length} Charaktere | {data.episodes.length} Episoden
          </div>
          {user && (
            <div className="flex items-center gap-2 text-xs">
              <span className="text-sidebar-foreground/50">Status:</span>
              <span className={`font-medium ${isPro ? 'text-yellow-500' : 'text-sidebar-foreground/70'}`}>
                {isPro ? 'Pro' : 'Free'}
              </span>
            </div>
          )}
        </div>
      )}
    </aside>
  )
}
