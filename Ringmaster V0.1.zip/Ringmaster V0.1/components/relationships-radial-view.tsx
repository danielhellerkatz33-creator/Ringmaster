"use client"

import { useState, useMemo } from "react"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { HoverCard, HoverCardContent, HoverCardTrigger } from "@/components/ui/hover-card"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { MoreVertical, Pencil, Trash2, Users } from "lucide-react"
import type { Relationship, Character } from "@/lib/types"
import { CharacterAvatar } from "@/components/character-avatar"

const typeLabels: Record<Relationship["type"], string> = {
  tag_team: "Tag Team",
  stable: "Stable",
  manager: "Manager",
  rivalry: "Rivalität",
  friendship: "Freundschaft",
}

const typeColors: Record<Relationship["type"], string> = {
  tag_team: "#a855f7", // purple
  stable: "#f97316", // orange
  manager: "#6366f1", // indigo
  rivalry: "#ef4444", // red
  friendship: "#22c55e", // green
}

interface RelationshipsRadialViewProps {
  relationships: Relationship[]
  characters: Character[]
  onEdit: (relationship: Relationship) => void
  onDelete: (id: string) => void
  onFocusCharacter: (characterId: string) => void
}

export function RelationshipsRadialView({
  relationships,
  characters,
  onEdit,
  onDelete,
  onFocusCharacter
}: RelationshipsRadialViewProps) {
  const [selectedCharacterId, setSelectedCharacterId] = useState<string | null>(null)

  // Wenn kein Charakter ausgewählt ist, den ersten mit Beziehungen auswählen
  const selectedCharacter = useMemo(() => {
    if (selectedCharacterId) {
      return characters.find(c => c.id === selectedCharacterId)
    }
    // Finde Charakter mit den meisten Beziehungen
    const charWithMostRelationships = characters
      .map(char => ({
        ...char,
        relationshipCount: relationships.filter(r =>
          r.characterIds.includes(char.id)
        ).length
      }))
      .sort((a, b) => b.relationshipCount - a.relationshipCount)[0]

    return charWithMostRelationships?.relationshipCount > 0 ? charWithMostRelationships : null
  }, [characters, relationships, selectedCharacterId])

  const characterRelationships = useMemo(() => {
    if (!selectedCharacter) return []

    return relationships
      .filter(r => r.characterIds.includes(selectedCharacter.id))
      .map(r => ({
        ...r,
        otherCharacterId: r.characterIds.find(id => id !== selectedCharacter.id) || ""
      }))
  }, [relationships, selectedCharacter])

  const getCharacter = (id: string) => characters.find(c => c.id === id)

  if (!selectedCharacter) {
    return (
      <div className="flex items-center justify-center h-64 text-muted-foreground">
        Kein Charakter mit Beziehungen gefunden.
      </div>
    )
  }

  // SVG Dimensionen
  const svgSize = 400
  const centerX = svgSize / 2
  const centerY = svgSize / 2
  const radius = 140

  // Positionen für Beziehungen berechnen
  const getRadialPosition = (index: number, total: number) => {
    const angle = (index / total) * 2 * Math.PI - Math.PI / 2 // Start at top
    return {
      x: centerX + radius * Math.cos(angle),
      y: centerY + radius * Math.sin(angle)
    }
  }

  return (
    <div className="space-y-4">
      {/* Charakter-Auswahl */}
      <div className="flex items-center gap-4">
        <Users className="h-5 w-5 text-muted-foreground" />
        <Select
          value={selectedCharacter.id}
          onValueChange={setSelectedCharacterId}
        >
          <SelectTrigger className="w-64">
            <SelectValue placeholder="Charakter auswählen" />
          </SelectTrigger>
          <SelectContent>
            {characters
              .filter(char => relationships.some(r =>
                r.characterIds.includes(char.id)
              ))
              .map(char => (
                <SelectItem key={char.id} value={char.id}>
                  {char.name} ({
                    relationships.filter(r =>
                      r.characterIds.includes(char.id)
                    ).length
                  } Beziehungen)
                </SelectItem>
              ))}
          </SelectContent>
        </Select>
      </div>

      {/* Radiale Visualisierung */}
      <Card className="p-6">
        <div className="flex justify-center">
          <svg width={svgSize} height={svgSize} className="overflow-visible">
            {/* Hintergrundkreis */}
            <circle
              cx={centerX}
              cy={centerY}
              r={radius + 20}
              fill="none"
              stroke="currentColor"
              strokeWidth="1"
              className="text-muted"
              opacity="0.2"
            />

            {/* Zentraler Charakter */}
            <g transform={`translate(${centerX - 32}, ${centerY - 32})`}>
              <CharacterAvatar
                name={selectedCharacter.name}
                imageUrl={selectedCharacter.imageUrl}
                character={selectedCharacter}
                size="xl"
              />
            </g>

            {/* Beziehungsverbindungen */}
            {characterRelationships.map((rel, index) => {
              const otherChar = getCharacter(rel.otherCharacterId)
              if (!otherChar) return null

              const position = getRadialPosition(index, characterRelationships.length)

              return (
                <g key={rel.id}>
                  {/* Verbindungslinie */}
                  <line
                    x1={centerX}
                    y1={centerY}
                    x2={position.x}
                    y2={position.y}
                    stroke={typeColors[rel.type]}
                    strokeWidth={Math.max(1, rel.intensity / 3)}
                    opacity="0.6"
                  />

                  {/* Anderer Charakter */}
                  <g transform={`translate(${position.x - 16}, ${position.y - 16})`}>
                    <HoverCard>
                      <HoverCardTrigger asChild>
                        <foreignObject width="32" height="32" className="cursor-pointer">
                          <CharacterAvatar
                            name={otherChar.name}
                            imageUrl={otherChar.imageUrl}
                            character={otherChar}
                            size="sm"
                          />
                        </foreignObject>
                      </HoverCardTrigger>
                      <HoverCardContent className="w-64">
                        <div className="space-y-2">
                          <div className="flex items-center gap-2">
                            <CharacterAvatar name={otherChar.name} imageUrl={otherChar.imageUrl} character={otherChar} size="sm" />
                            <span className="font-medium">{otherChar.name}</span>
                          </div>
                          <Badge className={`text-xs ${typeColors[rel.type]} text-white`}>
                            {typeLabels[rel.type]}
                          </Badge>
                          <p className="text-sm">{rel.description || "Keine Beschreibung"}</p>
                          
                          {/* Wrestling-specific fields */}
                          {(rel.type === "tag_team" || rel.type === "stable") && (
                            <div className="flex items-center gap-2 mt-2 flex-wrap">
                              {rel.teamName && (
                                <Badge variant="outline" className="text-xs">
                                  {rel.teamName}
                                </Badge>
                              )}
                              <Badge 
                                variant={rel.isActive ? "default" : "secondary"} 
                                className="text-xs"
                              >
                                {rel.isActive ? "Aktiv" : "Inaktiv"}
                              </Badge>
                              
                              {/* Show stable members count */}
                              {rel.type === "stable" && rel.characterIds && rel.characterIds.length > 2 && (
                                <Badge variant="secondary" className="text-xs">
                                  +{rel.characterIds.length} Mitglieder
                                </Badge>
                              )}
                            </div>
                          )}
                          
                          <div className="flex items-center gap-2">
                            <span className="text-xs">Intensität:</span>
                            <div className="flex gap-1">
                              {Array.from({ length: 10 }).map((_, i) => (
                                <div
                                  key={i}
                                  className={`h-2 w-2 rounded-full ${
                                    i < rel.intensity ? "bg-primary" : "bg-muted"
                                  }`}
                                />
                              ))}
                            </div>
                          </div>
                          <div className="flex gap-1 mt-2">
                            <Button size="sm" variant="outline" onClick={() => onEdit(rel)}>
                              <Pencil className="h-3 w-3 mr-1" />
                              Bearbeiten
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => onDelete(rel.id)}
                              className="text-destructive hover:text-destructive"
                            >
                              <Trash2 className="h-3 w-3 mr-1" />
                              Löschen
                            </Button>
                          </div>
                        </div>
                      </HoverCardContent>
                    </HoverCard>
                  </g>
                </g>
              )
            })}
          </svg>
        </div>

        {/* Legende */}
        <div className="mt-4 flex flex-wrap gap-2 justify-center">
          {Object.entries(typeLabels).map(([type, label]) => {
            const hasType = characterRelationships.some(r => r.type === type)
            if (!hasType) return null

            return (
              <div key={type} className="flex items-center gap-1">
                <div
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: typeColors[type as Relationship["type"]] }}
                />
                <span className="text-xs text-muted-foreground">{label}</span>
              </div>
            )
          })}
        </div>
      </Card>

      {/* Statistik */}
      <div className="text-center text-sm text-muted-foreground">
        {selectedCharacter.name} hat {characterRelationships.length} Beziehung{characterRelationships.length !== 1 ? 'en' : ''}
      </div>
    </div>
  )
}