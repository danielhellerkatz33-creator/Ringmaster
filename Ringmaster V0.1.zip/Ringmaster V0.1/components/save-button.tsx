"use client"

import { useState } from "react"
import { Save, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { exportSavegame } from "@/lib/savegame/export"
import { useToast } from "@/hooks/use-toast"
import { useLanguage } from "@/hooks/use-language"

export function SaveButton() {
  const [isSaving, setIsSaving] = useState(false)
  const { toast } = useToast()
  const { t } = useLanguage()

  const handleSave = async () => {
    setIsSaving(true)
    try {
      await exportSavegame(true) // true = mit Assets exportieren
      toast({
        title: t.saveButton.successTitle,
        description: t.saveButton.successDescription,
      })
    } catch (error) {
      toast({
        title: t.saveButton.errorTitle,
        description: t.saveButton.errorDescription,
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  return (
    <Button
      variant="outline"
      size="sm"
      className="fixed top-4 right-4 z-50 shadow-md hover:shadow-lg transition-shadow"
      onClick={handleSave}
      disabled={isSaving}
      title={t.saveButton.title}
    >
      {isSaving ? (
        <Loader2 className="h-4 w-4 animate-spin" />
      ) : (
        <Save className="h-4 w-4" />
      )}
    </Button>
  )
}