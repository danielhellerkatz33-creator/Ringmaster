"use client"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { CharacterAvatar } from "@/components/character-avatar"
import { Calendar as CalendarIcon, Crown, Plus, Edit, Trash2, Users } from "lucide-react"
import { format } from "date-fns"
import { de } from "date-fns/locale"
import { useSeries } from "@/lib/series-context"
import type { CharacterArc, ChampionshipReign, Character } from "@/lib/types"

interface ChampionshipHistoryProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  championshipId: string
}

export function ChampionshipHistory({ open, onOpenChange, championshipId }: ChampionshipHistoryProps) {
  const { data, addChampionshipReign, updateChampionshipReign, deleteChampionshipReign } = useSeries()
  const championship = data.characterArcs.find(arc => arc.id === championshipId)
  
  if (!championship) {
    return null
  }
  
  const [showAddReign, setShowAddReign] = useState(false)
  const [editingReign, setEditingReign] = useState<ChampionshipReign | null>(null)
  
  // Reset all calendar states when dialog closes
  useEffect(() => {
    if (!open) {
      setShowAddReign(false)
      setEditingReign(null)
    }
  }, [open])

  const currentChampions = championship.currentChampionIds.map(id => 
    data.characters.find(c => c.id === id)
  ).filter((c): c is Character => c !== undefined)

  // Funktion zur Berechnung der Gesamtzahl der Reigns für einen Champion
  const getTotalReigns = (championId: string): number => {
    // Finde den Character-Namen für diese ID
    const character = data.characters.find(c => c.id === championId)
    const characterName = character?.name
    
    const allReigns = [
      // Alle Reigns mit diesem Character (sowohl Character-IDs als auch manuelle Namen)
      ...championship.championHistory
        .filter(reign => {
          // Prüfe ob die Character-ID in championIds vorhanden ist
          const hasMatchingId = reign.championIds.includes(championId)
          // Prüfe ob der Character-Name in championNames vorhanden ist
          const hasMatchingName = characterName && (reign.championNames || []).includes(characterName)
          return hasMatchingId || hasMatchingName
        })
        .map(() => 1),
      // Aktuelle Regentschaft falls vorhanden
      ...(championship.currentChampionIds.includes(championId) ? [1] : [])
    ]
    return allReigns.length
  }

  // Funktion zur Berechnung der Reign-Anzahl für einen Champion
  const getReignCount = (championId: string): number => {
    // Finde den Character-Namen für diese ID
    const character = data.characters.find(c => c.id === championId)
    const characterName = character?.name
    
    const allReigns = [
      // Aktuelle Regentschaft zählen
      ...championship.currentChampionIds.includes(championId) ? [1] : [],
      // Alle Reigns mit diesem Character (sowohl Character-IDs als auch manuelle Namen)
      ...championship.championHistory
        .filter(reign => {
          // Prüfe ob die Character-ID in championIds vorhanden ist
          const hasMatchingId = reign.championIds.includes(championId)
          // Prüfe ob der Character-Name in championNames vorhanden ist
          const hasMatchingName = characterName && (reign.championNames || []).includes(characterName)
          return hasMatchingId || hasMatchingName
        })
        .map(() => 1)
    ]
    return allReigns.length
  }

  // Funktion zur Berechnung der Reign-Nummer für einen bestimmten Reign
  const getReignNumber = (reignId: string, championId: string): number => {
    // Finde den Character-Namen für diese ID
    const character = data.characters.find(c => c.id === championId)
    const characterName = character?.name
    
    const allReigns = [
      // Alle Reigns mit diesem Character (sowohl Character-IDs als auch manuelle Namen)
      ...championship.championHistory
        .filter(reign => {
          // Prüfe ob die Character-ID in championIds vorhanden ist
          const hasMatchingId = reign.championIds.includes(championId)
          // Prüfe ob der Character-Name in championNames vorhanden ist
          const hasMatchingName = characterName && (reign.championNames || []).includes(characterName)
          return hasMatchingId || hasMatchingName
        })
        .sort((a, b) => new Date(a.dateWon).getTime() - new Date(b.dateWon).getTime()),
      // Aktuelle Regentschaft falls vorhanden
      ...(championship.currentChampionIds.includes(championId) ? [{
        id: 'current',
        dateWon: new Date()
      }] : [])
    ]
    
    const reignIndex = allReigns.findIndex(reign => reign.id === reignId || (reignId === 'current' && reign.id === 'current'))
    return reignIndex + 1
  }

  const history = championship.championHistory.sort((a, b) => 
    new Date(b.dateWon).getTime() - new Date(a.dateWon).getTime()
  )

  const handleTransferChampionship = () => {
    if (currentChampions.length === 0) return
    
    // End current reign and create new one (placeholder for now)
    // This would need a proper implementation with new champion selection
    const now = new Date()
    const currentReign = championship.championHistory.find(r => !r.dateLost)
    
    if (currentReign) {
      updateChampionshipReign(championship.id, {
        ...currentReign,
        dateLost: now
      })
    }
  }

  const handleAddReign = (reign: Omit<ChampionshipReign, "id">) => {
    addChampionshipReign(championship.id, reign)
    setShowAddReign(false)
  }

  const handleEditReign = (reign: Omit<ChampionshipReign, "id">) => {
    // Finde den ursprünglichen Reign und behalte die ID
    const originalReign = championship.championHistory.find(r => r.id === editingReign?.id)
    if (!originalReign) return
    
    const updatedReign: ChampionshipReign = {
      ...reign,
      id: originalReign.id
    }
    
    updateChampionshipReign(championship.id, updatedReign)
    setEditingReign(null)
  }

  const handleDeleteReign = (reignId: string) => {
    deleteChampionshipReign(championship.id, reignId)
  }

  const getChampionNames = (championIds: string[]) => {
    return championIds.map(id => 
      data.characters.find(c => c.id === id)?.name || "Unbekannt"
    ).join(", ")
  }

  // Funktion zur Berechnung der Reign-Nummer für einen bestimmten Reign (auch für historische Einträge)
  const getReignNumberForHistorical = (reignId: string, championName: string): number => {
    // Debug: Log was passiert
    console.log('getReignNumberForHistorical called:', { reignId, championName })
    
    // Berechne Reign-Nummer basierend auf Namensgleichheit (für manuelle UND Character-Einträge)
    const allReigns = [
      // Alle Reigns mit diesem Champion-Namen (sowohl championNames als auch characterIds)
      ...championship.championHistory
        .filter(reign => {
          // Prüfe ob der Name in championNames vorhanden ist
          const hasMatchingName = (reign.championNames || []).includes(championName)
          // Prüfe ob ein Character mit diesem Namen in championIds vorhanden ist
          const hasMatchingCharacter = (reign.championIds || []).some(id => {
            const character = data.characters.find(c => c.id === id)
            return character && character.name === championName
          })
          return hasMatchingName || hasMatchingCharacter
        })
        .sort((a, b) => new Date(a.dateWon).getTime() - new Date(b.dateWon).getTime()),
      // Aktuelle Regentschaft falls vorhanden
      ...((championship.currentChampionIds || []).some(id => {
        const character = data.characters.find(c => c.id === id)
        return character && character.name === championName
      }) ? [{
        id: 'current',
        dateWon: new Date()
      }] : [])
    ]
    
    console.log('allReigns for historical:', allReigns)
    
    const reignIndex = allReigns.findIndex(reign => reign.id === reignId || (reignId === 'current' && reign.id === 'current'))
    const result = reignIndex + 1
    console.log('getReignNumberForHistorical result:', result)
    
    return result
  }

  // Funktion zur Berechnung der Reign-Nummer für jeden Wrestler (auch ohne Character-Verknüpfung)
  const getReignNumberForAnyWrestler = (reignId: string, championName: string): number => {
    // Zähle alle Reigns mit diesem exakten Champion-Namen
    const allReignsWithThisName = championship.championHistory
      .filter(reign => (reign.championNames || []).includes(championName))
      .sort((a, b) => new Date(a.dateWon).getTime() - new Date(b.dateWon).getTime())
    
    // Finde den Index des aktuellen Reign
    const reignIndex = allReignsWithThisName.findIndex(reign => reign.id === reignId)
    
    // Gib die Reign-Nummer zurück (1-basiert)
    return reignIndex + 1
  }

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-4xl max-h-[90vh] overflow-y-auto z-50">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Crown className="h-5 w-5" />
              {championship.title} - Titelhistorie
            </DialogTitle>
            <DialogDescription>
              Verfolge alle Regentschaften und Titelwechsel dieses Championships.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6">
            {/* Current Champions */}
            <div className="bg-muted/50 p-4 rounded-lg">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold flex items-center gap-2">
                  <Crown className="h-4 w-4" />
                  Aktuelle Champion{championship.type !== "singles" ? "s" : ""}
                </h3>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={handleTransferChampionship}
                  disabled={currentChampions.length === 0}
                >
                  Titel übertragen
                </Button>
              </div>
              {currentChampions.length > 0 ? (
                <div className="flex flex-wrap gap-3">
                  {currentChampions.map(champion => {
                    const reignCount = getReignCount(champion.id)
                    return (
                      <div key={champion.id} className="flex items-center gap-2 bg-muted/50 rounded-lg p-2">
                        <CharacterAvatar 
                          name={champion.name} 
                          imageUrl={champion.imageUrl} 
                          character={champion} 
                          size="sm" 
                        />
                        <span className="text-sm font-medium">
                          {champion.name}
                          {reignCount > 1 && (
                            <span className="ml-1 text-xs text-muted-foreground">({reignCount})</span>
                          )}
                        </span>
                      </div>
                    )
                  })}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">Aktuell vakant</p>
              )}
            </div>

            {/* Add Reign Button */}
            <div className="flex justify-between items-center">
              <h3 className="font-semibold">Regentschaften ({history.length})</h3>
              <Button onClick={() => setShowAddReign(true)} className="gap-2">
                <Plus className="h-4 w-4" />
                Historische Regentschaft
              </Button>
            </div>

            {/* History Timeline */}
            <div className="space-y-4">
              {history.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Crown className="h-12 w-12 mx-auto mb-3 opacity-50" />
                  <p>Noch keine Titelhistorie vorhanden</p>
                </div>
              ) : (
                history.map((reign, index) => (
                  <div key={reign.id} className="relative">
                    {/* Timeline Line */}
                    {index < history.length - 1 && (
                      <div className="absolute left-4 top-8 bottom-0 w-0.5 bg-border" />
                    )}
                    
                    <div className="flex gap-4">
                      {/* Timeline Dot */}
                      <div className="flex-shrink-0 w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                        <Crown className="h-4 w-4 text-primary-foreground" />
                      </div>
                      
                      {/* Reign Content */}
                      <div className="flex-1 bg-card border rounded-lg p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <Badge variant={reign.dateLost ? "outline" : "default"}>
                                {reign.dateLost ? "Beendet" : "Aktuell"}
                              </Badge>
                              {reign.defenses > 0 && (
                                <Badge variant="secondary">
                                  {reign.defenses} Titelverteidigungen
                                </Badge>
                              )}
                            </div>
                            
                            <div className="flex items-center gap-2 mb-2">
                              {reign.championIds && reign.championIds.length > 0 ? (
                                // Einträge mit Character-IDs: Zeige Character-Avatare mit Namen
                                <div className="flex -space-x-2">
                                  {reign.championIds.map(championId => {
                                    const champion = data.characters.find(c => c.id === championId)
                                    const reignNumber = getReignNumber(reign.id, championId)
                                    return champion ? (
                                      <div key={championId} className="relative">
                                        <CharacterAvatar 
                                          name={champion.name} 
                                          imageUrl={champion.imageUrl} 
                                          character={champion} 
                                          size="sm"
                                          className="border-2 border-background"
                                        />
                                        {reignNumber > 1 && (
                                          <div className="absolute -bottom-1 -right-1 bg-primary text-primary-foreground text-xs rounded-full w-5 h-5 flex items-center justify-center font-bold">
                                            {reignNumber}
                                          </div>
                                        )}
                                      </div>
                                    ) : null
                                  })}
                                  <span className="ml-2 font-medium">
                                    {reign.championIds.map(id => {
                                      const character = data.characters.find(c => c.id === id)
                                      return character?.name || "Unbekannt"
                                    }).join(", ")}
                                  </span>
                                </div>
                              ) : (
                                // Historische Einträge: Zeige manuelle Namen mit optionalen Avataren/Reign-Nummern
                                <div className="flex items-center gap-2">
                                  {(reign.championNames || []).map((championName, index) => {
                                    const matchingCharacter = data.characters.find(c => c.name === championName)
                                    const reignNumber = getReignNumberForAnyWrestler(reign.id, championName)
                                    
                                    return (
                                      <div key={index} className="flex items-center gap-2">
                                        {matchingCharacter && (
                                          <div className="relative">
                                            <CharacterAvatar 
                                              name={championName} 
                                              imageUrl={matchingCharacter.imageUrl} 
                                              character={matchingCharacter} 
                                              size="sm"
                                              className="border-2 border-background"
                                            />
                                            {reignNumber > 1 && (
                                              <div className="absolute -bottom-1 -right-1 bg-primary text-primary-foreground text-xs rounded-full w-5 h-5 flex items-center justify-center font-bold">
                                                {reignNumber}
                                              </div>
                                            )}
                                          </div>
                                        )}
                                        <span className="font-medium">
                                          {championName}
                                          {reignNumber > 1 && (
                                            <span className="ml-1 text-sm text-muted-foreground">({reignNumber})</span>
                                          )}
                                        </span>
                                      </div>
                                    )
                                  })}
                                </div>
                              )}
                            </div>
                            
                            <div className="text-sm text-muted-foreground space-y-1">
                              <div className="flex items-center gap-2">
                                <CalendarIcon className="h-3 w-3" />
                                <span>Gewonnen: {format(new Date(reign.dateWon), "PPP", { locale: de })}</span>
                              </div>
                              {reign.dateLost && (
                                <div className="flex items-center gap-2">
                                  <CalendarIcon className="h-3 w-3" />
                                  <span>Verloren: {format(new Date(reign.dateLost), "PPP", { locale: de })}</span>
                                </div>
                              )}
                              {reign.dateLost && reign.dateWon && (
                                <div className="text-xs">
                                  Dauer: {Math.ceil((new Date(reign.dateLost).getTime() - new Date(reign.dateWon).getTime()) / (1000 * 60 * 60 * 24))} Tage
                                </div>
                              )}
                            </div>
                            
                            {reign.isHistorical && (
                              <Badge variant="outline" className="mt-2">
                                Historischer Eintrag
                              </Badge>
                            )}
                          </div>
                          
                          <div className="flex gap-1">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => setEditingReign(reign)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDeleteReign(reign.id)}
                              className="text-destructive hover:text-destructive"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Add/Edit Reign Dialog */}
      {(showAddReign || editingReign) && championship && (
        <ReignDialog
          open={true}
          onOpenChange={(open) => {
            if (!open) {
              setShowAddReign(false)
              setEditingReign(null)
            }
          }}
          championship={championship}
          reign={editingReign}
          onSave={(reign) => {
            if (editingReign) {
              handleEditReign(reign)
            } else {
              handleAddReign(reign)
            }
          }}
        />
      )}
    </>
  )
}

interface ReignDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  championship: CharacterArc
  reign?: ChampionshipReign | null
  onSave: (reign: Omit<ChampionshipReign, "id">) => void
}

function ReignDialog({ open, onOpenChange, championship, reign, onSave }: ReignDialogProps) {
  const { data } = useSeries()
  const [championIds, setChampionIds] = useState<string[]>(reign?.championIds || [])
  const [championNames, setChampionNames] = useState<string[]>(reign?.championNames || [])
  const [dateWon, setDateWon] = useState<Date | undefined>(reign?.dateWon ? new Date(reign.dateWon) : undefined)
  const [dateLost, setDateLost] = useState<Date | undefined>(reign?.dateLost ? new Date(reign.dateLost) : undefined)
  const [defenses, setDefenses] = useState(reign?.defenses || 0)
  const [isHistorical, setIsHistorical] = useState(reign?.isHistorical || false)
  const [useManualDateInput, setUseManualDateInput] = useState(false)
  const [manualDateWon, setManualDateWon] = useState("")
  const [manualDateLost, setManualDateLost] = useState("")
  const [wrestlerFilter, setWrestlerFilter] = useState("")

  // Initialize manual date fields when editing
  useEffect(() => {
    if (reign && open) {
      if (reign.dateWon) {
        const date = new Date(reign.dateWon)
        setManualDateWon(format(date, "dd.MM.yyyy"))
      }
      if (reign.dateLost) {
        const date = new Date(reign.dateLost)
        setManualDateLost(format(date, "dd.MM.yyyy"))
      }
    }
  }, [reign, open])

  // Reset all states when dialog closes
  useEffect(() => {
    if (!open) {
      setChampionIds([])
      setChampionNames([])
      setDateWon(undefined)
      setDateLost(undefined)
      setDefenses(0)
      setIsHistorical(false)
      setUseManualDateInput(false)
      setManualDateWon("")
      setManualDateLost("")
      setWrestlerFilter("")
    }
  }, [open])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    // Parse manual dates if used
    let finalDateWon = dateWon
    let finalDateLost = dateLost
    
    if (useManualDateInput) {
      if (manualDateWon) {
        const parsed = parseManualDate(manualDateWon)
        if (parsed) {
          finalDateWon = parsed
        } else {
          alert("Ungültiges Datum für 'Gewonnen am'. Bitte verwenden Sie das Format DD.MM.YYYY")
          return
        }
      } else {
        alert("Datum 'Gewonnen am' ist erforderlich")
        return
      }
      
      if (manualDateLost) {
        const parsed = parseManualDate(manualDateLost)
        if (parsed) {
          finalDateLost = parsed
        } else {
          alert("Ungültiges Datum für 'Verloren am'. Bitte verwenden Sie das Format DD.MM.YYYY")
          return
        }
      }
    }
    
    if (!finalDateWon) return // dateWon is required
    
    const reignData: Omit<ChampionshipReign, "id"> = {
      championIds: isHistorical ? [] : championIds,
      championNames: isHistorical ? championNames : undefined,
      dateWon: finalDateWon,
      dateLost: finalDateLost || undefined,
      defenses,
      isHistorical,
    }

    onSave(reignData)
  }

  // Helper function to parse manual date input
  const parseManualDate = (dateString: string): Date | null => {
    // Support DD.MM.YYYY format
    const parts = dateString.trim().split('.')
    if (parts.length !== 3) return null
    
    const day = parseInt(parts[0])
    const month = parseInt(parts[1]) - 1 // JavaScript months are 0-based
    const year = parseInt(parts[2])
    
    if (isNaN(day) || isNaN(month) || isNaN(year)) return null
    if (day < 1 || day > 31) return null
    if (month < 0 || month > 11) return null
    if (year < 1900 || year > 2100) return null
    
    const date = new Date(year, month, day)
    // Check if the date is valid (e.g., 31.02.2024 would become 03.03.2024)
    if (date.getDate() !== day || date.getMonth() !== month || date.getFullYear() !== year) {
      return null
    }
    
    return date
  }

  // Helper function to auto-format date input
  const formatDateInput = (value: string): string => {
    // Remove all non-digit characters
    let digits = value.replace(/\D/g, '')
    
    // Limit to 8 digits (DDMMYYYY)
    if (digits.length > 8) {
      digits = digits.substring(0, 8)
    }
    
    // Format as DD.MM.YYYY
    if (digits.length >= 5) {
      return `${digits.slice(0, 2)}.${digits.slice(2, 4)}.${digits.slice(4)}`
    } else if (digits.length >= 3) {
      return `${digits.slice(0, 2)}.${digits.slice(2)}`
    } else if (digits.length > 0) {
      return digits
    }
    
    return value
  }

  // Handler for manual date input with auto-formatting
  const handleManualDateChange = (value: string, setter: (value: string) => void) => {
    const formatted = formatDateInput(value)
    setter(formatted)
  }

  const handleChampionSelect = (characterId: string) => {
    if (championship.type === "singles") {
      setChampionIds([characterId])
    } else {
      const maxChampions = championship.type === "tag_team" ? 2 : championship.type === "trios" ? 3 : 6
      if (championIds.includes(characterId)) {
        setChampionIds(championIds.filter(id => id !== characterId))
      } else if (championIds.length < maxChampions) {
        setChampionIds([...championIds, characterId])
      }
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>
            {reign ? "Regentschaft bearbeiten" : "Historische Regentschaft hinzufügen"}
          </DialogTitle>
          <DialogDescription>
            {reign ? "Bearbeite die Details dieser Regentschaft." : "Füge eine historische Regentschaft hinzu."}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label>Historischer Eintrag</Label>
            <Select value={isHistorical ? "yes" : "no"} onValueChange={(value) => setIsHistorical(value === "yes")}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="no">Aus Wrestler auswählen</SelectItem>
                <SelectItem value="yes">Namen manuell eingeben</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {isHistorical ? (
            <div className="space-y-2">
              <Label>Champion-Namen (kommagetrennt)</Label>
              <Input
                placeholder="z.B. John Doe, Jane Smith"
                value={championNames.join(", ")}
                onChange={(e) => setChampionNames(e.target.value.split(",").map(n => n.trim()).filter(n => n))}
              />
            </div>
          ) : (
            <div className="space-y-2">
              <Label>Champion{championship.type !== "singles" ? "s" : ""}</Label>
              <Input
                placeholder="Wrestler filtern..."
                value={wrestlerFilter}
                onChange={(e) => setWrestlerFilter(e.target.value)}
                className="mb-2"
              />
              <div className="space-y-2 max-h-32 overflow-y-auto border rounded p-2">
                {[...data.characters]
                  .sort((a, b) => a.name.localeCompare(b.name))
                  .filter(character => 
                    wrestlerFilter === "" || 
                    character.name.toLowerCase().includes(wrestlerFilter.toLowerCase())
                  )
                  .map((character) => (
                  <div key={character.id} className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id={`reign-champion-${character.id}`}
                      checked={championIds.includes(character.id)}
                      onChange={() => handleChampionSelect(character.id)}
                      className="rounded"
                    />
                    <Label htmlFor={`reign-champion-${character.id}`} className="text-sm">
                      {character.name}
                    </Label>
                  </div>
                ))}
                {wrestlerFilter && [...data.characters].filter(character => 
                  character.name.toLowerCase().includes(wrestlerFilter.toLowerCase())
                ).length === 0 && (
                  <div className="text-sm text-muted-foreground p-2">
                    Keine Wrestler gefunden
                  </div>
                )}
              </div>
            </div>
          )}

          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Datums-Eingabe</Label>
              <Select value={useManualDateInput ? "manual" : "calendar"} onValueChange={(value) => setUseManualDateInput(value === "manual")}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="calendar">Kalender auswählen</SelectItem>
                  <SelectItem value="manual">Manuell eingeben</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Gewonnen am</Label>
                {useManualDateInput ? (
                  <Input
                    placeholder="DD.MM.YYYY"
                    value={manualDateWon}
                    onChange={(e) => handleManualDateChange(e.target.value, setManualDateWon)}
                    maxLength={10}
                  />
                ) : (
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className="w-full justify-start text-left font-normal"
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {dateWon ? format(dateWon, "dd.MM.yyyy", { locale: de }) : "Datum auswählen"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start" side="bottom" sideOffset={4} avoidCollisions={true}>
                      <Calendar
                        mode="single"
                        selected={dateWon}
                        onSelect={setDateWon}
                        initialFocus
                        locale={de}
                        captionLayout="dropdown"
                        fromYear={1950}
                        toYear={2030}
                        defaultMonth={new Date(1988, 0, 1)}
                      />
                    </PopoverContent>
                  </Popover>
                )}
              </div>
              <div className="space-y-2">
                <Label>Verloren am (optional)</Label>
                {useManualDateInput ? (
                  <Input
                    placeholder="DD.MM.YYYY"
                    value={manualDateLost}
                    onChange={(e) => handleManualDateChange(e.target.value, setManualDateLost)}
                    maxLength={10}
                  />
                ) : (
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className="w-full justify-start text-left font-normal"
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {dateLost ? format(dateLost, "dd.MM.yyyy", { locale: de }) : "Datum auswählen"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start" side="bottom" sideOffset={4} avoidCollisions={true}>
                      <Calendar
                        mode="single"
                        selected={dateLost}
                        onSelect={setDateLost}
                        initialFocus
                        locale={de}
                        captionLayout="dropdown"
                        fromYear={1950}
                        toYear={2030}
                        defaultMonth={new Date(1988, 0, 1)}
                      />
                    </PopoverContent>
                  </Popover>
                )}
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Titelverteidigungen</Label>
            <Input
              type="number"
              min="0"
              value={defenses}
              onChange={(e) => setDefenses(parseInt(e.target.value) || 0)}
            />
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Abbrechen
            </Button>
            <Button type="submit">
              {reign ? "Speichern" : "Hinzufügen"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
