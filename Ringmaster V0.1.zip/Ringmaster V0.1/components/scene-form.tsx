"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { X } from "lucide-react"
import { useSeries } from "@/lib/series-context"
import type { Segment } from "@/lib/types"
import { CharacterAvatar } from "@/components/character-avatar"

interface SceneFormProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  scene?: Segment
}

export function SceneForm({ open, onOpenChange, scene }: SceneFormProps) {
  const { data, addScene, updateScene } = useSeries()
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [notes, setNotes] = useState("")
  const [duration, setDuration] = useState(5)
  const [storylineIds, setStorylineIds] = useState<string[]>([])
  const [selectedCharacters, setSelectedCharacters] = useState<string[]>([])

  const isEditing = !!scene

  useEffect(() => {
    if (scene) {
      setTitle(scene.title)
      setDescription(scene.description)
      setNotes(scene.notes)
      setDuration(scene.duration)
      setStorylineIds(scene.storylineIds || [])
      setSelectedCharacters(scene.characterIds)
    } else {
      resetForm()
    }
  }, [scene, open])

  const resetForm = () => {
    setTitle("")
    setDescription("")
    setNotes("")
    setDuration(5)
    setStorylineIds([])
    setSelectedCharacters([])
  }

  const toggleStoryline = (storylineId: string) => {
    setStorylineIds((prev) => (prev.includes(storylineId) ? prev.filter((id) => id !== storylineId) : [...prev, storylineId]))
  }

  const toggleCharacter = (charId: string) => {
    setSelectedCharacters((prev) => (prev.includes(charId) ? prev.filter((id) => id !== charId) : [...prev, charId]))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!title.trim()) return

    const sceneData = {
      title: title.trim(),
      description: description.trim(),
      notes: notes.trim(),
      duration,
      storylineIds: storylineIds.length > 0 ? storylineIds : undefined,
      characterIds: selectedCharacters,
      order: scene?.order ?? (data.segments?.length || 0),
    }

    if (isEditing) {
      updateScene({
        ...scene,
        ...sceneData,
      })
    } else {
      addScene(sceneData)
    }

    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{isEditing ? "Segment bearbeiten" : "Neues Segment erstellen"}</DialogTitle>
          <DialogDescription>
            {isEditing
              ? "Bearbeite die Details dieses Segments."
              : "Erstelle ein neues Segment für deine Promotion."
            }
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="space-y-2">
            <Label htmlFor="title">Titel</Label>
            <Input
              id="title"
              placeholder="z.B. Erste Begegnung"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Beschreibung</Label>
            <Textarea
              id="description"
              placeholder="Was passiert in diesem Segment..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="duration">Dauer (Minuten)</Label>
              <Input
                id="duration"
                type="number"
                min={1}
                max={60}
                value={duration}
                onChange={(e) => setDuration(Number.parseInt(e.target.value) || 5)}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Storylines</Label>
            {data.storylines.filter((s) => s.status !== "completed").length === 0 ? (
              <p className="text-sm text-muted-foreground">Keine aktiven Storylines verfügbar.</p>
            ) : (
              <div className="flex flex-wrap gap-2">
                {data.storylines.filter((s) => s.status !== "completed").map((s) => (
                  <Badge
                    key={s.id}
                    variant={storylineIds.includes(s.id) ? "default" : "outline"}
                    className="cursor-pointer gap-1.5 pr-2"
                    onClick={() => toggleStoryline(s.id)}
                  >
                    <div className="h-3 w-3 rounded-full" style={{ backgroundColor: s.color }} />
                    {s.title}
                    {storylineIds.includes(s.id) && <X className="h-3 w-3 ml-1" />}
                  </Badge>
                ))}
              </div>
            )}
          </div>

          <div className="space-y-2">
            <Label>Wrestler in diesem Segment</Label>
            {data.characters.length === 0 ? (
              <p className="text-sm text-muted-foreground">Erstelle zuerst Wrestler.</p>
            ) : (
              <div className="flex flex-wrap gap-2">
                {[...data.characters]
                  .filter((char) => char.status === "active")
                  .sort((a, b) => a.name.localeCompare(b.name))
                  .map((char) => (
                  <Badge
                    key={char.id}
                    variant={selectedCharacters.includes(char.id) ? "default" : "outline"}
                    className="cursor-pointer gap-1.5 pr-2"
                    onClick={() => toggleCharacter(char.id)}
                  >
                    <CharacterAvatar name={char.name} imageUrl={char.imageUrl} character={char} size="xs" />
                    {char.name}
                    {selectedCharacters.includes(char.id) && <X className="h-3 w-3 ml-1" />}
                  </Badge>
                ))}
              </div>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Notizen</Label>
            <Textarea
              id="notes"
              placeholder="Zusätzliche Notizen zum Segment..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={2}
            />
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Abbrechen
            </Button>
            <Button type="submit" disabled={!title.trim()}>
              {isEditing ? "Speichern" : "Erstellen"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
