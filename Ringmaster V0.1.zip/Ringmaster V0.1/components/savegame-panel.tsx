"use client"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Download, Upload, AlertTriangle, CheckCircle, XCircle, Info } from "lucide-react"
import { exportSavegame } from "@/lib/savegame/export"
import { importSavegame } from "@/lib/savegame/import"
import { useSeries } from "@/lib/series-context"

export function SavegamePanel() {
  const { data, storageReady } = useSeries()
  const [includeAssets, setIncludeAssets] = useState(true)
  const [isExporting, setIsExporting] = useState(false)
  const [isImporting, setIsImporting] = useState(false)
  const [importProgress, setImportProgress] = useState<string>("")
  const [importProgressValue, setImportProgressValue] = useState(0)
  const [showImportDialog, setShowImportDialog] = useState(false)
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [lastExport, setLastExport] = useState<string | null>(null)
  const [lastImport, setLastImport] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const hasData = data.characters.length > 0 || data.series || data.episodes.length > 0
  const hasAvatars = data.characters.some(char => char.avatarBlobId)

  const handleExport = async () => {
    if (!storageReady) {
      setError("IndexedDB ist nicht verfügbar. Export nicht möglich.")
      return
    }

    setIsExporting(true)
    setError(null)

    try {
      await exportSavegame(includeAssets)
      setLastExport(new Date().toLocaleString())
      setSuccess("Savegame erfolgreich exportiert!")
    } catch (err) {
      setError(err instanceof Error ? err.message : "Export fehlgeschlagen")
    } finally {
      setIsExporting(false)
    }
  }

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      if (!file.name.endsWith('.json')) {
        setError("Bitte wählen Sie eine .json-Datei aus")
        return
      }
      setSelectedFile(file)
      setShowImportDialog(true)
      setError(null)
    }
  }

  const handleImport = async () => {
    if (!selectedFile || !storageReady) return

    setIsImporting(true)
    setImportProgress("")
    setImportProgressValue(0)
    setError(null)
    setShowImportDialog(false)

    const result = await importSavegame(selectedFile, (step) => {
      setImportProgress(step)
      // Schätze Fortschritt basierend auf Schritt
      const steps = ["Datei wird gelesen...", "Savegame wird validiert...", "Daten werden wiederhergestellt...", "Alte Daten werden gelöscht...", "Neue Daten werden geschrieben...", "Assets werden wiederhergestellt...", "Import abgeschlossen!"]
      const currentIndex = steps.indexOf(step)
      setImportProgressValue(currentIndex >= 0 ? ((currentIndex + 1) / steps.length) * 100 : 0)
    })

    setIsImporting(false)
    setImportProgress("")
    setImportProgressValue(0)

    if (result.success) {
      setLastImport(new Date().toLocaleString())
      setSuccess("Savegame erfolgreich importiert! Seite wird neu geladen...")
      // Hard reload nach erfolgreichem Import
      setTimeout(() => window.location.reload(), 2000)
    } else {
      setError(result.error)
    }

    // Reset file input
    setSelectedFile(null)
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  const clearMessages = () => {
    setError(null)
    setSuccess(null)
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Download className="h-5 w-5" />
            Savegame Export
          </CardTitle>
          <CardDescription>
            Exportieren Sie Ihre Wrestling-Spiel Daten als Backup-Datei
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {hasAvatars && (
            <div className="flex items-center space-x-2">
              <Checkbox
                id="include-assets"
                checked={includeAssets}
                onCheckedChange={(checked) => setIncludeAssets(checked as boolean)}
              />
              <label
                htmlFor="include-assets"
                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
              >
                Avatare und Assets einschließen
              </label>
            </div>
          )}

          <Button
            onClick={handleExport}
            disabled={isExporting || !hasData || !storageReady}
            className="w-full"
          >
            {isExporting ? (
              <>Export läuft...</>
            ) : (
              <>
                <Download className="h-4 w-4 mr-2" />
                Savegame exportieren
              </>
            )}
          </Button>

          {!storageReady && (
            <Alert>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                IndexedDB ist nicht verfügbar. Export nur mit localStorage möglich.
              </AlertDescription>
            </Alert>
          )}

          {!hasData && (
            <Alert>
              <Info className="h-4 w-4" />
              <AlertDescription>
                Keine Daten zum Exportieren vorhanden.
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5" />
            Savegame Import
          </CardTitle>
          <CardDescription>
            Stellen Sie ein gespeichertes Savegame wieder her
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <input
              ref={fileInputRef}
              type="file"
              accept=".json"
              onChange={handleFileSelect}
              className="hidden"
            />
            <Button
              variant="outline"
              onClick={() => fileInputRef.current?.click()}
              disabled={isImporting || !storageReady}
              className="w-full"
            >
              <Upload className="h-4 w-4 mr-2" />
              Savegame-Datei auswählen
            </Button>

            <Alert>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                <strong>Warnung:</strong> Der Import ersetzt alle aktuellen Daten vollständig.
                Erstellen Sie vorher ein Backup, falls nötig.
              </AlertDescription>
            </Alert>
          </div>

          {!storageReady && (
            <Alert>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                IndexedDB ist nicht verfügbar. Import nicht möglich.
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Status Informationen */}
      {(lastExport || lastImport) && (
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Letzte Aktivitäten</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {lastExport && (
              <div className="flex items-center gap-2 text-sm">
                <CheckCircle className="h-4 w-4 text-green-500" />
                Exportiert: {lastExport}
              </div>
            )}
            {lastImport && (
              <div className="flex items-center gap-2 text-sm">
                <CheckCircle className="h-4 w-4 text-blue-500" />
                Importiert: {lastImport}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Progress Dialog für Import */}
      {isImporting && (
        <AlertDialog open={isImporting}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Import läuft...</AlertDialogTitle>
              <AlertDialogDescription>
                Bitte warten Sie, während das Savegame wiederhergestellt wird.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <div className="space-y-4">
              <Progress value={importProgressValue} className="w-full" />
              <p className="text-sm text-center">{importProgress}</p>
            </div>
          </AlertDialogContent>
        </AlertDialog>
      )}

      {/* Import Bestätigung Dialog */}
      <AlertDialog open={showImportDialog} onOpenChange={setShowImportDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Import bestätigen</AlertDialogTitle>
            <AlertDialogDescription>
              Sind Sie sicher, dass Sie "{selectedFile?.name}" importieren möchten?
              <br />
              <strong>Diese Aktion kann nicht rückgängig gemacht werden!</strong>
              <br />
              Alle aktuellen Daten werden ersetzt.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Abbrechen</AlertDialogCancel>
            <AlertDialogAction onClick={handleImport} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Import durchführen
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Erfolgs-/Fehlermeldungen */}
      {success && (
        <Alert>
          <CheckCircle className="h-4 w-4" />
          <AlertDescription>{success}</AlertDescription>
        </Alert>
      )}

      {error && (
        <Alert variant="destructive">
          <XCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}
    </div>
  )
}
