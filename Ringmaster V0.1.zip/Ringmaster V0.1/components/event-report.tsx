"use client"

import type React from "react"
import { useState } from "react"
import { useToast } from "@/hooks/use-toast"
import { CustomModal } from "@/components/custom-modal"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { useSeries } from "@/lib/series-context"
import type { Event, EventReport, CharacterAppearance, StorylineProgress } from "@/lib/types"
import { 
  FileText, 
  Clock, 
  Users, 
  BookOpen, 
  TrendingUp, 
  Calendar,
  Edit3,
  Save,
  X,
  Download,
  BarChart3,
  Copy
} from "lucide-react"

interface EventReportProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  event: Event
}

export function EventReportModal({ open, onOpenChange, event }: EventReportProps) {
  const { data, updateEpisode } = useSeries()
  const { toast } = useToast()
  const [isEditing, setIsEditing] = useState(false)
  const [editedSummary, setEditedSummary] = useState("")

  if (!event.completionReport) {
    return null
  }

  const report = event.completionReport

  const handleEditSummary = () => {
    setEditedSummary(report.summary)
    setIsEditing(true)
  }

  const handleSaveSummary = () => {
    const updatedEvent = {
      ...event,
      completionReport: {
        ...report,
        summary: editedSummary
      }
    }
    updateEpisode(updatedEvent)
    setIsEditing(false)
  }

  const handleCancelEdit = () => {
    setEditedSummary("")
    setIsEditing(false)
  }

  const handleExport = () => {
    const exportContent = generateExportContent(event, report)
    const blob = new Blob([exportContent], { type: 'text/plain' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `${event.eventType}-${event.eventNumber}-bericht.txt`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  const handleCopy = async () => {
    const exportContent = generateExportContent(event, report)
    try {
      await navigator.clipboard.writeText(exportContent)
      toast({
        title: "Bericht kopiert",
        description: "Der Event-Bericht wurde in die Zwischenablage kopiert.",
      })
    } catch (err) {
      // Fallback for older browsers
      const textArea = document.createElement('textarea')
      textArea.value = exportContent
      document.body.appendChild(textArea)
      textArea.select()
      document.execCommand('copy')
      document.body.removeChild(textArea)
      toast({
        title: "Bericht kopiert",
        description: "Der Event-Bericht wurde in die Zwischenablage kopiert.",
      })
    }
  }

  const getStatusColor = (status: StorylineProgress["status"]) => {
    switch (status) {
      case "completed": return "bg-green-500/20 text-green-500"
      case "advanced": return "bg-blue-500/20 text-blue-500"
      case "continued": return "bg-purple-500/20 text-purple-500"
      case "paused": return "bg-orange-500/20 text-orange-500"
      default: return "bg-gray-500/20 text-gray-500"
    }
  }

  const getStatusLabel = (status: StorylineProgress["status"]) => {
    switch (status) {
      case "completed": return "Abgeschlossen"
      case "advanced": return "Vorangebracht"
      case "continued": return "Fortgesetzt"
      case "paused": return "Pausiert"
      default: return "Unbekannt"
    }
  }

  return (
    <CustomModal open={open} onOpenChange={onOpenChange}>
      <div className="h-full min-w-0 flex flex-col p-6">
        {/* Header */}
        <div className="flex items-start justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-primary/10 rounded-lg">
              <FileText className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h2 className="text-2xl font-semibold">Event-Bericht</h2>
              <p className="text-muted-foreground">
                {event.eventType} #{event.eventNumber}: {event.title}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={handleExport}>
              <Download className="h-4 w-4 mr-2" />
              Exportieren
            </Button>
            <Button variant="outline" size="sm" onClick={handleCopy}>
              <Copy className="h-4 w-4 mr-2" />
              Kopieren
            </Button>
            <Button variant="outline" size="sm" onClick={handleEditSummary}>
              <Edit3 className="h-4 w-4 mr-2" />
              Bearbeiten
            </Button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto space-y-6">
          {/* Zusammenfassung */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  Zusammenfassung
                </CardTitle>
                {isEditing && (
                  <div className="flex items-center gap-2">
                    <Button size="sm" onClick={handleSaveSummary}>
                      <Save className="h-4 w-4 mr-1" />
                      Speichern
                    </Button>
                    <Button size="sm" variant="outline" onClick={handleCancelEdit}>
                      <X className="h-4 w-4 mr-1" />
                      Abbrechen
                    </Button>
                  </div>
                )}
              </div>
            </CardHeader>
            <CardContent>
              {isEditing ? (
                <div className="space-y-2">
                  <Label>Bearbeite die Zusammenfassung</Label>
                  <Textarea
                    value={editedSummary}
                    onChange={(e) => setEditedSummary(e.target.value)}
                    rows={8}
                    className="min-h-[200px]"
                  />
                </div>
              ) : (
                <div className="whitespace-pre-wrap text-sm leading-relaxed">
                  {report.summary}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Statistiken */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-blue-500/10 rounded-lg">
                    <Clock className="h-5 w-5 text-blue-500" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Gesamtdauer</p>
                    <p className="text-2xl font-semibold">{report.totalDuration} Min.</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-green-500/10 rounded-lg">
                    <BarChart3 className="h-5 w-5 text-green-500" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Segmente</p>
                    <p className="text-2xl font-semibold">{report.segmentCount}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-purple-500/10 rounded-lg">
                    <Users className="h-5 w-5 text-purple-500" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Characters</p>
                    <p className="text-2xl font-semibold">{report.characterAppearances.length}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Character-Auftritte */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Character-Auftritte
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {report.characterAppearances.map((appearance) => (
                  <div key={appearance.characterId} className="flex items-center justify-between p-3 rounded-lg border">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-muted rounded-full flex items-center justify-center">
                        <span className="text-sm font-medium">
                          {appearance.characterName.charAt(0).toUpperCase()}
                        </span>
                      </div>
                      <div>
                        <p className="font-medium">{appearance.characterName}</p>
                        <p className="text-sm text-muted-foreground">
                          {appearance.appearanceCount} Auftritte • {appearance.totalScreenTime} Min.
                        </p>
                      </div>
                    </div>
                    <Badge variant="secondary">
                      {appearance.appearanceCount}x
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Storyline-Fortschritt */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="h-5 w-5" />
                Storyline-Fortschritt
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {report.storylineProgress.map((progress) => (
                  <div key={progress.storylineId} className="flex items-center justify-between p-3 rounded-lg border">
                    <div className="flex items-center gap-3">
                      <div 
                        className="w-3 h-3 rounded-full"
                        style={{ backgroundColor: progress.storylineColor }}
                      />
                      <div>
                        <p className="font-medium">{progress.storylineTitle}</p>
                        <p className="text-sm text-muted-foreground">
                          {progress.segmentCount} Segment{progress.segmentCount > 1 ? 'e' : ''}
                        </p>
                      </div>
                    </div>
                    <Badge className={getStatusColor(progress.status)}>
                      {getStatusLabel(progress.status)}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Metadaten */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Bericht-Metadaten
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-muted-foreground">Erstellt am</p>
                  <p className="font-medium">
                    {new Date(report.generatedAt).toLocaleDateString("de-DE", {
                      day: "2-digit",
                      month: "2-digit", 
                      year: "numeric",
                      hour: "2-digit",
                      minute: "2-digit"
                    })}
                  </p>
                </div>
                <div>
                  <p className="text-muted-foreground">Event-Status</p>
                  <Badge variant="outline">Abgeschlossen</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </CustomModal>
  )
}

function generateExportContent(event: Event, report: EventReport): string {
  let content = `EVENT-BERICHT\n`
  content += `================\n\n`
  content += `${event.eventType} #${event.eventNumber}: ${event.title}\n`
  content += `Status: Abgeschlossen\n`
  content += `Bericht erstellt: ${new Date(report.generatedAt).toLocaleString("de-DE")}\n\n`

  content += `ZUSAMMENFASSUNG\n`
  content += `---------------\n${report.summary}\n\n`

  content += `STATISTIKEN\n`
  content += `-----------\n`
  content += `Gesamtdauer: ${report.totalDuration} Minuten\n`
  content += `Anzahl Segmente: ${report.segmentCount}\n`
  content += `Anzahl Characters: ${report.characterAppearances.length}\n\n`

  content += `CHARACTER-AUFTRITTE\n`
  content += `-------------------\n`
  report.characterAppearances.forEach(appearance => {
    content += `${appearance.characterName}: ${appearance.appearanceCount}x (${appearance.totalScreenTime} Min.)\n`
  })
  content += `\n`

  content += `STORYLINE-FORTSCHRITT\n`
  content += `---------------------\n`
  report.storylineProgress.forEach(progress => {
    content += `${progress.storylineTitle}: ${progress.segmentCount} Segmente\n`
  })

  return content
}
