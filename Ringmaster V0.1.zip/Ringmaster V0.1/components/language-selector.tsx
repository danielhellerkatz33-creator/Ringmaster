"use client"

import { useLanguage } from "@/hooks/use-language"
import { Button } from "@/components/ui/button"

const germanFlag = (
  <svg width="20" height="15" viewBox="0 0 5 3" className="rounded-sm">
    <rect width="5" height="3" fill="#000"/>
    <rect width="5" height="2" fill="#dd0000"/>
    <rect width="5" height="1" y="1" fill="#ffcc00"/>
  </svg>
)

const englishFlag = (
  <svg width="20" height="15" viewBox="0 0 60 30" className="rounded-sm">
    <clipPath id="s">
      <path d="m0,0 v30 h60 v-30 z"/>
    </clipPath>
    <clipPath id="t">
      <path d="m30,15 h30 v15 z v15 h-30 z h-30 v-15 z v-15 h30 z"/>
    </clipPath>
    <g clipPath="url(#s)">
      <path d="m0,0 v30 h60 v-30 z" fill="#012169"/>
      <path d="m0,0 L60,30 M60,0 L0,30" stroke="#fff" strokeWidth="6"/>
      <path d="m0,0 L60,30 M60,0 L0,30" stroke="#c8102e" strokeWidth="4"/>
      <path d="m30,0 v30 M0,15 h60" stroke="#fff" strokeWidth="10"/>
      <path d="m30,0 v30 M0,15 h60" stroke="#c8102e" strokeWidth="6"/>
    </g>
  </svg>
)

export function LanguageSelector() {
  const { language, setLanguage } = useLanguage()

  return (
    <div className="fixed top-4 right-20 z-50 flex gap-1">
      <Button
        variant={language === "de" ? "default" : "outline"}
        size="sm"
        className="w-10 h-10 p-0 shadow-md hover:shadow-lg transition-shadow"
        onClick={() => setLanguage("de")}
        title="Deutsch"
      >
        {germanFlag}
      </Button>

      <Button
        variant={language === "en" ? "default" : "outline"}
        size="sm"
        className="w-10 h-10 p-0 shadow-md hover:shadow-lg transition-shadow"
        onClick={() => setLanguage("en")}
        title="English"
      >
        {englishFlag}
      </Button>
    </div>
  )
}