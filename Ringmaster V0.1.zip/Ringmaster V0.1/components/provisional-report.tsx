"use client"

import type React from "react"
import { useState } from "react"
import { CustomModal } from "@/components/custom-modal"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { useSeries } from "@/lib/series-context"
import { generateProvisionalReport } from "@/lib/event-report"
import type { Event, CharacterAppearance, StorylineProgress } from "@/lib/types"
import { 
  FileText, 
  Clock, 
  Users, 
  BookOpen, 
  Calendar,
  Copy,
  Download,
  BarChart3,
  Eye
} from "lucide-react"

interface ProvisionalReportProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  event: Event
}

export function ProvisionalReportModal({ open, onOpenChange, event }: ProvisionalReportProps) {
  const { data } = useSeries()
  const [showCopyConfirmation, setShowCopyConfirmation] = useState(false)

  // Provisorischen Bericht generieren
  const report = generateProvisionalReport(event.id, data)

  const handleCopyToClipboard = async () => {
    const content = generateProvisionalExportContent(event, report)
    try {
      await navigator.clipboard.writeText(content)
      setShowCopyConfirmation(true)
      setTimeout(() => setShowCopyConfirmation(false), 2000)
    } catch (error) {
      console.error("Fehler beim Kopieren:", error)
    }
  }

  const handleExport = () => {
    const exportContent = generateProvisionalExportContent(event, report)
    const blob = new Blob([exportContent], { type: 'text/plain' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `${event.eventType}-${event.eventNumber}-provisorisch.txt`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  const getStatusColor = (status: StorylineProgress["status"]) => {
    switch (status) {
      case "completed": return "bg-green-500/20 text-green-500"
      case "advanced": return "bg-blue-500/20 text-blue-500"
      case "continued": return "bg-purple-500/20 text-purple-500"
      case "paused": return "bg-orange-500/20 text-orange-500"
      default: return "bg-gray-500/20 text-gray-500"
    }
  }

  const getStatusLabel = (status: StorylineProgress["status"]) => {
    switch (status) {
      case "completed": return "Abgeschlossen"
      case "advanced": return "Vorangebracht"
      case "continued": return "Fortgesetzt"
      case "paused": return "Pausiert"
      default: return "Unbekannt"
    }
  }

  return (
    <CustomModal open={open} onOpenChange={onOpenChange}>
      <div className="h-full min-w-0 flex flex-col p-6">
        {/* Header */}
        <div className="flex items-start justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-orange-500/10 rounded-lg">
              <FileText className="h-6 w-6 text-orange-500" />
            </div>
            <div>
              <h2 className="text-2xl font-semibold">Provisorischer Bericht</h2>
              <p className="text-muted-foreground">
                {event.eventType} #{event.eventNumber}: {event.title}
              </p>
              <Badge variant="outline" className="mt-1">
                In Planung
              </Badge>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={handleCopyToClipboard}>
              <Copy className="h-4 w-4 mr-2" />
              {showCopyConfirmation ? "Kopiert!" : "Kopieren"}
            </Button>
            <Button variant="outline" size="sm" onClick={handleExport}>
              <Download className="h-4 w-4 mr-2" />
              Exportieren
            </Button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto space-y-6">
          {/* Zusammenfassung */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Eye className="h-5 w-5" />
                Vorschau für ChatGPT
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="bg-muted/50 p-4 rounded-lg">
                <div className="whitespace-pre-wrap text-sm leading-relaxed font-mono">
                  {report.summary}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Statistiken */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-blue-500/10 rounded-lg">
                    <Clock className="h-5 w-5 text-blue-500" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Gesamtdauer</p>
                    <p className="text-2xl font-semibold">{report.totalDuration} Min.</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-green-500/10 rounded-lg">
                    <BarChart3 className="h-5 w-5 text-green-500" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Segmente</p>
                    <p className="text-2xl font-semibold">{report.segmentCount}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-purple-500/10 rounded-lg">
                    <Users className="h-5 w-5 text-purple-500" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Characters</p>
                    <p className="text-2xl font-semibold">{report.characterAppearances.length}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Character-Auftritte */}
          {report.characterAppearances.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Geplante Character-Auftritte
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {report.characterAppearances.map((appearance) => (
                    <div key={appearance.characterId} className="flex items-center justify-between p-3 rounded-lg border">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-muted rounded-full flex items-center justify-center">
                          <span className="text-sm font-medium">
                            {appearance.characterName.charAt(0).toUpperCase()}
                          </span>
                        </div>
                        <div>
                          <p className="font-medium">{appearance.characterName}</p>
                          <p className="text-sm text-muted-foreground">
                            {appearance.appearanceCount} Auftritte • {appearance.totalScreenTime} Min.
                          </p>
                        </div>
                      </div>
                      <Badge variant="secondary">
                        {appearance.appearanceCount}x
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Storyline-Fortschritt */}
          {report.storylineProgress.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BookOpen className="h-5 w-5" />
                  Storyline-Fokus
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {report.storylineProgress.map((progress) => (
                    <div key={progress.storylineId} className="flex items-center justify-between p-3 rounded-lg border">
                      <div className="flex items-center gap-3">
                        <div 
                          className="w-3 h-3 rounded-full"
                          style={{ backgroundColor: progress.storylineColor }}
                        />
                        <div>
                          <p className="font-medium">{progress.storylineTitle}</p>
                          <p className="text-sm text-muted-foreground">
                            {progress.segmentCount} Segment{progress.segmentCount > 1 ? 'e' : ''}
                          </p>
                        </div>
                      </div>
                      <Badge className={getStatusColor(progress.status)}>
                        {getStatusLabel(progress.status)}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Metadaten */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Bericht-Metadaten
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-muted-foreground">Erstellt am</p>
                  <p className="font-medium">
                    {new Date(report.generatedAt).toLocaleDateString("de-DE", {
                      day: "2-digit",
                      month: "2-digit", 
                      year: "numeric",
                      hour: "2-digit",
                      minute: "2-digit"
                    })}
                  </p>
                </div>
                <div>
                  <p className="text-muted-foreground">Event-Status</p>
                  <Badge variant="outline">In Planung</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </CustomModal>
  )
}

function generateProvisionalExportContent(event: Event, report: any): string {
  let content = `PROVISORISCHER EVENT-BERICHT\n`
  content += `===========================\n\n`
  content += `${event.eventType} #${event.eventNumber}: ${event.title}\n`
  content += `Status: In Planung\n`
  content += `Bericht erstellt: ${new Date(report.generatedAt).toLocaleString("de-DE")}\n\n`

  content += `ZUSAMMENFASSUNG\n`
  content += `---------------\n${report.summary}\n\n`

  if (report.segmentCount > 0) {
    content += `STATISTIKEN\n`
    content += `-----------\n`
    content += `Gesamtdauer: ${report.totalDuration} Minuten\n`
    content += `Anzahl Segmente: ${report.segmentCount}\n`
    content += `Anzahl Characters: ${report.characterAppearances.length}\n\n`

    content += `CHARACTER-AUFTRITTE\n`
    content += `-------------------\n`
    report.characterAppearances.forEach((appearance: CharacterAppearance) => {
      content += `${appearance.characterName}: ${appearance.appearanceCount}x (${appearance.totalScreenTime} Min.)\n`
    })
    content += `\n`

    content += `STORYLINE-FOKUS\n`
    content += `----------------\n`
    report.storylineProgress.forEach((progress: StorylineProgress) => {
      content += `${progress.storylineTitle}: ${progress.segmentCount} Segmente\n`
    })
  }

  content += `\n---\n`
  content += `Dies ist ein provisorischer Bericht für eine Show in Planung.\n`
  content += `Er kann für ChatGPT-Anfragen verwendet werden, um eine erste Einschätzung zu erhalten.\n`

  return content
}
