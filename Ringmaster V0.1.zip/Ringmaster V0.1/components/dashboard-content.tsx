"use client"

import { useState } from "react"
import { useSeries } from "@/lib/series-context"
import { PageHeader } from "@/components/page-header"
import { StatsCard } from "@/components/stats-card"
import { EmptyState } from "@/components/empty-state"
import { SeriesSetupDialog } from "@/components/series-setup-dialog"
import { StorageStatus } from "@/components/storage-status"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Users, BookOpen, Layers, Calendar, Heart, Tv, Trophy } from "lucide-react"
import Link from "next/link"

export function DashboardContent() {
  const { data, isLoading } = useSeries()
  const [showSetup, setShowSetup] = useState(false)

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-pulse text-muted-foreground">Lädt...</div>
      </div>
    )
  }

  // Show setup dialog if no series exists
  if (!data.series) {
    return (
      <>
        <EmptyState
          icon={Tv}
          title="Willkommen beim Ringmaster"
          description="Erstelle deine erste Promotion um mit der Planung von Wrestlern, Storylines und Events zu beginnen."
          actionLabel="Neue Promotion erstellen"
          onAction={() => setShowSetup(true)}
        />
        <SeriesSetupDialog open={showSetup} onOpenChange={setShowSetup} />
      </>
    )
  }

  const recentCharacters = (data.characters || []).slice(-3)
  const activeStorylines = (data.storylines || []).filter((s) => s.status === "active")
  const planningEvents = (data.events || []).filter((e) => e.status === "planning" || e.status === "writing")

  return (
    <>
      <PageHeader
        title={data.series?.[0]?.title || "Ringmaster"}
        description={data.series?.[0]?.logline || "Wrestling Promotion Management"}
        action={
          <div className="flex gap-2">
            {data.series?.[0]?.genre && Array.isArray(data.series[0].genre) ? (
              data.series[0].genre.map((g: string) => (
                <Badge key={g} variant="secondary">
                  {g}
                </Badge>
              ))
            ) : null}
          </div>
        }
      />

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatsCard title="Wrestler" value={String(data.characters?.length || 0)} icon={Users} description="Angelegt" />
        <StatsCard title="Beziehungen" value={String(data.relationships?.length || 0)} icon={Heart} description="Definiert" />
        <StatsCard
          title="Storylines"
          value={String(data.storylines?.length || 0)}
          icon={BookOpen}
          description={`${activeStorylines.length} aktiv`}
        />
        <StatsCard
          title="Events"
          value={String(data.events?.length || 0)}
          icon={Calendar}
          description={`${planningEvents.length} in Planung`}
        />
      </div>

      {/* Quick Actions & Recent */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Schnellaktionen</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-2 gap-3">
            <Link href="/characters">
              <Button variant="outline" className="w-full justify-start gap-2 bg-transparent">
                <Users className="h-4 w-4" />
                Wrestler anlegen
              </Button>
            </Link>
            <Link href="/storylines">
              <Button variant="outline" className="w-full justify-start gap-2 bg-transparent">
                <BookOpen className="h-4 w-4" />
                Storyline erstellen
              </Button>
            </Link>
            <Link href="/scenes">
              <Button variant="outline" className="w-full justify-start gap-2 bg-transparent">
                <Layers className="h-4 w-4" />
                Segment erstellen
              </Button>
            </Link>
            <Link href="/episodes">
              <Button variant="outline" className="w-full justify-start gap-2 bg-transparent">
                <Calendar className="h-4 w-4" />
                Event planen
              </Button>
            </Link>
          </CardContent>
        </Card>

        {/* Recent Characters */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-lg">Neueste Wrestler</CardTitle>
            <Link href="/characters">
              <Button variant="ghost" size="sm">
                Alle anzeigen
              </Button>
            </Link>
          </CardHeader>
          <CardContent>
            {(!recentCharacters || recentCharacters.length === 0) ? (
              <p className="text-sm text-muted-foreground">Noch keine Wrestler angelegt.</p>
            ) : (
              <div className="space-y-3">
                {recentCharacters.map((char) => (
                  <div key={char.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-muted/50">
                    <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                      <span className="text-sm font-medium text-primary">{char.name.charAt(0).toUpperCase()}</span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-foreground truncate">{char.name}</p>
                      <p className="text-xs text-muted-foreground capitalize">{char.position}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Active Storylines */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-lg">Aktive Storylines</CardTitle>
            <Link href="/storylines">
              <Button variant="ghost" size="sm">
                Alle anzeigen
              </Button>
            </Link>
          </CardHeader>
          <CardContent>
            {(!activeStorylines || activeStorylines.length === 0) ? (
              <p className="text-sm text-muted-foreground">Keine aktiven Storylines.</p>
            ) : (
              <div className="space-y-3">
                {activeStorylines.slice(0, 3).map((storyline) => (
                  <div key={storyline.id} className="flex items-center gap-3">
                    <div className="h-3 w-3 rounded-full" style={{ backgroundColor: storyline.color }} />
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-foreground truncate">{storyline.title}</p>
                      <p className="text-xs text-muted-foreground">{storyline.characterIds.length} Wrestler</p>
                    </div>
                    <Badge variant="outline" className="text-xs capitalize">
                      {storyline.type}
                    </Badge>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Character Arcs Overview */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-lg">Championships</CardTitle>
            <Link href="/arcs">
              <Button variant="ghost" size="sm">
                Alle anzeigen
              </Button>
            </Link>
          </CardHeader>
          <CardContent>
            {(!data.characterArcs || data.characterArcs.length === 0) ? (
              <p className="text-sm text-muted-foreground">Noch keine Championships definiert.</p>
            ) : (
              <div className="space-y-3">
                {data.characterArcs.slice(0, 3).map((arc) => {
                  const character = data.characters.find((c) => c.id === arc.characterId)
                  return (
                    <div key={arc.id} className="flex items-center gap-3">
                      <Trophy className="h-4 w-4 text-muted-foreground" />
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-foreground truncate">{arc.title}</p>
                        <p className="text-xs text-muted-foreground">{character?.name || "Unbekannt"}</p>
                      </div>
                      <Badge variant={arc.status === "active" ? "default" : "outline"} className="text-xs capitalize">
                        {arc.status}
                      </Badge>
                    </div>
                  )
                })}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Storage Status */}
        <StorageStatus />
      </div>
    </>
  )
}
