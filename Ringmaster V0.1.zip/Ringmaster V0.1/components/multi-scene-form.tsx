"use client"

import React, { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { ContextMenu, ContextMenuContent, ContextMenuItem, ContextMenuTrigger } from "@/components/ui/context-menu"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { ScrollArea } from "@/components/ui/scroll-area"
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog"
import { Plus, Trash2, Copy, X, Grid3x3 as TableIcon, AlertTriangle, Check, Download, Upload } from "lucide-react"
import { useSeries } from "@/lib/series-context"
import type { Segment, Character, Storyline } from "@/lib/types"
import * as XLSX from "xlsx"

interface MultiSceneRow {
  id: string
  title: string
  description: string
  characterIds: string[]
  storylineIds: string[]
  duration: number
  notes: string
}

interface MultiSceneFormProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function MultiSceneForm({ open, onOpenChange }: MultiSceneFormProps) {
  const { data, addScene } = useSeries()

  // Filter active locations and moods, sorted alphabetically
  const activeLocations = data.locations
    .filter(location => location.isActive)
    .sort((a, b) => a.name.localeCompare(b.name))
  const activeMoods = data.moods
    .filter(mood => mood.isActive)
    .sort((a, b) => a.name.localeCompare(b.name))

  const [rows, setRows] = useState<MultiSceneRow[]>([
    {
      id: "row_1",
      title: "",
      description: "",
      characterIds: [],
      storylineIds: [],
      duration: 5,
      notes: "",
    }
  ])
  const [showConfirmDialog, setShowConfirmDialog] = useState(false)
  const [generatingScenes, setGeneratingScenes] = useState(false)
  const [currentField, setCurrentField] = useState<string>("")
  const [selectedRowId, setSelectedRowId] = useState<string | null>(null)
  const fileInputRef = React.useRef<HTMLInputElement>(null)

  const activeStorylines = data.storylines.filter(s => s.status !== "completed")
  const activeCharacters = data.characters
    .filter(c => c.status === "active")
    .sort((a, b) => a.name.localeCompare(b.name))

  const resetForm = () => {
    setRows([
      {
        id: `row_${Date.now()}_initial`,
        title: "",
        description: "",
        characterIds: [],
        storylineIds: [],
        duration: 5,
        notes: "",
      }
    ])
    setSelectedRowId(null)
  }

  useEffect(() => {
    if (!open) {
      resetForm()
    }
  }, [open])

  const addRow = () => {
    const newId = `row_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    const newRow: MultiSceneRow = {
      id: newId,
      title: "",
      description: "",
      characterIds: [],
      storylineIds: [],
      duration: 5,
      notes: "",
    }
    setRows([...rows, newRow])
  }

  const duplicateRow = (index: number) => {
    const rowToDuplicate = rows[index]
    const newId = `row_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    const duplicatedRow: MultiSceneRow = {
      ...rowToDuplicate,
      id: newId,
      title: rowToDuplicate.title ? `${(rowToDuplicate.title || "").trim()} (Kopie)` : "",
    }
    const newRows = [...rows]
    newRows.splice(index + 1, 0, duplicatedRow)
    setRows(newRows)
  }

  const deleteRow = (index: number) => {
    if (rows.length > 1) {
      const rowToDelete = rows[index]
      setRows(rows.filter((_, i) => i !== index))

      // Wenn die gelöschte Zeile markiert war, Selektion aufheben
      if (selectedRowId === rowToDelete.id) {
        setSelectedRowId(null)
      }
    }
  }

  const updateRow = (index: number, field: keyof MultiSceneRow, value: any) => {
    const newRows = [...rows]
    newRows[index] = { ...newRows[index], [field]: value }
    setRows(newRows)
  }

  const toggleStoryline = (rowIndex: number, storylineId: string) => {
    const row = rows[rowIndex]
    const currentIds = row.storylineIds || []
    const newStorylineIds = currentIds.includes(storylineId)
      ? currentIds.filter(id => id !== storylineId)
      : [...currentIds, storylineId]
    updateRow(rowIndex, "storylineIds", newStorylineIds)
  }

  const toggleCharacter = (rowIndex: number, charId: string) => {
    const row = rows[rowIndex]
    const currentIds = row.characterIds || []
    const newCharacterIds = currentIds.includes(charId)
      ? currentIds.filter(id => id !== charId)
      : [...currentIds, charId]
    updateRow(rowIndex, "characterIds", newCharacterIds)
  }

  const getValidRows = () => {
    return rows.filter(row => (row.title || "").trim() !== "")
  }

  const handleDeleteSelectedRow = () => {
    if (selectedRowId) {
      const rowIndex = rows.findIndex(row => row.id === selectedRowId)
      if (rowIndex !== -1 && rows.length > 1) {
        deleteRow(rowIndex)
        setSelectedRowId(null)
      }
    }
  }

  const handleRowSelect = (rowId: string) => {
    setSelectedRowId(selectedRowId === rowId ? null : rowId)
  }

  const handleMultiPaste = async (field: string) => {
    try {
      let clipboardText: string

      // Fallback für Browser ohne Clipboard API
      if (!navigator.clipboard) {
        clipboardText = prompt('Fügen Sie den Text ein:') || ''
        if (!clipboardText.trim()) return
      } else {
        clipboardText = await navigator.clipboard.readText()
      }

      // Zeilen parsen und validieren
      // Excel-Daten können unterschiedlich formatiert sein
      let lines: string[]

      if (clipboardText.includes('\t')) {
        // Mehrere Zellen (horizontal): Nach Tabulatoren trennen
        lines = clipboardText
          .split(/\t/)
          .map(line => line.trim())
          .filter(line => line.length > 0)
      } else if (clipboardText.includes('\n')) {
        // Mehrere Zeilen (vertikal): Nach Zeilenumbrüchen trennen
        lines = clipboardText
          .split(/\r?\n/)
          .map(line => line.trim())
          .filter(line => line.length > 0)
      } else {
        // Einzelne Zelle: Als eine Szene behandeln
        lines = [clipboardText.trim()].filter(line => line.length > 0)
      }

      // Validierung
      if (lines.length === 0) {
        alert('Keine Daten zum Einfügen gefunden.')
        return
      }

      if (lines.length > 10) {
        alert(`Maximum 10 Szenen erlaubt. ${lines.length} Szenen erkannt.`)
        return
      }

      // Alle kopierten Zeilen als neue Zeilen am Ende hinzufügen
      const newRows = lines.map((line) => ({
        id: `row_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        title: field === "title" ? line : "",
        description: field === "description" ? line : "",
        characterIds: [],
        storylineIds: [],
        duration: 5,
        notes: field === "notes" ? line : "",
      }))

      setRows([...rows, ...newRows])

      // Erfolgsmeldung
      alert(`${lines.length} Szenen erfolgreich in Feld "${field}" eingefügt!`)

    } catch (error) {
      console.error('Fehler beim Mehrfach-Einfügen:', error)
      alert('Fehler beim Einfügen. Stellen Sie sicher, dass Sie Text kopiert haben.')
    }
  }

  const handleDownloadTemplate = () => {
    const templateData = [
      {
        "Titel": "Beispiel-Segment 1",
        "Beschreibung": "Was passiert in diesem Segment...",
        "Wrestler": "Wrestler1, Wrestler2",
        "Storyline": "Storyline-Name",
        "Dauer (Minuten)": 10,
        "Notizen": "Zusätzliche Notizen"
      },
      {
        "Titel": "Beispiel-Segment 2",
        "Beschreibung": "Beschreibung des zweiten Segments...",
        "Wrestler": "Wrestler3",
        "Storyline": "Andere Storyline",
        "Dauer (Minuten)": 15,
        "Notizen": ""
      }
    ]

    const ws = XLSX.utils.json_to_sheet(templateData)
    const wb = XLSX.utils.book_new()
    XLSX.utils.book_append_sheet(wb, ws, "Multi-Segmente Template")
    XLSX.writeFile(wb, "multi-segments-template.xlsx")
  }

  const handleUploadTemplate = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer)
        const workbook = XLSX.read(data, { type: 'array' })
        const sheetName = workbook.SheetNames[0]
        const worksheet = workbook.Sheets[sheetName]
        const jsonData = XLSX.utils.sheet_to_json(worksheet) as any[]

        // Maximal 10 Zeilen verarbeiten
        const maxRows = Math.min(jsonData.length, 10)
        const newRows = jsonData.slice(0, maxRows).map((row: any, index: number) => {
          // Wrestler-String in Array umwandeln
          const wrestlerNames = (row["Wrestler"] || "").toString().split(",").map((name: string) => name.trim()).filter((name: string) => name)
          const characterIds = wrestlerNames.map((name: string) => {
            const character = activeCharacters.find(c => c.name === name)
            return character ? character.id : ""
          }).filter((id: string) => id)

          // Storyline ID finden
          const storylineName = (row["Storyline"] || "").toString().trim()
          const storyline = activeStorylines.find(s => s.title === storylineName)

          return {
            id: `row_${Date.now()}_${index}_${Math.random().toString(36).substr(2, 9)}`,
            title: (row["Titel"] || "").toString().trim(),
            description: (row["Beschreibung"] || "").toString().trim(),
            characterIds,
            storylineIds: storyline ? [storyline.id] : [],
            duration: Number(row["Dauer (Minuten)"]) || 5,
            notes: (row["Notizen"] || "").toString().trim()
          }
        })

        setRows(newRows)
        alert(`${maxRows} Segmente erfolgreich aus Excel importiert!`)
      } catch (error) {
        console.error('Fehler beim Einlesen der Excel-Datei:', error)
        alert('Fehler beim Einlesen der Excel-Datei. Bitte überprüfen Sie das Dateiformat.')
      }
    }
    reader.readAsArrayBuffer(file)

    // File Input zurücksetzen
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  const handleGenerateScenes = async () => {
    const validRows = getValidRows()
    if (validRows.length === 0) return

    setGeneratingScenes(true)
    try {
      // Generiere alle Szenen
      for (const row of validRows) {
        const sceneData = {
          title: (row.title || "").trim(),
          description: (row.description || "").trim(),
          notes: (row.notes || "").trim(),
          duration: row.duration || 5,
          storylineIds: row.storylineIds || [],
          characterIds: row.characterIds || [],
          order: data.segments.length,
        }
        await addScene(sceneData)
      }
      onOpenChange(false)
    } catch (error) {
      console.error("Fehler beim Erstellen der Szenen:", error)
    } finally {
      setGeneratingScenes(false)
    }
  }

  const handleGenerateClick = () => {
    const validRows = getValidRows()
    if (validRows.length === 0) {
      // Zeige Warnung wenn keine gültigen Zeilen
      return
    }
    setShowConfirmDialog(true)
  }

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent size="large" className="overflow-hidden">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <TableIcon className="h-5 w-5" />
              Multi-Segmente erstellen
            </DialogTitle>
            <DialogDescription>
              Erstelle mehrere Segmente auf einmal in einer tabellarischen Ansicht.
              Fülle die Zeilen aus und klicke auf "Segmente generieren".
            </DialogDescription>
          </DialogHeader>

          <div className="flex gap-4 mb-4">
            <Button onClick={addRow} variant="outline" size="sm" className="gap-2">
              <Plus className="h-4 w-4" />
              Zeile hinzufügen
            </Button>
            <Button
              onClick={handleDeleteSelectedRow}
              variant="outline"
              size="sm"
              className="gap-2"
              disabled={!selectedRowId || rows.length <= 1}
            >
              <Trash2 className="h-4 w-4" />
              Markierte Zeile löschen
            </Button>
            <Button
              onClick={handleDownloadTemplate}
              variant="outline"
              size="sm"
              className="gap-2"
            >
              <Download className="h-4 w-4" />
              Template Download
            </Button>
            <Button
              onClick={() => fileInputRef.current?.click()}
              variant="outline"
              size="sm"
              className="gap-2"
            >
              <Upload className="h-4 w-4" />
              Upload Template
            </Button>
            <input
              ref={fileInputRef}
              type="file"
              accept=".xlsx,.xls"
              onChange={handleUploadTemplate}
              className="hidden"
            />
          </div>

          <ScrollArea className="h-[500px] border rounded-md overflow-auto">
            <div className="min-w-max">
              <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12">#</TableHead>
                  <TableHead className="min-w-[180px]">Titel *</TableHead>
                  <TableHead className="min-w-[250px]">Beschreibung</TableHead>
                  <TableHead className="min-w-[220px]">Wrestler</TableHead>
                  <TableHead className="min-w-[180px]">Storyline</TableHead>
                  <TableHead className="min-w-[110px]">Dauer</TableHead>
                  <TableHead className="min-w-[180px]">Notizen</TableHead>
                  <TableHead className="w-32">Aktionen</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map((row, index) => (
                    <TableRow
                      key={row.id}
                      className={`align-top ${selectedRowId === row.id ? 'bg-muted/50' : ''}`}
                    >
                    <TableCell className="font-mono text-sm text-muted-foreground align-top pt-3">
                      <div className="flex items-center gap-2">
                        <input
                          type="radio"
                          name="row-select"
                          checked={selectedRowId === row.id}
                          onChange={() => handleRowSelect(row.id)}
                          className="w-4 h-4"
                        />
                        {index + 1}
                      </div>
                    </TableCell>
                    <TableCell className="align-top pt-3">
                      <ContextMenu>
                        <ContextMenuTrigger asChild>
                          <Input
                            value={row.title || ""}
                            onChange={(e) => updateRow(index, "title", e.target.value)}
                            onContextMenu={() => setCurrentField("title")}
                            placeholder="Segment-Titel"
                            className="min-w-[170px] max-w-[170px]"
                          />
                        </ContextMenuTrigger>
                        <ContextMenuContent>
                          <ContextMenuItem onClick={() => handleMultiPaste("title")}>
                            Als mehrere Zeilen einfügen
                          </ContextMenuItem>
                        </ContextMenuContent>
                      </ContextMenu>
                    </TableCell>
                    <TableCell className="align-top pt-3">
                      <ContextMenu>
                        <ContextMenuTrigger asChild>
                          <Textarea
                            value={row.description || ""}
                            onChange={(e) => updateRow(index, "description", e.target.value)}
                            onContextMenu={() => setCurrentField("description")}
                            placeholder="Was passiert..."
                            rows={2}
                            className="min-w-[240px] max-w-[240px] resize-none whitespace-pre-wrap break-words"
                          />
                        </ContextMenuTrigger>
                        <ContextMenuContent>
                          <ContextMenuItem onClick={() => handleMultiPaste("description")}>
                            Als mehrere Zeilen einfügen
                          </ContextMenuItem>
                        </ContextMenuContent>
                      </ContextMenu>
                    </TableCell>
                    <TableCell className="align-top">
                      <div className="min-w-[210px] space-y-2">
                        {activeCharacters.length === 0 ? (
                          <span className="text-sm text-muted-foreground">Keine Wrestler</span>
                        ) : (
                          <>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="outline" className="w-full justify-between">
                                  {(row.characterIds || []).length === 0
                                    ? "Wrestler auswählen..."
                                    : `${(row.characterIds || []).length} Wrestler ausgewählt`
                                  }
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent className="w-56 max-h-64 overflow-y-auto">
                                {activeCharacters.map((char) => (
                                  <DropdownMenuItem
                                    key={char.id}
                                    onClick={(e) => {
                                      e.preventDefault()
                                      toggleCharacter(index, char.id)
                                    }}
                                    className="flex items-center space-x-2 cursor-pointer p-2"
                                  >
                                    <Checkbox
                                      checked={(row.characterIds || []).includes(char.id)}
                                      className="pointer-events-none"
                                    />
                                    <span>{char.name}</span>
                                  </DropdownMenuItem>
                                ))}
                              </DropdownMenuContent>
                            </DropdownMenu>
                            {(row.characterIds || []).length > 0 && (
                              <div className="flex flex-col gap-1 max-h-20 overflow-y-auto">
                                {(row.characterIds || []).map((charId) => {
                                  const char = activeCharacters.find(c => c.id === charId)
                                  return char ? (
                                    <Badge key={char.id} variant="secondary" className="text-xs w-fit">
                                      {char.name}
                                      <X
                                        className="h-3 w-3 ml-1 cursor-pointer hover:text-destructive"
                                        onClick={() => toggleCharacter(index, char.id)}
                                      />
                                    </Badge>
                                  ) : null
                                })}
                              </div>
                            )}
                          </>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="align-top pt-3">
                      <div className="min-w-[210px] space-y-2">
                        {activeStorylines.length === 0 ? (
                          <span className="text-sm text-muted-foreground">Keine Storylines</span>
                        ) : (
                          <>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="outline" className="w-full justify-between">
                                  {(row.storylineIds || []).length === 0
                                    ? "Storylines auswählen..."
                                    : `${(row.storylineIds || []).length} Storylines ausgewählt`
                                  }
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent className="w-56 max-h-64 overflow-y-auto">
                                {activeStorylines.map((storyline) => (
                                  <DropdownMenuItem
                                    key={storyline.id}
                                    onClick={(e) => {
                                      e.preventDefault()
                                      toggleStoryline(index, storyline.id)
                                    }}
                                    className="flex items-center space-x-2 cursor-pointer p-2"
                                  >
                                    <Checkbox
                                      checked={(row.storylineIds || []).includes(storyline.id)}
                                      className="pointer-events-none"
                                    />
                                    <div className="flex items-center gap-2">
                                      <div
                                        className="h-3 w-3 rounded-full shrink-0"
                                        style={{ backgroundColor: storyline.color }}
                                      />
                                      <span>{storyline.title}</span>
                                    </div>
                                  </DropdownMenuItem>
                                ))}
                              </DropdownMenuContent>
                            </DropdownMenu>
                            {(row.storylineIds || []).length > 0 && (
                              <div className="flex flex-col gap-1 max-h-20 overflow-y-auto">
                                {(row.storylineIds || []).map((storylineId) => {
                                  const storyline = activeStorylines.find(s => s.id === storylineId)
                                  return storyline ? (
                                    <Badge key={storyline.id} variant="secondary" className="text-xs w-fit">
                                      <div className="flex items-center gap-1">
                                        <div
                                          className="h-2 w-2 rounded-full"
                                          style={{ backgroundColor: storyline.color }}
                                        />
                                        {storyline.title}
                                      </div>
                                      <X
                                        className="h-3 w-3 ml-1 cursor-pointer hover:text-destructive"
                                        onClick={() => toggleStoryline(index, storyline.id)}
                                      />
                                    </Badge>
                                  ) : null
                                })}
                              </div>
                            )}
                          </>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="align-top pt-3">
                      <Input
                        type="number"
                        min={1}
                        max={60}
                        value={row.duration || 5}
                        onChange={(e) => updateRow(index, "duration", Number.parseInt(e.target.value) || 5)}
                        className="min-w-[90px] max-w-[90px]"
                      />
                    </TableCell>
                    <TableCell className="align-top pt-3">
                      <ContextMenu>
                        <ContextMenuTrigger asChild>
                          <Textarea
                            value={row.notes || ""}
                            onChange={(e) => updateRow(index, "notes", e.target.value)}
                            onContextMenu={() => setCurrentField("notes")}
                            placeholder="Zusätzliche Notizen"
                            rows={2}
                            className="min-w-[170px] max-w-[170px] resize-none whitespace-pre-wrap break-words"
                          />
                        </ContextMenuTrigger>
                        <ContextMenuContent>
                          <ContextMenuItem onClick={() => handleMultiPaste("notes")}>
                            Als mehrere Zeilen einfügen
                          </ContextMenuItem>
                        </ContextMenuContent>
                      </ContextMenu>
                    </TableCell>
                    <TableCell className="align-top pt-3">
                      <div className="flex gap-1">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => duplicateRow(index)}
                          className="h-8 w-8 p-0"
                        >
                          <Copy className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => deleteRow(index)}
                          disabled={rows.length === 1}
                          className="h-8 w-8 p-0 text-destructive hover:text-destructive"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
              </Table>
            </div>
          </ScrollArea>

          <div className="flex justify-between items-center pt-4 border-t">
            <div className="text-sm text-muted-foreground">
              {getValidRows().length} von {rows.length} Zeilen sind gültig (Titel erforderlich)
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => onOpenChange(false)}>
                Abbrechen
              </Button>
              <Button
                onClick={handleGenerateClick}
                disabled={getValidRows().length === 0 || generatingScenes}
                className="gap-2"
              >
                {generatingScenes ? (
                  <>Erstelle Segmente...</>
                ) : (
                  <>
                    <TableIcon className="h-4 w-4" />
                    Segmente generieren ({getValidRows().length})
                  </>
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <AlertDialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Segmente generieren?</AlertDialogTitle>
            <AlertDialogDescription>
              {getValidRows().length === 1
                ? "Ein Segment wird erstellt."
                : `${getValidRows().length} Segmente werden erstellt.`
              }
              Diese Aktion kann nicht rückgängig gemacht werden.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Abbrechen</AlertDialogCancel>
            <AlertDialogAction onClick={handleGenerateScenes}>
              Segmente generieren
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}