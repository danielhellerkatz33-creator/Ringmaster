"use client"

import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { useSeries } from "@/lib/series-context"
import type { Character, Storyline } from "@/lib/types"
import { Heart, TrendingUp, Film, BookOpen, AlertCircle } from "lucide-react"
import { CharacterAvatar } from "@/components/character-avatar"

interface CharacterDetailProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  character: Character
}

const positionLabels: Record<Character["position"], string> = {
  main_event: "Main Event",
  upper_card: "Upper Card",
  mid_card: "Mid Card",
  lower_card: "Lower Card",
  jobber: "Jobber",
  road_agent: "Road Agent",
  manager: "Manager",
  staff: "Staff",
  commentary: "Commentary",
  referee: "Referee",
}

const alignmentLabels: Record<Character["alignment"], string> = {
  face: "Face",
  heel: "Heel",
  tweener: "Tweener",
}

const statusLabels: Record<Character["status"], string> = {
  active: "Active",
  injured: "Injured",
  suspended: "Suspended",
  retired: "Retired",
  inactive: "Inactive",
}

interface CharacterSummarySection {
  character: Character | null
  characterName: string
  content: string
  hasValidCharacter: boolean
}

const parseCharacterSummaries = (summary: string, characters: Character[]): CharacterSummarySection[] => {
  const sections: CharacterSummarySection[] = []

  // Finde alle Charakter-Absätze mit Regex
  // Pattern: Name: Inhalt (bis zum nächsten Name: oder Ende)
  // Unterstützt Namen wie "Vera Richter" oder "Peter Becker"
  const pattern = /([A-Z][a-zäöüÄÖÜß]+(?:\s+[A-Z][a-zäöüÄÖÜß]+)*):\s*([^]*?)(?=\n\n[A-Z][a-zäöüÄÖÜß]+(?:\s+[A-Z][a-zäöüÄÖÜß]+)*:|$(?![\r\n]))/g

  let match
  while ((match = pattern.exec(summary)) !== null) {
    const characterName = match[1].trim()
    const content = match[2].trim()

    // Finde passenden Charakter
    const character = characters.find(c => c.name === characterName)

    sections.push({
      character,
      characterName,
      content,
      hasValidCharacter: !!character
    })
  }

  return sections
}

export function CharacterDetail({ open, onOpenChange, character }: CharacterDetailProps) {
  const { data } = useSeries()

  const relationships = data.relationships.filter(
    (r) => {
      // Handle both old and new data structure
      const characterIds = r.characterIds || 
        ((r as any).characterId1 && (r as any).characterId2 ? 
          [(r as any).characterId1, (r as any).characterId2] : [])
      return characterIds.includes(character.id)
    }
  )

  const arcs = data.characterArcs.filter((a) => a.characterId === character.id)
  const storylines = data.storylines.filter((s) => s.characterIds.includes(character.id))
  const scenes = data.scenes.filter((s) => s.characterIds.includes(character.id))

  // Abgeschlossene Storylines mit Charakterrückblicken für diesen Charakter
  const completedStorylinesWithCharacterReviews = data.storylines
    .filter((s) => s.status === "completed" && s.characterReview && s.characterIds.includes(character.id))
    .map((storyline) => ({
      storyline,
      characterSummary: parseCharacterSummaries(storyline.characterReview!, data.characters)
        .find(section => section.characterName === character.name)
    }))
    .filter(item => item.characterSummary)

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center gap-4">
            <CharacterAvatar key={character.id + character.avatarBlobId + character.updatedAt} name={character.name} imageUrl={character.imageUrl} character={character} size="xl" />
            <div>
              <DialogTitle className="text-2xl">{character.name}</DialogTitle>
              <DialogDescription>
                Detaillierte Informationen über diesen Charakter einschließlich Charakterrückblicke, Character Arcs und Szenen.
              </DialogDescription>
              <div className="flex gap-1 mt-1">
                <Badge variant="outline" className="text-xs">
                  {positionLabels[character.position]}
                </Badge>
                <Badge 
                  className={`text-xs border-0 ${
                    character.alignment === 'face' ? 'bg-blue-500/20 text-blue-500' :
                    character.alignment === 'heel' ? 'bg-red-500/20 text-red-500' :
                    'bg-gray-500/20 text-gray-500'
                  }`}
                >
                  {alignmentLabels[character.alignment]}
                </Badge>
                <Badge 
                  variant={character.status === 'active' ? 'default' : 'secondary'}
                  className="text-xs"
                >
                  {statusLabels[character.status]}
                </Badge>
              </div>
            </div>
          </div>
        </DialogHeader>

        <div className="space-y-6 mt-4">
          {/* Stats Overview */}
          <div className="grid grid-cols-4 gap-3">
            <div className="flex flex-col items-center p-3 rounded-lg bg-muted/50">
              <BookOpen className="h-5 w-5 text-muted-foreground mb-1" />
              <span className="text-xl font-bold text-foreground">{completedStorylinesWithCharacterReviews.length}</span>
              <span className="text-xs text-muted-foreground">Stories</span>
            </div>
            <div className="flex flex-col items-center p-3 rounded-lg bg-muted/50">
              <TrendingUp className="h-5 w-5 text-muted-foreground mb-1" />
              <span className="text-xl font-bold text-foreground">{arcs.length}</span>
              <span className="text-xs text-muted-foreground">Arcs</span>
            </div>
            <div className="flex flex-col items-center p-3 rounded-lg bg-muted/50">
              <Film className="h-5 w-5 text-muted-foreground mb-1" />
              <span className="text-xl font-bold text-foreground">{scenes.length}</span>
              <span className="text-xs text-muted-foreground">Szenen</span>
            </div>
            <div className="flex flex-col items-center p-3 rounded-lg bg-muted/50">
              <Heart className="h-5 w-5 text-muted-foreground mb-1" />
              <span className="text-xl font-bold text-foreground">{relationships.length}</span>
              <span className="text-xs text-muted-foreground">Beziehungen</span>
            </div>
          </div>

          {/* Description */}
          {character.description && (
            <div>
              <h4 className="text-sm font-semibold text-foreground mb-2">Beschreibung</h4>
              <p className="text-sm text-muted-foreground leading-relaxed">{character.description}</p>
            </div>
          )}

          {/* Backstory */}
          {character.backstory && (
            <div>
              <h4 className="text-sm font-semibold text-foreground mb-2">Hintergrundgeschichte</h4>
              <p className="text-sm text-muted-foreground leading-relaxed">{character.backstory}</p>
            </div>
          )}

          {/* Traits */}
          {character.traits.length > 0 && (
            <div>
              <h4 className="text-sm font-semibold text-foreground mb-2">Eigenschaften</h4>
              <div className="flex flex-wrap gap-2">
                {character.traits.map((trait) => (
                  <Badge key={trait} variant="outline">
                    {trait}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          <Separator />

          {/* Charakterrückblicke */}
          <div>
            <h4 className="text-sm font-semibold text-foreground mb-3">Charakterrückblicke</h4>
            {completedStorylinesWithCharacterReviews.length === 0 ? (
              <p className="text-sm text-muted-foreground">Keine abgeschlossenen Storylines mit Charakterrückblicken für diesen Charakter.</p>
            ) : (
              <div className="space-y-3">
                {completedStorylinesWithCharacterReviews.map(({ storyline, characterSummary }) => (
                  <div key={storyline.id} className="p-4 rounded-lg bg-muted/30 border border-muted/50">
                    <div className="flex items-start gap-3 mb-2">
                      <div
                        className="h-4 w-4 rounded-full mt-1 shrink-0"
                        style={{ backgroundColor: storyline.color }}
                      />
                      <div className="flex-1">
                        <h5 className="text-sm font-medium text-foreground mb-1">{storyline.title}</h5>
                        <Badge variant="outline" className="text-xs capitalize">
                          {storyline.type === "main" ? "Haupthandlung" :
                           storyline.type === "subplot" ? "Nebenhandlung" : "Story Arc"}
                        </Badge>
                      </div>
                    </div>
                    {characterSummary && (
                      <div className="ml-7">
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          {characterSummary.content}
                        </p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Character Arcs */}
          {arcs.length > 0 && (
            <div>
              <h4 className="text-sm font-semibold text-foreground mb-3">Character Arcs</h4>
              <div className="space-y-2">
                {arcs.map((arc) => (
                  <div key={arc.id} className="p-3 rounded-lg bg-muted/30">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-medium text-foreground text-sm">{arc.title}</span>
                      <Badge variant={arc.status === "active" ? "default" : "outline"} className="text-xs capitalize">
                        {arc.status}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground">{arc.description}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
