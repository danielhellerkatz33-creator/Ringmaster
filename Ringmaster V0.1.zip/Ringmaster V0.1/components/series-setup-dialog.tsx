"use client"

import type React from "react"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { X } from "lucide-react"
import { useSeries } from "@/lib/series-context"

interface SeriesSetupDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

const genreOptions = [
  "Drama",
  "Comedy",
  "Thriller",
  "Sci-Fi",
  "Fantasy",
  "Horror",
  "Romance",
  "Action",
  "Mystery",
  "Crime",
  "Documentary",
]

export function SeriesSetupDialog({ open, onOpenChange }: SeriesSetupDialogProps) {
  const { createSeries } = useSeries()
  const [title, setTitle] = useState("")
  const [logline, setLogline] = useState("")
  const [selectedGenres, setSelectedGenres] = useState<string[]>([])

  const toggleGenre = (genre: string) => {
    setSelectedGenres((prev) => (prev.includes(genre) ? prev.filter((g) => g !== genre) : [...prev, genre]))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!title.trim()) return

    createSeries({
      title: title.trim(),
      logline: logline.trim(),
      genre: selectedGenres,
    })
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Neue Serie erstellen</DialogTitle>
          <DialogDescription>Gib deiner Serie einen Namen und beschreibe sie kurz.</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="title">Titel der Serie</Label>
            <Input
              id="title"
              placeholder="z.B. Breaking Bad"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="logline">Logline</Label>
            <Textarea
              id="logline"
              placeholder="Eine kurze Zusammenfassung der Serie in 1-2 Sätzen..."
              value={logline}
              onChange={(e) => setLogline(e.target.value)}
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label>Genre</Label>
            <div className="flex flex-wrap gap-2">
              {genreOptions.map((genre) => (
                <Badge
                  key={genre}
                  variant={selectedGenres.includes(genre) ? "default" : "outline"}
                  className="cursor-pointer"
                  onClick={() => toggleGenre(genre)}
                >
                  {genre}
                  {selectedGenres.includes(genre) && <X className="h-3 w-3 ml-1" />}
                </Badge>
              ))}
            </div>
          </div>

          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Abbrechen
            </Button>
            <Button type="submit" disabled={!title.trim()}>
              Serie erstellen
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
