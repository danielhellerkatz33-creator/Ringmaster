"use client"

import { useState, useEffect } from "react"
import { cn } from "@/lib/utils"
import { useSeries } from "@/lib/series-context"
import type { Character } from "@/lib/types"

interface CharacterAvatarProps {
  name?: string
  imageUrl?: string
  character?: Character
  size?: "xs" | "sm" | "md" | "lg" | "xl"
  className?: string
}

const sizeClasses = {
  xs: "h-6 w-6 text-xs",
  sm: "h-8 w-8 text-xs",
  md: "h-10 w-10 text-sm",
  lg: "h-12 w-12 text-lg",
  xl: "h-16 w-16 text-2xl",
}

export function CharacterAvatar({ name, imageUrl, character, size = "md", className }: CharacterAvatarProps) {
  const { getAvatarUrl, storageReady } = useSeries()
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null)
  const sizeClass = sizeClasses[size]

  // Use name from props or character object
  const displayName = name || character?.name || "?"

  // Load avatar from IndexedDB if character has avatarBlobId
  useEffect(() => {
    if (character?.avatarBlobId && storageReady) {
      getAvatarUrl(character).then(setAvatarUrl)
    }
  }, [character, storageReady, getAvatarUrl])

  // Use imageUrl prop, then character.imageUrl, then avatarUrl (IndexedDB), or fallback to initials
  const displayUrl = imageUrl || character?.imageUrl || avatarUrl

  if (displayUrl) {
    return (
      <div className={cn("rounded-full overflow-hidden flex-shrink-0", sizeClass, className)}>
        <img
          src={displayUrl}
          alt={displayName}
          className="h-full w-full object-cover"
          crossOrigin="anonymous"
        />
      </div>
    )
  }

  return (
    <div
      className={cn("rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0", sizeClass, className)}
    >
      <span className="font-semibold text-primary">{displayName.charAt(0).toUpperCase()}</span>
    </div>
  )
}
