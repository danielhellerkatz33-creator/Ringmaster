"use client"

import React from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { MoreVertical, Pencil, Trash2, ArrowRight } from "lucide-react"
import type { Relationship, Character } from "@/lib/types"
import { CharacterAvatar } from "@/components/character-avatar"

const typeLabels: Record<Relationship["type"], string> = {
  tag_team: "Tag Team",
  stable: "Stable",
  manager: "Manager",
  rivalry: "Rivalität",
  friendship: "Freundschaft",
}

const typeColors: Record<Relationship["type"], string> = {
  tag_team: "bg-purple-500/20 text-purple-500",
  stable: "bg-orange-500/20 text-orange-500",
  manager: "bg-indigo-500/20 text-indigo-500",
  rivalry: "bg-red-500/20 text-red-500",
  friendship: "bg-green-500/20 text-green-500",
}

interface RelationshipsCardsViewProps {
  relationships: Relationship[]
  characters: Character[]
  onEdit: (relationship: Relationship) => void
  onDelete: (id: string) => void
}

export function RelationshipsCardsView({
  relationships,
  characters,
  onEdit,
  onDelete
}: RelationshipsCardsViewProps) {
  const getCharacter = (id: string) => characters.find((c) => c.id === id)

  // Group relationships by type
  const groupedRelationships = Object.entries(typeLabels).reduce(
    (acc, [type]) => {
      acc[type as Relationship["type"]] = relationships.filter((r) => r.type === type)
      return acc
    },
    {} as Record<Relationship["type"], Relationship[]>,
  )

  return (
    <div className="space-y-8">
      {Object.entries(groupedRelationships).map(([type, relationships]) => {
        if (relationships.length === 0) return null
        return (
          <div key={type}>
            <h2 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
              <Badge className={`${typeColors[type as Relationship["type"]]} border-0`}>
                {typeLabels[type as Relationship["type"]]}
              </Badge>
              <span className="text-muted-foreground text-sm font-normal">({relationships.length})</span>
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {relationships.map((rel) => {
                // Handle both old and new data structure for backward compatibility
                const characterIds = rel.characterIds || 
                  ((rel as any).characterId1 && (rel as any).characterId2 ? 
                    [(rel as any).characterId1, (rel as any).characterId2] : [])
                const characters = characterIds.map(id => getCharacter(id)).filter(Boolean)
                if (characters.length < 2) return null

                return (
                  <Card key={rel.id} className="group hover:border-primary/50 transition-colors bg-card">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center gap-2">
                          {characters.map((char, index) => {
                            if (!char) return null
                            return (
                              <React.Fragment key={char.id}>
                                <CharacterAvatar name={char.name} imageUrl={char.imageUrl} character={char} size="md" />
                                {index < characters.length - 1 && (
                                  <ArrowRight className="h-4 w-4 text-muted-foreground" />
                                )}
                              </React.Fragment>
                            )
                          })}
                        </div>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity"
                            >
                              <MoreVertical className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => onEdit(rel)}>
                              <Pencil className="h-4 w-4 mr-2" />
                              Bearbeiten
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              onClick={() => onDelete(rel.id)}
                              className="text-destructive focus:text-destructive"
                            >
                              <Trash2 className="h-4 w-4 mr-2" />
                              Löschen
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>

                      <div className="mb-2">
                        <p className="text-sm font-medium text-foreground">
                          {characters.map(c => c?.name).filter(Boolean).join(" & ")}
                        </p>
                      </div>

                      {rel.description && (
                        <p className="text-sm text-muted-foreground line-clamp-2 mb-3">{rel.description}</p>
                      )}

                      {/* Wrestling-specific fields */}
                      {(rel.type === "tag_team" || rel.type === "stable") && (
                        <div className="space-y-2 mb-3">
                          {rel.teamName && (
                            <div className="flex items-center gap-2">
                              <Badge variant="outline" className="text-xs">
                                {rel.teamName}
                              </Badge>
                              <Badge 
                                variant={rel.isActive ? "default" : "secondary"} 
                                className="text-xs"
                              >
                                {rel.isActive ? "Aktiv" : "Inaktiv"}
                              </Badge>
                            </div>
                          )}
                          
                          {/* Show stable members */}
                          {rel.type === "stable" && characterIds.length > 2 && (
                            <div className="flex flex-wrap gap-1">
                              {characterIds.slice(2).map((memberId) => {
                                const member = characters.find(c => c?.id === memberId)
                                return member ? (
                                  <Badge key={memberId} variant="secondary" className="text-xs">
                                    {member.name}
                                  </Badge>
                                ) : null
                              })}
                            </div>
                          )}
                        </div>
                      )}

                      <div className="flex items-center justify-between">
                        <span className="text-xs text-muted-foreground">Intensität</span>
                        <div className="flex items-center gap-1">
                          {Array.from({ length: 10 }).map((_, i) => (
                            <div
                              key={i}
                              className={`h-2 w-2 rounded-full ${i < rel.intensity ? "bg-primary" : "bg-muted"}`}
                            />
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </div>
        )
      })}
    </div>
  )
}