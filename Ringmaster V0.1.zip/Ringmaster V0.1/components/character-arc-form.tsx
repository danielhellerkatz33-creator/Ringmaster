"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { format } from "date-fns"
import { de } from "date-fns/locale"
import { Upload, X, Calendar as CalendarIcon } from "lucide-react"
import { cn } from "@/lib/utils"
import { useSeries } from "@/lib/series-context"
import type { CharacterArc } from "@/lib/types"

interface CharacterArcFormProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  arc?: CharacterArc
}

export function ChampionshipForm({ open, onOpenChange, arc }: CharacterArcFormProps) {
  const { data, addCharacterArc, updateCharacterArc } = useSeries()
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [foundingDate, setFoundingDate] = useState<Date>()
  const [image, setImage] = useState<string | undefined>()
  const [type, setType] = useState<CharacterArc["type"]>("singles")
  const [status, setStatus] = useState<CharacterArc["status"]>("active")
  const [prestige, setPrestige] = useState<CharacterArc["prestige"]>("world")
  const [currentChampionIds, setCurrentChampionIds] = useState<string[]>([])

  const isEditing = !!arc

  useEffect(() => {
    if (arc) {
      setTitle(arc.title)
      setDescription(arc.description)
      setFoundingDate(arc.startEpisodeId ? new Date(arc.startEpisodeId) : undefined)
      setImage(arc.image)
      setType(arc.type || "singles")
      setStatus(arc.status || "active")
      setPrestige(arc.prestige || "world")
      setCurrentChampionIds(arc.currentChampionIds || [])
    } else {
      resetForm()
    }
  }, [arc, open])

  const resetForm = () => {
    setTitle("")
    setDescription("")
    setFoundingDate(undefined)
    setImage(undefined)
    setType("singles")
    setStatus("active")
    setPrestige("world")
    setCurrentChampionIds([])
  }

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    if (file.size > 5 * 1024 * 1024) {
      alert("Bild ist zu groß. Maximale Größe: 5MB")
      return
    }

    const reader = new FileReader()
    reader.onloadend = () => {
      setImage(reader.result as string)
    }
    reader.readAsDataURL(file)
  }

  const handleChampionSelect = (characterId: string) => {
    if (type === "singles") {
      // Singles: Nur ein Champion
      setCurrentChampionIds([characterId])
    } else {
      // Tag Teams, Trios, Six-Man: Multiple Champions
      const maxChampions = type === "tag_team" ? 2 : type === "trios" ? 3 : 6
      if (currentChampionIds.includes(characterId)) {
        // Entfernen
        setCurrentChampionIds(currentChampionIds.filter(id => id !== characterId))
      } else {
        // Hinzufügen
        if (currentChampionIds.length < maxChampions) {
          setCurrentChampionIds([...currentChampionIds, characterId])
        }
      }
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!title.trim()) return

    const championshipData: Omit<CharacterArc, "id"> = {
      characterId: "championship", // Fixed ID für Championships
      title: title.trim(),
      description: description.trim(),
      startEpisodeId: foundingDate ? foundingDate.toISOString() : undefined,
      endEpisodeId: foundingDate ? foundingDate.toISOString() : undefined, // Gleich wie Gründungsdatum
      status,
      milestones: arc?.milestones || [],
      image,
      type,
      prestige,
      currentChampionIds,
      championHistory: arc?.championHistory || [],
      createdAt: arc?.createdAt || new Date(),
      updatedAt: new Date(),
    }

    if (isEditing) {
      updateCharacterArc({
        ...arc,
        ...championshipData,
      })
    } else {
      addCharacterArc(championshipData)
    }

    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{isEditing ? "Championship bearbeiten" : "Neues Championship"}</DialogTitle>
          <DialogDescription>
            {isEditing
              ? "Bearbeite die Details dieses Championships."
              : "Erstelle ein neues Championship für deine Promotion."
            }
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="space-y-2">
            <Label htmlFor="title">Championship Name</Label>
            <Input
              id="title"
              placeholder="z.B. World Heavyweight Championship"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Championship Beschreibung</Label>
            <Textarea
              id="description"
              placeholder="Beschreibe die Geschichte und Bedeutung dieses Championships..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label>Championship Bild</Label>
            <div className="space-y-3">
              {image ? (
                <div className="relative">
                  <img
                    src={image}
                    alt="Championship Bild"
                    className="w-full h-32 object-cover rounded-lg"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    className="absolute top-2 right-2"
                    onClick={() => setImage(undefined)}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ) : (
                <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-6">
                  <div className="text-center">
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="hidden"
                      id="image-upload"
                    />
                    <label
                      htmlFor="image-upload"
                      className="cursor-pointer inline-flex flex-col items-center justify-center"
                    >
                      <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center mb-3">
                        <Upload className="h-6 w-6 text-muted-foreground" />
                      </div>
                      <span className="text-sm text-muted-foreground">
                        Klicke zum Hochladen
                      </span>
                      <span className="text-xs text-muted-foreground">
                        JPG, PNG oder GIF. Max 5MB.
                      </span>
                    </label>
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="space-y-2">
            <Label>Gründungsdatum</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className="w-full justify-start text-left font-normal"
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {foundingDate ? format(foundingDate, "dd.MM.yyyy", { locale: de }) : "Datum auswählen"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={foundingDate}
                  onSelect={setFoundingDate}
                  initialFocus
                  locale={de}
                  captionLayout="dropdown"
                  fromYear={1950}
                  toYear={2030}
                  defaultMonth={new Date(1988, 0, 1)}
                />
              </PopoverContent>
            </Popover>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Typ</Label>
              <Select value={type} onValueChange={(v) => setType(v as CharacterArc["type"])}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="singles">Singles</SelectItem>
                  <SelectItem value="tag_team">Tag Team</SelectItem>
                  <SelectItem value="trios">Trios</SelectItem>
                  <SelectItem value="six_man">Six-Man</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Prestige</Label>
              <Select value={prestige} onValueChange={(v) => setPrestige(v as CharacterArc["prestige"])}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="world">World</SelectItem>
                  <SelectItem value="national">National</SelectItem>
                  <SelectItem value="regional">Regional</SelectItem>
                  <SelectItem value="local">Local</SelectItem>
                  <SelectItem value="developmental">Developmental</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Status</Label>
            <Select value={status} onValueChange={(v) => setStatus(v as CharacterArc["status"])}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="active">Aktiv</SelectItem>
                <SelectItem value="inactive">Inaktiv</SelectItem>
                <SelectItem value="planned">Geplant</SelectItem>
                <SelectItem value="completed">Abgeschlossen</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {status === "active" && (
            <div className="space-y-2">
              <Label>Aktuelle Champion{type !== "singles" ? "s" : ""}</Label>
              <div className="space-y-2 max-h-32 overflow-y-auto">
                {[...data.characters]
                  .sort((a, b) => a.name.localeCompare(b.name))
                  .map((character) => (
                  <div key={character.id} className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id={`champion-${character.id}`}
                      checked={currentChampionIds.includes(character.id)}
                      onChange={() => handleChampionSelect(character.id)}
                      className="rounded"
                    />
                    <Label htmlFor={`champion-${character.id}`} className="text-sm">
                      {character.name}
                    </Label>
                  </div>
                ))}
              </div>
              {type !== "singles" && (
                <p className="text-xs text-muted-foreground">
                  {type === "tag_team" ? "Wähle 2 Wrestler" : 
                   type === "trios" ? "Wähle 3 Wrestler" : 
                   "Wähle bis zu 6 Wrestler"}
                </p>
              )}
            </div>
          )}

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Abbrechen
            </Button>
            <Button type="submit" disabled={!title.trim()}>
              {isEditing ? "Speichern" : "Erstellen"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
