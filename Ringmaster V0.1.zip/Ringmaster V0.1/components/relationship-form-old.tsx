"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Checkbox } from "@/components/ui/checkbox"
import { Badge } from "@/components/ui/badge"
import { useSeries } from "@/lib/series-context"
import type { Relationship } from "@/lib/types"

interface RelationshipFormProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  relationship?: Relationship
}

const typeLabels: Record<Relationship["type"], string> = {
  tag_team: "Tag Team",
  stable: "Stable",
  manager: "Manager",
}

export function RelationshipForm({ open, onOpenChange, relationship }: RelationshipFormProps) {
  const { data, addRelationship, updateRelationship } = useSeries()
  const [characterIds, setCharacterIds] = useState<string[]>([])
  const [type, setType] = useState<Relationship["type"]>("tag_team")
  const [description, setDescription] = useState("")
  const [intensity, setIntensity] = useState(5)
  const [teamName, setTeamName] = useState("")
  const [isActive, setIsActive] = useState(true)

  const isEditing = !!relationship

  useEffect(() => {
    if (relationship) {
      setCharacter1(relationship.characterId1)
      setCharacter2(relationship.characterId2)
      setType(relationship.type)
      setDescription(relationship.description)
      setIntensity(relationship.intensity)
      setTeamName(relationship.teamName || "")
      setIsActive(relationship.isActive ?? true)
      setStableMembers(relationship.stableMemberIds || [])
    } else {
      resetForm()
    }
  }, [relationship, open])

  const resetForm = () => {
    setCharacter1("")
    setCharacter2("")
    setType("tag_team")
    setDescription("")
    setIntensity(5)
    setTeamName("")
    setIsActive(true)
    setStableMembers([])
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!character1 || !character2 || character1 === character2) return

    const relationshipData = {
      characterId1: character1,
      characterId2: character2,
      type,
      description: description.trim(),
      intensity,
      episodes: relationship?.episodes || [],
      evolution: relationship?.evolution || [],
      teamName: (type === "tag_team" || type === "stable") ? teamName.trim() : undefined,
      isActive: (type === "tag_team" || type === "stable") ? isActive : undefined,
      stableMemberIds: type === "stable" ? stableMembers : undefined,
    }

    if (isEditing) {
      updateRelationship({
        ...relationship,
        ...relationshipData,
      })
    } else {
      addRelationship(relationshipData)
    }

    onOpenChange(false)
  }

  const availableCharacters2 = data.characters.filter((c) => c.id !== character1)
  
  // For stables, get characters that are not already selected
  const availableStableMembers = data.characters.filter((c) => 
    c.id !== character1 && 
    c.id !== character2 && 
    !stableMembers.includes(c.id)
  )

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{isEditing ? "Beziehung bearbeiten" : "Neue Beziehung erstellen"}</DialogTitle>
          <DialogDescription>
            {isEditing
              ? "Bearbeite die Details dieser Charakterbeziehung."
              : "Erstelle eine neue Beziehung zwischen zwei Charakteren."
            }
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Charakter 1</Label>
              <Select value={character1} onValueChange={setCharacter1} disabled={isEditing}>
                <SelectTrigger>
                  <SelectValue placeholder="Auswählen..." />
                </SelectTrigger>
                <SelectContent>
                  {data.characters.map((char) => (
                    <SelectItem key={char.id} value={char.id}>
                      {char.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Charakter 2</Label>
              <Select value={character2} onValueChange={setCharacter2} disabled={isEditing || !character1}>
                <SelectTrigger>
                  <SelectValue placeholder="Auswählen..." />
                </SelectTrigger>
                <SelectContent>
                  {availableCharacters2.map((char) => (
                    <SelectItem key={char.id} value={char.id}>
                      {char.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Art der Beziehung</Label>
            <Select value={type} onValueChange={(v) => setType(v as Relationship["type"])}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(typeLabels).map(([value, label]) => (
                  <SelectItem key={value} value={value}>
                    {label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Wrestling-specific fields */}
          {(type === "tag_team" || type === "stable") && (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>{type === "tag_team" ? "Teamname" : "Stablename"}</Label>
                <input
                  type="text"
                  value={teamName}
                  onChange={(e) => setTeamName(e.target.value)}
                  placeholder={type === "tag_team" ? "z.B. The Hardy Boyz" : "z.B. The New Day"}
                  className="w-full px-3 py-2 border border-input bg-background rounded-md text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                />
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="is-active"
                  checked={isActive}
                  onCheckedChange={(checked: boolean) => setIsActive(checked)}
                />
                <label
                  htmlFor="is-active"
                  className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                >
                  Aktiv
                </label>
              </div>

              {/* Stable-specific: Additional members */}
              {type === "stable" && (
                <div className="space-y-2">
                  <Label>Weitere Stable-Mitglieder</Label>
                  <div className="space-y-2">
                    {stableMembers.length > 0 && (
                      <div className="flex flex-wrap gap-2">
                        {stableMembers.map((memberId) => {
                          const member = data.characters.find(c => c.id === memberId)
                          return member ? (
                            <Badge key={memberId} variant="secondary" className="flex items-center gap-1">
                              {member.name}
                              <button
                                type="button"
                                onClick={() => setStableMembers(prev => prev.filter(id => id !== memberId))}
                                className="ml-1 text-xs hover:text-destructive"
                              >
                                ×
                              </button>
                            </Badge>
                          ) : null
                        })}
                      </div>
                    )}
                    
                    {availableStableMembers.length > 0 && (
                      <Select onValueChange={(value) => setStableMembers(prev => [...prev, value])}>
                        <SelectTrigger>
                          <SelectValue placeholder="Mitglied hinzufügen..." />
                        </SelectTrigger>
                        <SelectContent>
                          {availableStableMembers.map((char) => (
                            <SelectItem key={char.id} value={char.id}>
                              {char.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="description">Beschreibung</Label>
            <Textarea
              id="description"
              placeholder="Beschreibe die Beziehung zwischen den Charakteren..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
            />
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label>Intensität</Label>
              <span className="text-sm text-muted-foreground">{intensity}/10</span>
            </div>
            <Slider value={[intensity]} onValueChange={(v) => setIntensity(v[0])} min={1} max={10} step={1} />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>Schwach</span>
              <span>Stark</span>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Abbrechen
            </Button>
            <Button type="submit" disabled={!character1 || !character2 || character1 === character2}>
              {isEditing ? "Speichern" : "Erstellen"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
