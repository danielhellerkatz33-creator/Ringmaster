"use client"

import { useEffect, useState } from "react"
import { useSearchParams } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle, ArrowRight, Crown } from "lucide-react"
import { useAuth } from "@/lib/auth-context"

export default function SuccessPage() {
  const searchParams = useSearchParams()
  const sessionId = searchParams.get("session_id")
  const { user, refreshUser } = useAuth()
  const [isProcessing, setIsProcessing] = useState(true)

  useEffect(() => {
    const processPayment = async () => {
      if (sessionId && user) {
        try {
          // In production, the webhook would have already updated the user's pro status
          // But we'll refresh to make sure we have the latest data
          console.log("Payment successful for session:", sessionId)
          
          // Refresh user data to get pro status (updated by webhook)
          await refreshUser()
          
          // Give webhook a moment to process
          setTimeout(() => {
            refreshUser()
            setIsProcessing(false)
          }, 2000)
        } catch (error) {
          console.error("Error processing payment:", error)
          setIsProcessing(false)
        }
      } else {
        setIsProcessing(false)
      }
    }

    processPayment()
  }, [sessionId, user, refreshUser])

  if (isProcessing) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-green-50 to-emerald-100 dark:from-green-900/20 dark:to-emerald-900/20 p-4">
      <div className="w-full max-w-md">
        <Card>
          <CardHeader className="text-center">
            <div className="mx-auto mb-4 w-16 h-16 bg-green-100 dark:bg-green-900/20 rounded-full flex items-center justify-center">
              <CheckCircle className="h-8 w-8 text-green-600 dark:text-green-400" />
            </div>
            <CardTitle className="text-2xl text-green-600 dark:text-green-400">
              Payment Successful!
            </CardTitle>
            <CardDescription>
              Welcome to Ringmaster Pro! Your account has been upgraded.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-4 border border-green-200 dark:border-green-800">
              <div className="flex items-center gap-2 text-green-700 dark:text-green-300">
                <Crown className="h-5 w-5" />
                <span className="font-medium">Pro Features Unlocked</span>
              </div>
              <ul className="mt-2 space-y-1 text-sm text-green-600 dark:text-green-400">
                <li>• Unlimited wrestlers</li>
                <li>• Unlimited storylines</li>
                <li>• Unlimited segments</li>
                <li>• All future pro features</li>
              </ul>
            </div>

            <div className="space-y-2">
              <Link href="/">
                <Button className="w-full">
                  Continue to Ringmaster
                  <ArrowRight className="h-4 w-4 ml-2" />
                </Button>
              </Link>
              <Link href="/account">
                <Button variant="outline" className="w-full">
                  View Account
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
