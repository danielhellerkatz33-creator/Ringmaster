"use client"

import { useRouter } from "next/navigation"
import { SavegamePanel } from "@/components/savegame-panel"
import { PageHeader } from "@/components/page-header"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"

export default function LoadGamePage() {
  const router = useRouter()

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4">
      <div className="max-w-2xl mx-auto space-y-6">
        {/* Header mit Zurück-Button */}
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => router.push('/main-menu')}
            className="text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Zurück zum Hauptmenü
          </Button>
        </div>

        {/* Savegame Panel */}
        <div className="bg-card rounded-lg border border-border p-6 shadow-2xl">
          <PageHeader
            title="Save Game laden"
            description="Wähle ein gespeichertes Spiel aus, um fortzufahren"
          />

          <div className="mt-6">
            <SavegamePanel />
          </div>
        </div>
      </div>
    </div>
  )
}