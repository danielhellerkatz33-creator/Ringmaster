import { NextRequest, NextResponse } from 'next/server'
import { indexedDBStorage } from '@/lib/indexeddb-storage'

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    console.log('API Route called with params:', params)
    
    const blobId = params.id
    
    if (!blobId) {
      console.error('No blob ID provided')
      return NextResponse.json({ error: 'Blob ID is required' }, { status: 400 })
    }

    console.log('Attempting to get blob with ID:', blobId)

    // Initialize IndexedDB first
    await indexedDBStorage.init()
    
    // Get the blob from IndexedDB
    const blob = await indexedDBStorage.getBlob(blobId)
    
    if (!blob) {
      console.error('Blob not found for ID:', blobId)
      return NextResponse.json({ error: 'Blob not found' }, { status: 404 })
    }

    console.log('Blob found, type:', blob.type, 'size:', blob.size)

    // Convert blob to ArrayBuffer
    const arrayBuffer = await blob.arrayBuffer()
    const buffer = Buffer.from(arrayBuffer)

    // Determine content type
    const contentType = blob.type || 'image/jpeg'

    console.log('Returning image with content type:', contentType)

    // Return the image with proper headers
    return new NextResponse(buffer, {
      headers: {
        'Content-Type': contentType,
        'Cache-Control': 'public, max-age=31536000', // Cache for 1 year
        'Content-Length': buffer.length.toString(),
      },
    })
  } catch (error) {
    console.error('Error serving blob:', error)
    return NextResponse.json({ error: 'Internal server error', details: error.message }, { status: 500 })
  }
}
