import { NextRequest, NextResponse } from 'next/server'
import Stripe from 'stripe'
import { supabase } from '@/lib/supabase'
import { headers } from 'next/headers'

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!)

// Webhook event types we handle
const handledEventTypes = [
  'checkout.session.completed',
  'checkout.session.async_payment_succeeded',
  'checkout.session.async_payment_failed',
  'payment_intent.succeeded',
  'payment_intent.payment_failed',
]

// Helper function to log webhook events
async function logWebhookEvent(eventType: string, processed: boolean, error?: string) {
  if (!supabase) return

  try {
    await supabase
      .from('stripe_events')
      .insert({
        id: crypto.randomUUID(),
        type: eventType,
        processed,
      })
  } catch (err) {
    console.error('Failed to log webhook event:', err)
  }
}

// Helper function to update user pro status
async function updateUserProStatus(userId: string, isPro: boolean) {
  if (!supabase) return

  try {
    const { error } = await supabase
      .from('users')
      .update({ is_pro: isPro })
      .eq('id', userId)

    if (error) {
      console.error('Failed to update user pro status:', error)
      throw error
    }

    console.log(`User ${userId} pro status updated to: ${isPro}`)
  } catch (err) {
    console.error('Error updating user pro status:', err)
    throw err
  }
}

export async function POST(request: NextRequest) {
  const body = await request.text()
  const headersList = await headers()
  const signature = headersList.get('stripe-signature')

  if (!signature) {
    console.error('No Stripe signature found')
    return NextResponse.json({ error: 'No signature' }, { status: 400 })
  }

  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET
  if (!webhookSecret) {
    console.error('No webhook secret configured')
    return NextResponse.json({ error: 'Webhook secret not configured' }, { status: 500 })
  }

  let event: Stripe.Event

  try {
    // Verify webhook signature
    event = stripe.webhooks.constructEvent(body, signature, webhookSecret)
  } catch (err) {
    console.error('Webhook signature verification failed:', err)
    return NextResponse.json({ error: 'Invalid signature' }, { status: 400 })
  }

  // Only process events we care about
  if (!handledEventTypes.includes(event.type)) {
    console.log(`Unhandled event type: ${event.type}`)
    return NextResponse.json({ received: true })
  }

  console.log(`Processing webhook event: ${event.type}`)

  try {
    switch (event.type) {
      case 'checkout.session.completed':
      case 'checkout.session.async_payment_succeeded':
      case 'payment_intent.succeeded':
        const session = event.data.object as Stripe.Checkout.Session
        
        // Get user ID from metadata
        const userId = session.metadata?.userId
        if (!userId) {
          console.error('No user ID in session metadata')
          await logWebhookEvent(event.type, false, 'No user ID in metadata')
          return NextResponse.json({ error: 'No user ID' }, { status: 400 })
        }

        // Check if this is a successful payment for our product
        if (session.payment_status === 'paid' || session.status === 'complete') {
          await updateUserProStatus(userId, true)
          await logWebhookEvent(event.type, true)
          console.log(`Payment successful for user ${userId}`)
        }
        break

      case 'checkout.session.async_payment_failed':
      case 'payment_intent.payment_failed':
        const failedSession = event.data.object as Stripe.Checkout.Session
        const failedUserId = failedSession.metadata?.userId
        
        if (failedUserId) {
          console.log(`Payment failed for user ${failedUserId}`)
          await logWebhookEvent(event.type, true, 'Payment failed')
        }
        break

      default:
        console.log(`Unhandled event type: ${event.type}`)
        await logWebhookEvent(event.type, false, 'Unhandled event type')
    }

    return NextResponse.json({ received: true })
  } catch (error) {
    console.error(`Error processing webhook ${event.type}:`, error)
    await logWebhookEvent(event.type, false, error instanceof Error ? error.message : 'Unknown error')
    return NextResponse.json({ error: 'Webhook processing failed' }, { status: 500 })
  }
}
