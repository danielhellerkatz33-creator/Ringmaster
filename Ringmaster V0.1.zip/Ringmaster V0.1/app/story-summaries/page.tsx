"use client"

import { useState, useMemo } from "react"
import { useSeries } from "@/lib/series-context"
import { PageHeader } from "@/components/page-header"
import { EmptyState } from "@/components/empty-state"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { BookOpen, Search, Filter, BarChart3 } from "lucide-react"
import type { Storyline, Character, Segment } from "@/lib/types"
import { StorySummaryCard } from "@/components/story-summary-card"

type StoryType = "all" | Storyline["type"]
type CompletionStatus = "all" | "complete" | "partial" | "empty"

export default function StorySummariesPage() {
  const { data, isLoading } = useSeries()
  const [searchTerm, setSearchTerm] = useState("")
  const [typeFilter, setTypeFilter] = useState<StoryType>("all")
  const [completionFilter, setCompletionFilter] = useState<CompletionStatus>("all")

  // Nur abgeschlossene Storylines filtern und mit zusätzlichen Daten anreichern
  // Diese Hooks müssen immer aufgerufen werden (vor allen early returns)
  const completedStorylines = useMemo(() => {
    if (!data) return []

    return data.storylines
      .filter((s) => s.status === "completed")
      .map((storyline) => {
        const characters = data.characters.filter((c) => storyline.characterIds.includes(c.id))
        const segments = data.segments.filter((s) => s.storylineId === storyline.id)
        const hasSummary = !!storyline.summary
        const hasCharacterReview = !!storyline.characterReview

        let completionStatus: CompletionStatus
        if (hasSummary && hasCharacterReview) completionStatus = "complete"
        else if (hasSummary || hasCharacterReview) completionStatus = "partial"
        else completionStatus = "empty"

        return {
          ...storyline,
          characters,
          segments,
          completionStatus
        }
      })
      .filter((storyline) => {
        // Suchfilter
        if (searchTerm) {
          const searchLower = searchTerm.toLowerCase()
          const matchesTitle = storyline.title.toLowerCase().includes(searchLower)
          const matchesDescription = storyline.description?.toLowerCase().includes(searchLower)
          if (!matchesTitle && !matchesDescription) return false
        }

        // Typ-Filter
        if (typeFilter !== "all" && storyline.type !== typeFilter) return false

        // Vollständigkeits-Filter
        if (completionFilter !== "all" && storyline.completionStatus !== completionFilter) return false

        return true
      })
      .sort((a, b) => {
        // Sortierung: zuerst nach Typ, dann nach Titel
        const typeOrder = { main: 0, subplot: 1, arc: 2 }
        const typeDiff = typeOrder[a.type] - typeOrder[b.type]
        if (typeDiff !== 0) return typeDiff
        return a.title.localeCompare(b.title)
      })
  }, [data, searchTerm, typeFilter, completionFilter])

  // Statistiken berechnen
  const stats = useMemo(() => {
    const total = completedStorylines.length
    const complete = completedStorylines.filter(s => s.completionStatus === "complete").length
    const partial = completedStorylines.filter(s => s.completionStatus === "partial").length
    const empty = completedStorylines.filter(s => s.completionStatus === "empty").length

    return { total, complete, partial, empty }
  }, [completedStorylines])

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-pulse text-muted-foreground">Lädt Storyzusammenfassungen...</div>
      </div>
    )
  }

  if (!data || data.storylines.filter((s) => s.status === "completed").length === 0) {
    return (
      <EmptyState
        icon={BookOpen}
        title="Keine abgeschlossenen Storylines"
        description="Schließen Sie zuerst Storylines ab, um hier Zusammenfassungen zu erstellen."
      />
    )
  }

  return (
    <>
      <PageHeader
        title="Storyzusammenfassungen"
        description="Übersicht aller abgeschlossenen Stories mit Zusammenfassungen und Charakteranalysen"
      />

      {/* Statistiken */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <div className="bg-card rounded-lg p-4 border">
          <div className="flex items-center gap-2 mb-1">
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm font-medium">Gesamt</span>
          </div>
          <p className="text-2xl font-bold">{stats.total}</p>
        </div>
        <div className="bg-card rounded-lg p-4 border">
          <div className="flex items-center gap-2 mb-1">
            <div className="h-3 w-3 rounded-full bg-green-500"></div>
            <span className="text-sm font-medium">Vollständig</span>
          </div>
          <p className="text-2xl font-bold text-green-600">{stats.complete}</p>
        </div>
        <div className="bg-card rounded-lg p-4 border">
          <div className="flex items-center gap-2 mb-1">
            <div className="h-3 w-3 rounded-full bg-yellow-500"></div>
            <span className="text-sm font-medium">Teilweise</span>
          </div>
          <p className="text-2xl font-bold text-yellow-600">{stats.partial}</p>
        </div>
        <div className="bg-card rounded-lg p-4 border">
          <div className="flex items-center gap-2 mb-1">
            <div className="h-3 w-3 rounded-full bg-red-500"></div>
            <span className="text-sm font-medium">Leer</span>
          </div>
          <p className="text-2xl font-bold text-red-600">{stats.empty}</p>
        </div>
      </div>

      {/* Filter und Suche */}
      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <div className="flex-1">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Nach Titel oder Beschreibung suchen..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>
        <Select value={typeFilter} onValueChange={(value) => setTypeFilter(value as StoryType)}>
          <SelectTrigger className="w-full sm:w-48">
            <Filter className="h-4 w-4 mr-2" />
            <SelectValue placeholder="Typ filtern" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Alle Typen</SelectItem>
            <SelectItem value="main">Haupthandlung</SelectItem>
            <SelectItem value="subplot">Nebenhandlung</SelectItem>
            <SelectItem value="arc">Story Arc</SelectItem>
          </SelectContent>
        </Select>
        <Select value={completionFilter} onValueChange={(value) => setCompletionFilter(value as CompletionStatus)}>
          <SelectTrigger className="w-full sm:w-48">
            <SelectValue placeholder="Status filtern" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Alle Status</SelectItem>
            <SelectItem value="complete">Vollständig</SelectItem>
            <SelectItem value="partial">Teilweise</SelectItem>
            <SelectItem value="empty">Leer</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Story Grid */}
      {completedStorylines.length === 0 ? (
        <div className="text-center py-12">
          <BookOpen className="h-12 w-12 mx-auto mb-4 text-muted-foreground opacity-50" />
          <h3 className="text-lg font-medium mb-2">Keine Stories gefunden</h3>
          <p className="text-muted-foreground">
            Keine Stories entsprechen den aktuellen Filterkriterien.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {completedStorylines.map((storyline) => (
            <StorySummaryCard
              key={storyline.id}
              storyline={storyline}
              characters={storyline.characters}
              scenes={storyline.segments}
            />
          ))}
        </div>
      )}
    </>
  )
}