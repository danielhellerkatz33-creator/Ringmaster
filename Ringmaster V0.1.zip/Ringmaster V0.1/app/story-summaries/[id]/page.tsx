"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { useSeries } from "@/lib/series-context"
import { PageHeader } from "@/components/page-header"
import { EmptyState } from "@/components/empty-state"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { FileText, Edit, Save, X, BookOpen, AlertCircle, Users, ScrollText, ArrowLeft } from "lucide-react"
import type { Storyline, Character } from "@/lib/types"
import { CharacterAvatar } from "@/components/character-avatar"

const typeLabels: Record<Storyline["type"], string> = {
  main: "Haupthandlung",
  subplot: "Nebenhandlung",
  arc: "Story Arc",
}

const getRoleLabel = (role: string) => {
  switch (role) {
    case "protagonist":
      return "Protagonist"
    case "antagonist":
      return "Antagonist"
    case "supporting":
      return "Nebenfigur"
    case "recurring":
      return "Wiederkehrend"
    case "guest":
      return "Gast"
    default:
      return role
  }
}

interface CharacterSummarySection {
  character: Character | null
  characterName: string
  content: string
  hasValidCharacter: boolean
}

const parseCharacterSummaries = (summary: string, characters: Character[]): CharacterSummarySection[] => {
  const sections: CharacterSummarySection[] = []

  // Finde alle Charakter-Absätze mit Regex
  // Pattern: Name: Inhalt (bis zum nächsten Name: oder Ende)
  // Unterstützt Namen wie "Vera Richter", "Peter Becker" oder "A.R. Daniel"
  const pattern = /([A-ZÄÖÜ][A-Za-zäöüÄÖÜß.]*(?:\s+[A-ZÄÖÜ][A-Za-zäöüÄÖÜß.]+)*):\s*([^]*?)(?=\n\n[A-ZÄÖÜ][A-Za-zäöüÄÖÜß.]*(?:\s+[A-ZÄÖÜ][A-Za-zäöüÄÖÜß.]+)*:|$(?![\r\n]))/g

  let match
  while ((match = pattern.exec(summary)) !== null) {
    const characterName = match[1].trim()
    const content = match[2].trim()

    // Finde passenden Charakter
    const character = characters.find(c => c.name === characterName)

    sections.push({
      character,
      characterName,
      content,
      hasValidCharacter: !!character
    })
  }

  return sections
}

export default function StorySummaryDetailPage() {
  const params = useParams()
  const router = useRouter()
  const { data, isLoading, updateStoryline } = useSeries()
  const [editingSection, setEditingSection] = useState<string | null>(null)
  const [characterReviewText, setCharacterReviewText] = useState("")
  const [summaryText, setSummaryText] = useState("")
  const [savingData, setSavingData] = useState(false)

  const storylineId = params.id as string

  // Finde die Storyline
  const storyline = data.storylines.find(s => s.id === storylineId)

  // Redirect wenn Story nicht gefunden oder nicht completed
  useEffect(() => {
    if (!isLoading && (!storyline || storyline.status !== "completed")) {
      router.push("/story-summaries")
    }
  }, [storyline, isLoading, router])

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-pulse text-muted-foreground">Lädt Storyzusammenfassung...</div>
      </div>
    )
  }

  if (!storyline || storyline.status !== "completed") {
    return (
      <EmptyState
        icon={BookOpen}
        title="Story nicht gefunden"
        description="Die angeforderte Story wurde nicht gefunden oder ist noch nicht abgeschlossen."
      />
    )
  }

  const characters = data.characters
    .filter((c) => storyline.characterIds.includes(c.id))
    .sort((a, b) => a.name.localeCompare(b.name))
  const segments = data.segments.filter((s) => s.storylineId === storyline.id)

  const handleEditSection = (section: 'characterReview' | 'summary') => {
    setEditingSection(`${storyline.id}-${section}`)
    if (section === 'characterReview') {
      setCharacterReviewText(storyline.characterReview || "")
    } else {
      setSummaryText(storyline.summary || "")
    }
  }

  const handleSaveSection = async (section: 'characterReview' | 'summary') => {
    setSavingData(true)
    try {
      const updates: Partial<Storyline> = {}
      if (section === 'characterReview') {
        updates.characterReview = characterReviewText.trim() || undefined
      } else {
        updates.summary = summaryText.trim() || undefined
      }

      await updateStoryline({
        ...storyline,
        ...updates
      })

      setEditingSection(null)
      setCharacterReviewText("")
      setSummaryText("")
    } catch (error) {
      console.error("Failed to save data:", error)
    } finally {
      setSavingData(false)
    }
  }

  const handleCancelEdit = () => {
    setEditingSection(null)
    setCharacterReviewText("")
    setSummaryText("")
  }

  return (
    <>
      <div className="flex items-center gap-4 mb-6">
        <Button
          variant="outline"
          size="sm"
          onClick={() => router.push("/story-summaries")}
          className="gap-2"
        >
          <ArrowLeft className="h-4 w-4" />
          Zur Übersicht
        </Button>
        <div className="flex-1">
          <PageHeader
            title={`Storyzusammenfassung: ${storyline.title}`}
            description="Dokumentieren Sie Zusammenfassungen für diese Storyline"
          />
        </div>
      </div>

      <Card className="bg-card">
        <CardHeader className="pb-4">
          <div className="flex items-start justify-between">
            <div className="flex items-start gap-3">
              <div
                className="h-4 w-4 rounded-full mt-1 shrink-0"
                style={{ backgroundColor: storyline.color }}
              />
              <div>
                <h3 className="font-semibold text-foreground leading-tight">{storyline.title}</h3>
                <Badge variant="outline" className="mt-1 text-xs capitalize">
                  {typeLabels[storyline.type]}
                </Badge>
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent className="pt-0">
          {storyline.description && (
            <p className="text-sm text-muted-foreground mb-4">{storyline.description}</p>
          )}

          <div className="flex items-center justify-between text-xs text-muted-foreground mb-4">
            <span>{characters.length} Charaktere</span>
            <span>{segments.length} Segmente</span>
          </div>

          {characters.length > 0 && (
            <div className="flex -space-x-2 mb-4">
              {characters.slice(0, 4).map((char) => (
                <CharacterAvatar
                  key={char.id}
                  name={char.name}
                  imageUrl={char.imageUrl}
                  size="sm"
                  className="border-2 border-card"
                />
              ))}
              {characters.length > 4 && (
                <div className="h-7 w-7 rounded-full bg-muted border-2 border-card flex items-center justify-center">
                  <span className="text-xs">+{characters.length - 4}</span>
                </div>
              )}
            </div>
          )}

          <div className="border-t pt-4">
            <Tabs defaultValue="character-review" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="character-review" className="flex items-center gap-2">
                  <Users className="h-4 w-4" />
                  Charakterrückblick
                </TabsTrigger>
                <TabsTrigger value="summary" className="flex items-center gap-2">
                  <ScrollText className="h-4 w-4" />
                  Zusammenfassung
                </TabsTrigger>
              </TabsList>

              <TabsContent value="character-review" className="mt-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Users className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm font-medium">Charakterrückblick</span>
                  </div>
                  {!storyline.characterReview && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleEditSection('characterReview')}
                      className="gap-2"
                    >
                      <Edit className="h-4 w-4" />
                      Hinzufügen
                    </Button>
                  )}
                </div>

                {editingSection === `${storyline.id}-characterReview` ? (
                  <div className="space-y-3">
                    <Textarea
                      value={characterReviewText}
                      onChange={(e) => setCharacterReviewText(e.target.value)}
                      placeholder="Fügen Sie hier die ChatGPT-Charakteranalysen im Format 'Name: Inhalt...' ein..."
                      className="min-h-[200px] resize-none"
                      disabled={savingData}
                    />
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        onClick={() => handleSaveSection('characterReview')}
                        disabled={savingData}
                        className="gap-2"
                      >
                        <Save className="h-4 w-4" />
                        {savingData ? "Speichert..." : "Speichern"}
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={handleCancelEdit}
                        disabled={savingData}
                        className="gap-2"
                      >
                        <X className="h-4 w-4" />
                        Abbrechen
                      </Button>
                    </div>
                  </div>
                ) : storyline.characterReview ? (
                  <div className="space-y-3">
                    <div className="flex justify-end mb-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleEditSection('characterReview')}
                        className="gap-2 text-muted-foreground hover:text-foreground"
                      >
                        <Edit className="h-4 w-4" />
                        Bearbeiten
                      </Button>
                    </div>
                    {parseCharacterSummaries(storyline.characterReview, data.characters).map((section, index) => (
                      <div key={index} className="flex items-start gap-3 p-3 bg-muted/30 rounded-lg border border-muted/50">
                        {/* Charakter-Avatar */}
                        <CharacterAvatar
                          name={section.characterName}
                          imageUrl={section.character?.imageUrl}
                          size="sm"
                          className={`ring-2 flex-shrink-0 ${
                            section.hasValidCharacter
                              ? "ring-primary/30 hover:ring-primary/50"
                              : "ring-muted-foreground/20"
                          }`}
                        />

                        {/* Charakter-Info und Zusammenfassung */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-2">
                            <h4 className="text-sm font-medium text-foreground">
                              {section.characterName}
                            </h4>
                            {section.character && (
                              <Badge variant="outline" className="text-xs">
                                {getRoleLabel(section.character.position)}
                              </Badge>
                            )}
                            {!section.hasValidCharacter && (
                              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                                <AlertCircle className="h-3 w-3" />
                                Charakter nicht gefunden
                              </div>
                            )}
                          </div>
                          <p className="text-sm text-muted-foreground leading-relaxed">
                            {section.content}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    <Users className="h-8 w-8 mx-auto mb-2 opacity-50" />
                    <p className="text-sm">Noch kein Charakterrückblick vorhanden</p>
                    <p className="text-xs mt-1">Klicken Sie auf "Hinzufügen" um strukturierte Charakteranalysen zu erstellen</p>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="summary" className="mt-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <ScrollText className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm font-medium">Zusammenfassung</span>
                  </div>
                  {!storyline.summary && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleEditSection('summary')}
                      className="gap-2"
                    >
                      <Edit className="h-4 w-4" />
                      Hinzufügen
                    </Button>
                  )}
                </div>

                {editingSection === `${storyline.id}-summary` ? (
                  <div className="space-y-3">
                    <Textarea
                      value={summaryText}
                      onChange={(e) => setSummaryText(e.target.value)}
                      placeholder="Fügen Sie hier eine allgemeine Zusammenfassung der Storyline ein..."
                      className="min-h-[120px] resize-none"
                      disabled={savingData}
                    />
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        onClick={() => handleSaveSection('summary')}
                        disabled={savingData}
                        className="gap-2"
                      >
                        <Save className="h-4 w-4" />
                        {savingData ? "Speichert..." : "Speichern"}
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={handleCancelEdit}
                        disabled={savingData}
                        className="gap-2"
                      >
                        <X className="h-4 w-4" />
                        Abbrechen
                      </Button>
                    </div>
                  </div>
                ) : storyline.summary ? (
                  <div className="space-y-3">
                    <div className="flex justify-end mb-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleEditSection('summary')}
                        className="gap-2 text-muted-foreground hover:text-foreground"
                      >
                        <Edit className="h-4 w-4" />
                        Bearbeiten
                      </Button>
                    </div>
                    <div className="bg-muted/50 rounded-md p-4">
                      <p className="text-sm text-muted-foreground whitespace-pre-wrap leading-relaxed">
                        {storyline.summary}
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    <ScrollText className="h-8 w-8 mx-auto mb-2 opacity-50" />
                    <p className="text-sm">Noch keine Zusammenfassung vorhanden</p>
                    <p className="text-xs mt-1">Klicken Sie auf "Hinzufügen" um eine allgemeine Zusammenfassung zu erstellen</p>
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </div>
        </CardContent>
      </Card>
    </>
  )
}