"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useAuth } from "@/lib/auth-context"
import { LogOut, Crown, User } from "lucide-react"
import Link from "next/link"

export default function AccountPage() {
  const { user, isPro, signOut } = useAuth()

  if (!user) {
    return (
      <div className="container max-w-7xl mx-auto p-6 pt-16">
        <div className="max-w-md mx-auto">
          <Card>
            <CardHeader>
              <CardTitle>Nicht eingeloggt</CardTitle>
              <CardDescription>
                Bitte logge dich ein um deinen Account zu sehen.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/auth">
                <Button className="w-full">
                  Zum Login
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="container max-w-7xl mx-auto p-6 pt-16">
      <div className="max-w-md mx-auto">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="h-5 w-5" />
              Dein Account
            </CardTitle>
            <CardDescription>
              Verwalte deinen Ringmaster Account
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                E-Mail
              </label>
              <p className="mt-1 text-sm text-gray-900 dark:text-gray-100">
                {user.email}
              </p>
            </div>
            
            <div>
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                Plan
              </label>
              <div className="mt-1 flex items-center gap-2">
                {isPro ? (
                  <>
                    <Crown className="h-4 w-4 text-yellow-500" />
                    <span className="text-sm font-medium text-yellow-600 dark:text-yellow-400">
                      Pro Plan
                    </span>
                  </>
                ) : (
                  <>
                    <span className="text-sm text-gray-900 dark:text-gray-100">
                      Free Plan
                    </span>
                  </>
                )}
              </div>
            </div>

            <div className="pt-4 border-t border-gray-200 dark:border-gray-700">
              <Button
                variant="outline"
                onClick={() => signOut()}
                className="w-full"
              >
                <LogOut className="h-4 w-4 mr-2" />
                Ausloggen
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
