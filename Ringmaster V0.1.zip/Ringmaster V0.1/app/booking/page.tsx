"use client"

import { useMemo } from "react"
import { useSeries } from "@/lib/series-context"
import { PageHeader } from "@/components/page-header"
import { CharacterAvatar } from "@/components/character-avatar"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Film, Clapperboard, Calendar, TrendingUp, TrendingDown, Minus } from "lucide-react"

interface CharacterBookingStats {
  character: {
    id: string
    name: string
    position: string
    imageUrl?: string
    avatarBlobId?: string
  }
  sceneCount: number
  eventCount: number
  lastEvent: {
    id: string
    title: string
    seasonNumber: number
    eventNumber: number
    airDate?: Date
  } | null
  eventsSinceLastAppearance: number
  screenTimePercentage: number
}

export default function BookingPage() {
  const { data, isLoading } = useSeries()

  // Nur abgeschlossene Episoden berücksichtigen
  const completedEpisodes = useMemo(() => {
    if (!data.episodes || !data.episodes.length) return []
    return data.episodes.filter(episode => episode.status === "completed")
  }, [data.episodes])

  const bookingStats = useMemo(() => {
    if (!completedEpisodes.length) return []

    const stats: CharacterBookingStats[] = [...data.characters]
      .sort((a, b) => a.name.localeCompare(b.name))
      .map((character) => {
      // Finde alle Szenen mit diesem Charakter aus abgeschlossenen Episoden
      const characterScenes = data.segments.filter((scene) => {
        // Prüfen, ob die Szene in einer abgeschlossenen Episode verwendet wird
        return completedEpisodes.some(episode => 
          episode.sceneIds.includes(scene.id) && scene.characterIds.includes(character.id)
        )
      })
      const sceneCount = characterScenes.length

      // Finde alle abgeschlossenen Events mit diesem Charakter
      const characterEvents = completedEpisodes.filter((event) =>
        event.sceneIds && event.sceneIds.some((segmentId: string) => {
          const segment = data.segments.find(s => s.id === segmentId)
          return segment && segment.characterIds.includes(character.id)
        })
      )
      const eventCount = characterEvents.length

      // Finde die letzte abgeschlossene Episode
      const sortedEvents = completedEpisodes
        .filter(e => e.airDate)
        .sort((a, b) => new Date(a.airDate!).getTime() - new Date(b.airDate!).getTime())

      const lastEvent = characterEvents.length > 0 ? characterEvents[characterEvents.length - 1] : null
      const lastEventIndex = sortedEvents.findIndex(e => e.id === lastEvent?.id)
      const totalEvents = sortedEvents.length
      const latestEventIndex = sortedEvents.length - 1

      let eventsSinceLastAppearance = 0
      if (lastEvent && lastEventIndex < latestEventIndex) {
        eventsSinceLastAppearance = sortedEvents.length - lastEventIndex - 1
      } else if (lastEvent) {
        eventsSinceLastAppearance = sortedEvents.length
      }

      // Berechne Screen-Time Prozentsatz
      const screenTimePercentage = totalEvents > 0 ? Math.round((eventCount / totalEvents) * 100) : 0

      return {
        character: {
          id: character.id,
          name: character.name,
          position: character.position,
          imageUrl: character.imageUrl,
          avatarBlobId: character.avatarBlobId,
        },
        sceneCount,
        eventCount,
        lastEvent: lastEvent
          ? {
              id: lastEvent.id,
              title: lastEvent.title,
              seasonNumber: 1, // Standardwert, da Event-Interface keine seasonNumber hat
              eventNumber: lastEvent.eventNumber,
              airDate: lastEvent.airDate
            }
          : null,
        eventsSinceLastAppearance,
        screenTimePercentage,
      }
    })

    // Sortiere nach Episodenanzahl (absteigend)
    return stats.sort((a, b) => b.eventCount - a.eventCount)
  }, [data.characters, data.segments, data.episodes])

  const totalEvents = completedEpisodes?.length || 0
  const totalScenes = data.segments?.filter(segment => 
    completedEpisodes.some(episode => episode.sceneIds.includes(segment.id))
  ).length || 0

  const getRoleBadgeVariant = (role: string) => {
    switch (role) {
      case "protagonist":
        return "default"
      case "antagonist":
        return "destructive"
      case "supporting":
        return "secondary"
      case "recurring":
        return "outline"
      default:
        return "outline"
    }
  }

  const getRoleLabel = (role: string) => {
    switch (role) {
      case "protagonist":
        return "Protagonist"
      case "antagonist":
        return "Antagonist"
      case "supporting":
        return "Nebenfigur"
      case "recurring":
        return "Wiederkehrend"
      case "guest":
        return "Gast"
      default:
        return role
    }
  }

  const getActivityIcon = (episodesSince: number) => {
    if (episodesSince === 0) {
      return <TrendingUp className="h-4 w-4 text-green-500" />
    } else if (episodesSince <= 2) {
      return <Minus className="h-4 w-4 text-yellow-500" />
    } else {
      return <TrendingDown className="h-4 w-4 text-red-500" />
    }
  }

  if (isLoading) {
    return (
      <div className="animate-pulse space-y-4">
        <div className="h-8 bg-muted rounded w-1/4" />
        <div className="h-64 bg-muted rounded" />
      </div>
    )
  }

  return (
    <div className="space-y-8">
      <PageHeader title="Booking Plan" description="Übersicht über Charakter-Auftritte und Screen-Time" />

      {/* Zusammenfassung */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Charaktere</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.characters?.length || 0}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Events</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalEvents}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Szenen</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalScenes}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Ø Szenen/Charakter</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {(data.characters?.length || 0) > 0
                ? Math.round(bookingStats.reduce((sum, s) => sum + s.sceneCount, 0) / (data.characters?.length || 1))
                : 0}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Booking-Tabelle */}
      <Card>
        <CardHeader>
          <CardTitle>Charakter-Auftritte</CardTitle>
        </CardHeader>
        <CardContent>
          {bookingStats.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">Noch keine Charaktere oder Szenen vorhanden.</div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[250px]">Charakter</TableHead>
                  <TableHead className="text-center">Rolle</TableHead>
                  <TableHead className="text-center">
                    <div className="flex items-center justify-center gap-1">
                      <Film className="h-4 w-4" />
                      Episoden
                    </div>
                  </TableHead>
                  <TableHead className="text-center">
                    <div className="flex items-center justify-center gap-1">
                      <Clapperboard className="h-4 w-4" />
                      Szenen
                    </div>
                  </TableHead>
                  <TableHead className="w-[200px]">Screen-Time</TableHead>
                  <TableHead>Letzter Auftritt</TableHead>
                  <TableHead className="text-center">Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {bookingStats.map((stat) => (
                  <TableRow key={stat.character.id}>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <CharacterAvatar name={stat.character.name} imageUrl={stat.character.imageUrl} character={stat.character as any} size="sm" />
                        <span className="font-medium">{stat.character.name}</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-center">
                      <Badge variant={getRoleBadgeVariant(stat.character.position)}>
                        {getRoleLabel(stat.character.position)}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-center font-medium">{stat.eventCount}</TableCell>
                    <TableCell className="text-center font-medium">{stat.sceneCount}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Progress value={stat.screenTimePercentage} className="h-2 flex-1" />
                        <span className="text-sm text-muted-foreground w-10">{stat.screenTimePercentage}%</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      {stat.lastEvent ? (
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm">
                            S{stat.lastEvent.seasonNumber}E{stat.lastEvent.eventNumber}
                            <span className="text-muted-foreground ml-1">({stat.lastEvent.title})</span>
                          </span>
                        </div>
                      ) : (
                        <span className="text-muted-foreground text-sm">Noch kein Auftritt</span>
                      )}
                    </TableCell>
                    <TableCell className="text-center">
                      <div className="flex items-center justify-center gap-1">
                        {getActivityIcon(stat.eventsSinceLastAppearance)}
                        <span className="text-sm text-muted-foreground">
                          {stat.eventsSinceLastAppearance === 0
                            ? "Aktuell"
                            : `${stat.eventsSinceLastAppearance} Events`}
                        </span>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
