"use client"

import { useState } from "react"
import { useSeries } from "@/lib/series-context"
import { PageHeader } from "@/components/page-header"
import { EmptyState } from "@/components/empty-state"
import { RelationshipForm } from "@/components/relationship-form"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Plus, Heart, MoreVertical, Pencil, Trash2, ArrowRight, Grid, List, Circle, Layout, Users, Shield, Crown, Sword, Handshake } from "lucide-react"
import type { Relationship } from "@/lib/types"
import { CharacterAvatar } from "@/components/character-avatar"
import { RelationshipsCardsView } from "@/components/relationships-cards-view"
import { RelationshipsListView } from "@/components/relationships-list-view"
import { RelationshipsRadialView } from "@/components/relationships-radial-view"


const viewOptions = [
  { value: 'cards', label: 'Kartenansicht', icon: Grid },
  { value: 'list', label: 'Listenansicht', icon: List },
  { value: 'radial', label: 'Radiale Ansicht', icon: Circle }
]

export default function RelationshipsPage() {
  const { data, isLoading, deleteRelationship } = useSeries()
  const [showForm, setShowForm] = useState(false)
  const [editingRelationship, setEditingRelationship] = useState<Relationship | undefined>()
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null)
  const [viewMode, setViewMode] = useState<'cards' | 'list' | 'radial'>('cards')
  const [activeTab, setActiveTab] = useState<'teams' | 'stables' | 'managers' | 'rivalries' | 'friendships'>('teams')

  const currentViewOption = viewOptions.find(option => option.value === viewMode)

  // Filter relationships by type
  const tagTeams = data.relationships.filter(r => r.type === 'tag_team')
  const stables = data.relationships.filter(r => r.type === 'stable')
  const managers = data.relationships.filter(r => r.type === 'manager')
  const rivalries = data.relationships.filter(r => r.type === 'rivalry')
  const friendships = data.relationships.filter(r => r.type === 'friendship')

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-pulse text-muted-foreground">Lädt Beziehungen...</div>
      </div>
    )
  }

  const handleEdit = (relationship: Relationship) => {
    setEditingRelationship(relationship)
    setShowForm(true)
  }

  const handleDelete = (id: string) => {
    deleteRelationship(id)
    setDeleteConfirm(null)
  }

  const handleFormClose = (open: boolean) => {
    setShowForm(open)
    if (!open) setEditingRelationship(undefined)
  }

  const renderRelationshipsContent = (relationships: Relationship[], emptyTitle: string, emptyDescription: string) => {
    if (relationships.length === 0) {
      return (
        <EmptyState
          icon={Heart}
          title={emptyTitle}
          description={emptyDescription}
          actionLabel={data.characters.length >= 2 ? "Erste Beziehung erstellen" : undefined}
          onAction={data.characters.length >= 2 ? () => setShowForm(true) : undefined}
        />
      )
    }

    return (
      <>
        {viewMode === 'cards' && (
          <RelationshipsCardsView
            relationships={relationships}
            characters={data.characters}
            onEdit={handleEdit}
            onDelete={(id) => setDeleteConfirm(id)}
          />
        )}
        {viewMode === 'list' && (
          <RelationshipsListView
            relationships={relationships}
            characters={data.characters}
            onEdit={handleEdit}
            onDelete={(id) => setDeleteConfirm(id)}
          />
        )}
        {viewMode === 'radial' && (
          <RelationshipsRadialView
            relationships={relationships}
            characters={data.characters}
            onEdit={handleEdit}
            onDelete={(id) => setDeleteConfirm(id)}
            onFocusCharacter={(characterId) => {
              console.log('Focus on character:', characterId)
            }}
          />
        )}
      </>
    )
  }


  return (
    <>
      <PageHeader
        title="Beziehungen"
        description="Verwalte Tag Teams, Stables, Manager, Rivalitäten und Freundschaften"
        action={
          <div className="flex items-center gap-2">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="gap-2">
                  {currentViewOption?.icon && <currentViewOption.icon className="h-4 w-4" />}
                  {currentViewOption?.label}
                  <Layout className="h-4 w-4 ml-1" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {viewOptions.map((option) => (
                  <DropdownMenuItem
                    key={option.value}
                    onClick={() => setViewMode(option.value as typeof viewMode)}
                    className="gap-2"
                  >
                    <option.icon className="h-4 w-4" />
                    {option.label}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            {data.characters.length >= 2 && (
              <Button onClick={() => setShowForm(true)} className="gap-2">
                <Plus className="h-4 w-4" />
                Neue Beziehung
              </Button>
            )}
          </div>
        }
      />

      {data.characters.length < 2 ? (
        <EmptyState
          icon={Heart}
          title="Zu wenige Charaktere"
          description="Erstelle mindestens zwei Charaktere, um Beziehungen zwischen ihnen zu definieren."
        />
      ) : (
        <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as typeof activeTab)} className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="teams" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              Tag Teams
              {tagTeams.length > 0 && (
                <Badge variant="secondary" className="ml-1 text-xs">
                  {tagTeams.length}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="stables" className="flex items-center gap-2">
              <Shield className="h-4 w-4" />
              Stables
              {stables.length > 0 && (
                <Badge variant="secondary" className="ml-1 text-xs">
                  {stables.length}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="managers" className="flex items-center gap-2">
              <Crown className="h-4 w-4" />
              Manager
              {managers.length > 0 && (
                <Badge variant="secondary" className="ml-1 text-xs">
                  {managers.length}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="rivalries" className="flex items-center gap-2">
              <Sword className="h-4 w-4" />
              Rivalitäten
              {rivalries.length > 0 && (
                <Badge variant="secondary" className="ml-1 text-xs">
                  {rivalries.length}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="friendships" className="flex items-center gap-2">
              <Handshake className="h-4 w-4" />
              Freundschaften
              {friendships.length > 0 && (
                <Badge variant="secondary" className="ml-1 text-xs">
                  {friendships.length}
                </Badge>
              )}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="teams" className="space-y-4">
            {renderRelationshipsContent(
              tagTeams,
              "Keine Tag Teams",
              "Erstelle Tag Teams um deine Wrestler zu organisieren."
            )}
          </TabsContent>

          <TabsContent value="stables" className="space-y-4">
            {renderRelationshipsContent(
              stables,
              "Keine Stables",
              "Erstelle Stables um größere Allianzen zu bilden."
            )}
          </TabsContent>

          <TabsContent value="managers" className="space-y-4">
            {renderRelationshipsContent(
              managers,
              "Keine Manager",
              "Weise Wrestlern Manager zu für Storyline-Unterstützung."
            )}
          </TabsContent>

          <TabsContent value="rivalries" className="space-y-4">
            {renderRelationshipsContent(
              rivalries,
              "Keine Rivalitäten",
              "Erstelle Rivalitäten für spannende Storylines und Fehden."
            )}
          </TabsContent>

          <TabsContent value="friendships" className="space-y-4">
            {renderRelationshipsContent(
              friendships,
              "Keine Freundschaften",
              "Erstelle Freundschaften für Allianzen und unterstützende Beziehungen."
            )}
          </TabsContent>
        </Tabs>
      )}

      <RelationshipForm open={showForm} onOpenChange={handleFormClose} relationship={editingRelationship} />

      <AlertDialog open={!!deleteConfirm} onOpenChange={(open) => !open && setDeleteConfirm(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Beziehung löschen?</AlertDialogTitle>
            <AlertDialogDescription>
              Diese Aktion kann nicht rückgängig gemacht werden. Die Charaktere bleiben erhalten.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Abbrechen</AlertDialogCancel>
            <AlertDialogAction onClick={() => deleteConfirm && handleDelete(deleteConfirm)}>Löschen</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}
