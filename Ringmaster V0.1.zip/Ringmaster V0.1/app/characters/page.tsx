"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useSeries } from "@/lib/series-context"
import { PageHeader } from "@/components/page-header"
import { EmptyState } from "@/components/empty-state"
import { CharacterForm } from "@/components/character-form"
import { CharacterCard } from "@/components/character-card"
import { CharacterDetail } from "@/components/character-detail"
import { CharacterDashboard } from "@/components/character-dashboard"
import { UpgradeModal } from "@/components/upgrade-modal"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Plus, Users, Search, LayoutGrid, BarChart3, Settings } from "lucide-react"
import { useLanguage } from "@/lib/i18n/language-context"
import { canCreateWrestler, getCurrentPlan, PLANS } from "@/lib/plans"
import { useAuth } from "@/lib/auth-context"

import type { Character } from "@/lib/types"
export default function CharactersPage() {
  const { data, isLoading, deleteCharacter } = useSeries()
  const { user, isPro } = useAuth()
  const router = useRouter()
  const { t } = useLanguage()
  const [showForm, setShowForm] = useState(false)
  const [editingCharacter, setEditingCharacter] = useState<Character | undefined>()
  const [viewingCharacter, setViewingCharacter] = useState<Character | undefined>()
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null)
  const [search, setSearch] = useState("")
  const [roleFilter, setRoleFilter] = useState<string>("all")
  const [viewMode, setViewMode] = useState<"grid" | "dashboard">("dashboard")
  const [characterViewMode, setCharacterViewMode] = useState<"modal" | "full">("full")
  const [showUpgradeModal, setShowUpgradeModal] = useState(false)

  // Check limits with user status
  const currentPlan = getCurrentPlan(isPro)
  const canCreate = canCreateWrestler(data.characters.length, isPro)
  const isAtLimit = !canCreate && data.characters.length > 0

  // Load character view mode preference
  useEffect(() => {
    const preference = localStorage.getItem('character-view-mode')
    setCharacterViewMode(preference === 'modal' ? 'modal' : 'full')
  }, [])

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-pulse text-muted-foreground">Lädt Charaktere...</div>
      </div>
    )
  }

  const filteredCharacters = data.characters
    .filter((char) => {
      const matchesSearch = char.name.toLowerCase().includes(search.toLowerCase())
      const matchesRole = roleFilter === "all" || char.position === roleFilter
      return matchesSearch && matchesRole
    })
    .sort((a, b) => a.name.localeCompare(b.name))

  const getRelationshipCount = (characterId: string) => {
    return data.relationships.filter((r) => {
      // Handle both old and new data structure
      const characterIds = r.characterIds || 
        ((r as any).characterId1 && (r as any).characterId2 ? 
          [(r as any).characterId1, (r as any).characterId2] : [])
      return characterIds.includes(characterId)
    }).length
  }

  const handleEdit = (character: Character) => {
    setEditingCharacter(character)
    setShowForm(true)
  }

  const handleDelete = (id: string) => {
    deleteCharacter(id)
    setDeleteConfirm(null)
  }

  const handleFormClose = (open: boolean) => {
    setShowForm(open)
    if (!open) setEditingCharacter(undefined)
  }

  const handleCreateCharacter = () => {
    if (canCreate) {
      setShowForm(true)
    } else {
      setShowUpgradeModal(true)
    }
  }

  const handleViewCharacter = (character: Character) => {
    if (characterViewMode === 'full') {
      router.push(`/characters/${character.id}`)
    } else {
      setViewingCharacter(character)
    }
  }

  return (
    <>
      <PageHeader
        title={t.characters.formTitle}
        description={
          `Wrestler: ${data.characters.length}/${currentPlan.limits.maxWrestlers === Infinity ? '∞' : currentPlan.limits.maxWrestlers}`
        }
        action={
          <Button 
            onClick={handleCreateCharacter} 
            className="gap-2"
            disabled={!canCreate && !isAtLimit}
            variant={isAtLimit ? "outline" : "default"}
          >
            <Plus className="h-4 w-4" />
            {isAtLimit ? "Upgrade für mehr" : t.characters.createTitle}
          </Button>
        }
      />

      {/* View Mode Toggle */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">Ansicht:</span>
          <div className="flex rounded-md border">
            <Button
              variant={viewMode === "grid" ? "default" : "ghost"}
              size="sm"
              onClick={() => setViewMode("grid")}
              className="rounded-r-none"
            >
              <LayoutGrid className="h-4 w-4 mr-2" />
              Grid
            </Button>
            <Button
              variant={viewMode === "dashboard" ? "default" : "ghost"}
              size="sm"
              onClick={() => setViewMode("dashboard")}
              className="rounded-l-none"
            >
              <BarChart3 className="h-4 w-4 mr-2" />
              Dashboard
            </Button>
          </div>
        </div>

        {/* Character View Mode Toggle */}
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">Wrestler-Ansicht:</span>
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              const newMode = characterViewMode === 'modal' ? 'full' : 'modal'
              setCharacterViewMode(newMode)
              localStorage.setItem('character-view-mode', newMode)
            }}
            className="gap-2"
          >
            <Settings className="h-4 w-4" />
            {characterViewMode === 'modal' ? 'Modal' : 'Full-View'}
          </Button>
        </div>
      </div>

      {/* Filters - only for grid view */}
      {viewMode === "grid" && (
        <div className="flex gap-4 mb-6">
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Wrestler suchen..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9"
            />
          </div>
          <Select value={roleFilter} onValueChange={setRoleFilter}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder={t.common.all} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{t.common.all}</SelectItem>
              <SelectItem value="protagonist">Protagonist</SelectItem>
              <SelectItem value="antagonist">Antagonist</SelectItem>
              <SelectItem value="supporting">Nebenrolle</SelectItem>
              <SelectItem value="recurring">Wiederkehrend</SelectItem>
              <SelectItem value="guest">Gastrolle</SelectItem>
            </SelectContent>
          </Select>
        </div>
      )}

      {/* Content based on view mode */}
      {viewMode === "dashboard" ? (
        <CharacterDashboard
          characters={data.characters}
          relationships={data.relationships}
          championships={data.characterArcs}
          onEdit={handleEdit}
          onDelete={(id) => setDeleteConfirm(id)}
        />
      ) : (
        /* Character Grid */
        filteredCharacters.length === 0 ? (
          <EmptyState
            icon={Users}
            title={search || roleFilter !== "all" ? t.ui.emptyStates.noCharacters : t.ui.emptyStates.noCharacters}
            description={
              search || roleFilter !== "all"
                ? "Versuche andere Suchkriterien."
                : "Erstelle deinen ersten Wrestler, um mit der Planung zu beginnen."
            }
            actionLabel={!search && roleFilter === "all" ? "Ersten Wrestler erstellen" : undefined}
            onAction={!search && roleFilter === "all" ? handleCreateCharacter : undefined}
          />
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredCharacters.map((character) => (
              <CharacterCard
                key={character.id}
                character={character}
                relationshipCount={getRelationshipCount(character.id)}
                storylineCount={data.storylines.filter((storyline) => storyline.characterIds.includes(character.id)).length}
                onEdit={() => handleEdit(character)}
                onDelete={() => setDeleteConfirm(character.id)}
                onView={() => handleViewCharacter(character)}
              />
            ))}
          </div>
        )
      )}

      {/* Forms & Dialogs */}
      <CharacterForm open={showForm} onOpenChange={handleFormClose} character={editingCharacter} />

      {viewingCharacter && (
        <CharacterDetail
          open={!!viewingCharacter}
          onOpenChange={(open) => !open && setViewingCharacter(undefined)}
          character={viewingCharacter}
        />
      )}

      <AlertDialog open={!!deleteConfirm} onOpenChange={(open) => !open && setDeleteConfirm(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t.ui.confirmations.deleteCharacter}</AlertDialogTitle>
            <AlertDialogDescription>
              Diese Aktion kann nicht rückgängig gemacht werden. Alle Beziehungen zu diesem Wrestler werden ebenfalls
              gelöscht.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Abbrechen</AlertDialogCancel>
            <AlertDialogAction onClick={() => deleteConfirm && handleDelete(deleteConfirm)}>{t.common.delete}</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <UpgradeModal
        open={showUpgradeModal}
        onOpenChange={setShowUpgradeModal}
        limitType="wrestlers"
        currentCount={data.characters.length}
        maxCount={currentPlan.limits.maxWrestlers === Infinity ? 999 : currentPlan.limits.maxWrestlers}
      />
    </>
  )
}
