"use client"

import { useParams, useRouter } from "next/navigation"
import { useSeries } from "@/lib/series-context"
import { CharacterFullView } from "@/components/character-full-view"
import { CharacterDetail } from "@/components/character-detail"
import { CharacterForm } from "@/components/character-form"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Settings, Pencil } from "lucide-react"
import type { Character } from "@/lib/types"

export default function CharacterPage() {
  const params = useParams()
  const router = useRouter()
  const { data, isLoading } = useSeries()
  const [useModalFallback, setUseModalFallback] = useState(false)
  const [showEditForm, setShowEditForm] = useState(false)
  const [editingCharacter, setEditingCharacter] = useState<Character | undefined>()

  const character = data.characters.find((c) => c.id === params.id)

  // Check if user prefers modal fallback
  useEffect(() => {
    const preference = localStorage.getItem('character-view-mode')
    setUseModalFallback(preference === 'modal')
  }, [])

  const handleEdit = (character: Character) => {
    setEditingCharacter(character)
    setShowEditForm(true)
  }

  const handleFormClose = (open: boolean) => {
    setShowEditForm(open)
    if (!open) setEditingCharacter(undefined)
  }

  const toggleViewMode = () => {
    const newMode = useModalFallback ? 'full' : 'modal'
    localStorage.setItem('character-view-mode', newMode)
    setUseModalFallback(!useModalFallback)
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-pulse text-muted-foreground">Lädt Charakter...</div>
      </div>
    )
  }

  if (!character) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-2">Charakter nicht gefunden</h1>
          <p className="text-muted-foreground mb-4">Der gesuchte Charakter existiert nicht.</p>
          <Button onClick={() => router.push('/characters')}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Zurück zu Charaktere
          </Button>
        </div>
      </div>
    )
  }

  return (
    <>
      {/* Header mit Navigation und Toggle */}
      <div className="sticky top-0 z-50 bg-background border-b border-border">
        <div className="flex items-center justify-between px-6 py-3">
          <Button
            variant="ghost"
            onClick={() => router.push('/characters')}
            className="gap-2"
          >
            <ArrowLeft className="h-4 w-4" />
            Zurück
          </Button>

          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => character && handleEdit(character)}
              className="gap-2"
            >
              <Pencil className="h-4 w-4" />
              Bearbeiten
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={toggleViewMode}
              className="gap-2"
            >
              <Settings className="h-4 w-4" />
              {useModalFallback ? 'Full-View' : 'Modal-View'}
            </Button>
          </div>
        </div>
      </div>

      {/* Content */}
      {useModalFallback ? (
        <div className="min-h-screen flex items-center justify-center p-4">
          <CharacterDetail
            open={true}
            onOpenChange={(open) => !open && router.push('/characters')}
            character={character}
          />
        </div>
      ) : (
        <CharacterFullView character={character} />
      )}

      {/* Edit Form */}
      <CharacterForm
        open={showEditForm}
        onOpenChange={handleFormClose}
        character={editingCharacter}
      />
    </>
  )
}