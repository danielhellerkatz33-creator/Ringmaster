"use client"

import { useMemo } from "react"
import { useSeries } from "@/lib/series-context"
import type { Character, Segment, Event, SeriesData } from "@/lib/types"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { CharacterAvatar } from "@/components/character-avatar"
import { Users, BarChart3 } from "lucide-react"

interface CharacterUtilization {
  character: Character
  sceneCount: number
  totalScenes: number
  utilizationPercentage: number
}

export default function DeploymentPlanningPage() {
  const { data } = useSeries()

  const characterUtilization = useMemo(() => {
    return calculateCharacterUtilization(data)
  }, [data])

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Einsatzplanung</h1>
          <p className="text-muted-foreground">
            Übersicht über die Auslastung aller aktiven Charaktere in noch nicht abgeschlossenen Events
          </p>
        </div>
        <BarChart3 className="h-8 w-8 text-muted-foreground" />
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Aktive Charaktere</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{characterUtilization.length}</div>
            <p className="text-xs text-muted-foreground">
              In der Planung berücksichtigt
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Offene Segmente</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {characterUtilization[0]?.totalScenes || 0}
            </div>
            <p className="text-xs text-muted-foreground">
              Noch nicht in Events eingebaut
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Höchste Auslastung</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {characterUtilization.length > 0 ? Math.max(...characterUtilization.map(c => c.utilizationPercentage)).toFixed(1) : 0}%
            </div>
            <p className="text-xs text-muted-foreground">
              Maximaler Einsatzanteil
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Durchschnitt</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {characterUtilization.length > 0
                ? (characterUtilization.reduce((sum, c) => sum + c.utilizationPercentage, 0) / characterUtilization.length).toFixed(1)
                : 0}%
            </div>
            <p className="text-xs text-muted-foreground">
              Durchschnittliche Auslastung
            </p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Charakter-Auslastung</CardTitle>
          <CardDescription>
            Übersicht über die Beteiligung jedes Charakters an noch nicht abgeschlossenen Segmenten
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <CharacterUtilizationTable data={characterUtilization} />
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

function calculateCharacterUtilization(data: SeriesData): CharacterUtilization[] {
  // Sicherstellen, dass alle Arrays existieren
  const characters = data.characters || []
  const segments = data.segments || []
  const events = data.episodes || []

  // 1. Finde alle Segmente, die noch NICHT in abgeschlossenen Events sind
  const completedEventIds = events
    .filter(ep => ep.status === 'completed')
    .map(ep => ep.id)

  const completedSegmentIds = new Set(
    events
      .filter(ep => completedEventIds.includes(ep.id))
      .flatMap(ep => ep.sceneIds || [])
  )

  const relevantSegments = segments.filter(
    segment => !completedSegmentIds.has(segment.id)
  )

  // 2. Finde aktive Charaktere (nur mit Status "active")
  const activeCharacters = characters
    .filter(char => char && char.status === 'active')
    .sort((a, b) => a.name.localeCompare(b.name))

  // 3. Berechne Auslastung pro Charakter
  const utilization = activeCharacters.map(character => {
    const characterSegments = relevantSegments.filter(
      segment => segment.characterIds && segment.characterIds.includes(character.id)
    )

    return {
      character,
      sceneCount: characterSegments.length,
      totalScenes: relevantSegments.length,
      utilizationPercentage: relevantSegments.length > 0
        ? (characterSegments.length / relevantSegments.length) * 100
        : 0
    }
  })

  // Sortiere nach Auslastung (höchste zuerst)
  return utilization.sort((a, b) => b.utilizationPercentage - a.utilizationPercentage)
}

function CharacterUtilizationTable({ data }: { data: CharacterUtilization[] }) {
  if (data.length === 0) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        Keine Daten verfügbar
      </div>
    )
  }

  const getUtilizationColor = (percentage: number) => {
    if (percentage >= 70) return "destructive"
    if (percentage >= 50) return "secondary"
    if (percentage >= 30) return "default"
    return "outline"
  }

  const getProgressColor = (percentage: number) => {
    if (percentage >= 70) return "[&>div]:bg-red-500"
    if (percentage >= 50) return "[&>div]:bg-yellow-500"
    if (percentage >= 30) return "[&>div]:bg-blue-500"
    return "[&>div]:bg-green-500"
  }

  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Charakter</TableHead>
          <TableHead>Position</TableHead>
          <TableHead>Alignment</TableHead>
          <TableHead className="text-right">Segmente</TableHead>
          <TableHead className="text-right">Auslastung</TableHead>
          <TableHead>Auslastungsanzeige</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {data.map((item) => (
          <TableRow key={item.character.id}>
            <TableCell className="font-medium">
              <div className="flex items-center gap-3">
                <CharacterAvatar
                  character={item.character}
                  name={item.character.name}
                  size="sm"
                />
                <span>{item.character.name}</span>
              </div>
            </TableCell>
            <TableCell>
              <Badge variant="outline">
                {item.character.position}
              </Badge>
            </TableCell>
            <TableCell>
              <Badge 
                variant={
                  item.character.alignment === 'heel' ? 'destructive' :
                  item.character.alignment === 'face' ? 'default' :
                  'secondary'
                }
              >
                {item.character.alignment}
              </Badge>
            </TableCell>
            <TableCell className="text-right">
              {item.sceneCount} / {item.totalScenes}
            </TableCell>
            <TableCell className="text-right">
              <Badge variant={getUtilizationColor(item.utilizationPercentage)}>
                {item.utilizationPercentage.toFixed(1)}%
              </Badge>
            </TableCell>
            <TableCell>
              <div className="flex items-center space-x-2">
                <Progress
                  value={item.utilizationPercentage}
                  className={`flex-1 h-2 ${getProgressColor(item.utilizationPercentage)}`}
                />
              </div>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  )
}