"use client"

import { useState, useMemo } from "react"
import { useSeries } from "@/lib/series-context"
import { PageHeader } from "@/components/page-header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Copy, Brain, FileText, TrendingUp, MapPin, Clock, Users } from "lucide-react"
import { CharacterAvatar } from "@/components/character-avatar"
import { toast } from "sonner"
import type { Segment, Character, Storyline } from "@/lib/types"

// Hilfsfunktionen für Segment-Analyse
const countBy = <T,>(array: T[], key: keyof T): Record<string, number> => {
  return array.reduce((acc, item) => {
    const value = String(item[key])
    acc[value] = (acc[value] || 0) + 1
    return acc
  }, {} as Record<string, number>)
}

const analyzeMoodProgression = (scenes: Segment[]): string => {
  if (scenes.length === 0) return "Keine Segmente verfügbar"

  // Für Wrestling-Segmente verwenden wir die Titel zur Analyse
  const sortedScenes = [...scenes].sort((a, b) => a.order - b.order)
  const titles = sortedScenes.map(s => s.title)

  if (titles.length <= 3) return `Segmente: ${titles.slice(0, 3).join(" → ")}`

  const firstThird = titles.slice(0, Math.floor(titles.length / 3))
  const middleThird = titles.slice(Math.floor(titles.length / 3), Math.floor(2 * titles.length / 3))
  const lastThird = titles.slice(Math.floor(2 * titles.length / 3))

  return `${firstThird.slice(0, 2).join(" & ")} → ${middleThird.slice(0, 2).join(" & ")} → ${lastThird.slice(0, 2).join(" & ")}`
}

const analyzeCharacterInteractions = (scenes: Segment[], characterId: string, allCharacters: Character[]): string[] => {
  const interactions: Record<string, number> = {}

  scenes.forEach(scene => {
    scene.characterIds.forEach(otherId => {
      if (otherId !== characterId) {
        interactions[otherId] = (interactions[otherId] || 0) + 1
      }
    })
  })

  const aloneScenes = scenes.filter(scene => scene.characterIds.length === 1).length

  const result = Object.entries(interactions)
    .sort(([,a], [,b]) => b - a)
    .slice(0, 3)
    .map(([id, count]) => {
      const char = allCharacters.find(c => c.id === id)
      return `${char?.name || 'Unbekannt'}: ${count} gemeinsame Segmente`
    })

  if (aloneScenes > 0) {
    result.push(`Allein-Segmente: ${aloneScenes}`)
  }

  return result
}

const groupScenesByTheme = (scenes: Segment[]): Record<string, Segment[]> => {
  const themes: Record<string, Segment[]> = {
    'Arbeitsumfeld': [],
    'Persönliches Leben': [],
    'Beziehungen': [],
    'Konflikte': [],
    'Reflexion': [],
    'Action': [],
    'Andere': []
  }

  scenes.forEach(scene => {
    const title = scene.title.toLowerCase()
    const description = scene.description.toLowerCase()
    const text = `${title} ${description}`

    if (text.includes('büro') || text.includes('arbeit') || text.includes('chef') || text.includes('kolleg')) {
      themes['Arbeitsumfeld'].push(scene)
    } else if (text.includes('zuhause') || text.includes('familie') || text.includes('heim') || text.includes('privat')) {
      themes['Persönliches Leben'].push(scene)
    } else if (text.includes('liebe') || text.includes('beziehung') || text.includes('freund') || text.includes('partner')) {
      themes['Beziehungen'].push(scene)
    } else if (text.includes('kampf') || text.includes('streit') || text.includes('konflikt') || text.includes('problem')) {
      themes['Konflikte'].push(scene)
    } else if (text.includes('denk') || text.includes('erinner') || text.includes('traum') || text.includes('allein')) {
      themes['Reflexion'].push(scene)
    } else if (text.includes('renn') || text.includes('verfolg') || text.includes('kampf') || text.includes('flucht')) {
      themes['Action'].push(scene)
    } else {
      themes['Andere'].push(scene)
    }
  })

  // Leere Kategorien entfernen
  return Object.fromEntries(
    Object.entries(themes).filter(([, scenes]) => scenes.length > 0)
  )
}

const getCharacterStorySummaries = (characterName: string, storylines: Storyline[]): string => {
  // Finde alle abgeschlossenen Storylines mit Charakterrückblicken
  const storylinesWithReviews = storylines.filter(
    storyline => storyline.status === "completed" && storyline.characterReview
  )

  if (storylinesWithReviews.length === 0) {
    return "Keine abgeschlossenen Storylines mit Charakterrückblicken gefunden."
  }

  const characterReviews = storylinesWithReviews.map(storyline => {
    // Extrahiere nur den Teil des Charakterrückblicks, der diesen spezifischen Charakter betrifft
    const reviewLines = storyline.characterReview.split('\n\n')
    const characterSection = reviewLines.find(line =>
      line.trim().startsWith(`${characterName}:`)
    )

    if (!characterSection) {
      return null // Dieser Charakter ist nicht in diesem Charakterrückblick erwähnt
    }

    return {
      storyline,
      characterReview: characterSection.trim()
    }
  }).filter(Boolean) // Entferne null-Einträge

  if (characterReviews.length === 0) {
    return `Keine Charakterrückblicke für ${characterName} in abgeschlossenen Storylines gefunden.`
  }

  const summaries = characterReviews.map(({ storyline, characterReview }) => {
    let summaryText = `📖 "${storyline.title}" (${storyline.type === 'main' ? 'Haupthandlung' : storyline.type === 'subplot' ? 'Nebenhandlung' : 'Story Arc'})\n`

    if (storyline.summary) {
      summaryText += `Zusammenfassung: ${storyline.summary}\n`
    }

    summaryText += `Charakterrückblick (${characterName}): ${characterReview}\n`

    return summaryText.trim()
  }).join('\n\n')

  return summaries
}

const generateSceneSummary = (scenes: Segment[], character: Character, allCharacters: Character[]) => {
  if (scenes.length === 0) {
    return {
      overview: "Keine Segmente für diesen Wrestler gefunden.",
      stats: {},
      themes: {},
      interactions: [],
      development: "Keine Entwicklung verfügbar"
    }
  }

  const locationStats = {} // Keine Location-Daten für Segmente verfügbar
  const timeStats = {} // Keine TimeOfDay-Daten für Segmente verfügbar
  const moodProgression = analyzeMoodProgression(scenes)
  const interactions = analyzeCharacterInteractions(scenes, character.id, allCharacters)
  const thematicGroups = groupScenesByTheme(scenes)

  const totalDuration = scenes.reduce((sum, scene) => sum + scene.duration, 0)
  const avgDuration = Math.round(totalDuration / scenes.length)

  return {
    overview: `${character.name} tritt in ${scenes.length} Segmenten auf (Ø ${avgDuration} Minuten pro Segment)`,
    stats: {
      locations: locationStats,
      times: timeStats,
      totalDuration,
      avgDuration
    },
    themes: thematicGroups,
    interactions,
    development: moodProgression
  }
}

export default function CharacterAnalysisPage() {
  const { data, isLoading } = useSeries()
  const [selectedCharacterId, setSelectedCharacterId] = useState<string>("")

  // Character-Daten für Analyse aggregieren
  const characterAnalysis = useMemo(() => {
    if (!selectedCharacterId) return null

    const character = data.characters.find(c => c.id === selectedCharacterId)
    if (!character) return null

    // Alle relevanten Daten sammeln
    const characterScenes = data.segments.filter(s => s.characterIds.includes(character.id))
    const characterArcs = data.characterArcs.filter(a => a.characterId === character.id)
    const characterStorylines = data.storylines.filter(s => s.characterIds.includes(character.id))

    // Beziehungen des Charakters
    const characterRelationships = data.relationships.filter(
      r => r.characterIds && r.characterIds.includes(character.id)
    )

    // Segmente chronologisch sortieren und mit Event-Informationen anreichern
    const sortedScenes = characterScenes
      .map(scene => {
        // Finde das Event dieses Segments
        const event = data.episodes.find(ep => ep.sceneIds.includes(scene.id))
        return { ...scene, event }
      })
      .sort((a, b) => {
        // Zuerst nach Event sortieren, dann nach Segment-Order
        if (a.event && b.event) {
          // Event hat keine seasonNumber, also nur nach eventNumber sortieren
          if (a.event.eventNumber !== b.event.eventNumber) {
            return a.event.eventNumber - b.event.eventNumber
          }
        }
        return a.order - b.order
      })

    // Segmente-Zusammenfassung generieren
    const sceneSummary = generateSceneSummary(sortedScenes, character, data.characters)

    return {
      character,
      scenes: sortedScenes,
      arcs: characterArcs,
      storylines: characterStorylines,
      relationships: characterRelationships,
      sceneSummary
    }
  }, [selectedCharacterId, data])

  // ChatGPT-Prompt generieren
  const generateChatGPTPrompt = () => {
    if (!characterAnalysis) return ""

    const { character, scenes, arcs, storylines, relationships, sceneSummary } = characterAnalysis

    return `Du bist ein erfahrener Wrestling-Booker und Storyline-Autor. Analysiere diesen Wrestler und schlage Entwicklungsmöglichkeiten vor:

🎭 WRESTLER: ${character.name}
Position: ${character.position}

📊 SEGMENT-ZUSAMMENFASSUNG:
${sceneSummary.overview}
• Stimmungsverlauf: ${sceneSummary.development}
• Häufigste Orte: ${Object.entries(sceneSummary.stats.locations || {}).slice(0, 3).map(([loc, count]) => `${loc} (${count}x)`).join(", ")}
• Häufigste Tageszeiten: ${Object.entries(sceneSummary.stats.times || {}).slice(0, 3).map(([time, count]) => `${time} (${count}x)`).join(", ")}

🎭 MATCH-TYPEN & THEMEN:
${Object.entries(sceneSummary.themes || {}).map(([theme, themeScenes]) =>
  `${theme} (${Array.isArray(themeScenes) ? themeScenes.length : 0} Segmente)`
).join("\n")}

👥 WICHTIGSTE RIVALITÄTEN:
${(sceneSummary.interactions || []).map(interaction => `• ${interaction}`).join("\n")}

📖 CHAMPIONSHIP-HISTORY & STORYLINE-RÜCKBLICKE:
${getCharacterStorySummaries(character.name, data.storylines)}

🔄 CHAMPIONSHIP REIGNS:
${(arcs || []).map(arc =>
  `- "${arc.title}": ${arc.description} (Status: ${arc.status}, Titelverteidigungen: ${(arc.milestones || []).filter(m => m.completed).length}/${(arc.milestones || []).length})`
).join("\n")}

❤️ WRESTLER-BEZIEHUNGEN:
${(relationships || []).map(rel => {
  const otherIds = rel.characterIds?.filter(id => id !== character.id) || []
  const otherId = otherIds[0] // Nehme den ersten anderen Charakter
  const otherChar = data.characters?.find(c => c.id === otherId)
  return `- ${otherChar?.name || 'Unbekannt'} (${rel.type}): Intensität ${rel.intensity}/10`
}).join("\n")}

📖 AKTIVE STORYLINES:
${(storylines || []).map(storyline =>
  `- "${storyline.title}": ${storyline.description} (Status: ${storyline.status})`
).join("\n")}

Basierend auf diesen Wrestling-Daten:
1. In welche Richtung könnte sich ${character.name} entwickeln?
2. Welche nächste Match-Storyline würde zu ${character.name} passen?
3. Welche ungenutzten Möglichkeiten siehst du für diesen Wrestler?
4. Welche Rivalitäten oder Allianzen sollten vertieft werden?
5. Welche Championship-Verfolgung wäre realistisch?`
  }

  const copyToClipboard = async () => {
    const prompt = generateChatGPTPrompt()
    await navigator.clipboard.writeText(prompt)
    toast.success("Prompt wurde in die Zwischenablage kopiert!")
  }

  if (isLoading) {
    return (
      <div className="animate-pulse space-y-4">
        <div className="h-8 bg-muted rounded w-1/4" />
        <div className="h-64 bg-muted rounded" />
      </div>
    )
  }

  return (
    <div className="space-y-8">
      <PageHeader
        title="Charakter-Analyse für KI"
        description="Analysiere Charaktere und generiere KI-Prompts für ChatGPT"
      />

      {/* Charakter-Auswahl */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5" />
            Charakter auswählen
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Select value={selectedCharacterId} onValueChange={setSelectedCharacterId}>
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Wähle einen Charakter für die Analyse..." />
            </SelectTrigger>
            <SelectContent>
              {[...data.characters]
                .sort((a, b) => a.name.localeCompare(b.name))
                .map((character) => (
                  <SelectItem key={character.id} value={character.id}>
                    <div className="flex items-center gap-2">
                      <CharacterAvatar character={character} size="sm" />
                      {character.name}
                    </div>
                  </SelectItem>
                ))}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {/* Analyse-Ergebnis */}
      {characterAnalysis && (
        <>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Analyse: {characterAnalysis.character.name}</span>
                <Button onClick={copyToClipboard} className="flex items-center gap-2">
                  <Copy className="h-4 w-4" />
                  Für ChatGPT kopieren
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Zusammenfassung */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center p-3 bg-muted/50 rounded-lg">
                  <div className="text-2xl font-bold">{characterAnalysis.scenes.length}</div>
                  <div className="text-sm text-muted-foreground">Szenen</div>
                </div>
                <div className="text-center p-3 bg-muted/50 rounded-lg">
                  <div className="text-2xl font-bold">{characterAnalysis.arcs.length}</div>
                  <div className="text-sm text-muted-foreground">Arcs</div>
                </div>
                <div className="text-center p-3 bg-muted/50 rounded-lg">
                  <div className="text-2xl font-bold">{characterAnalysis.relationships.length}</div>
                  <div className="text-sm text-muted-foreground">Beziehungen</div>
                </div>
                <div className="text-center p-3 bg-muted/50 rounded-lg">
                  <div className="text-2xl font-bold">{characterAnalysis.storylines.length}</div>
                  <div className="text-sm text-muted-foreground">Storylines</div>
                </div>
              </div>

              {/* Szenen-Zusammenfassung */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Statistische Analyse */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-lg">
                      <TrendingUp className="h-5 w-5" />
                      Szenen-Analyse
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <div className="text-sm font-medium text-muted-foreground mb-1">Übersicht</div>
                      <div className="text-sm">{characterAnalysis.sceneSummary.overview}</div>
                    </div>

                    <div>
                      <div className="text-sm font-medium text-muted-foreground mb-1">Stimmungsverlauf</div>
                      <div className="text-sm">{characterAnalysis.sceneSummary.development}</div>
                    </div>

                    <div>
                      <div className="text-sm font-medium text-muted-foreground mb-2">Häufigste Orte</div>
                      <div className="flex flex-wrap gap-1">
                        {Object.entries(characterAnalysis.sceneSummary.stats.locations || {})
                          .sort(([,a], [,b]) => b - a)
                          .slice(0, 3)
                          .map(([location, count]) => (
                          <Badge key={location} variant="outline" className="text-xs">
                            {location} ({count})
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div>
                      <div className="text-sm font-medium text-muted-foreground mb-2">Häufigste Tageszeiten</div>
                      <div className="flex flex-wrap gap-1">
                        {Object.entries(characterAnalysis.sceneSummary.stats.times || {})
                          .sort(([,a], [,b]) => b - a)
                          .slice(0, 3)
                          .map(([time, count]) => (
                          <Badge key={time} variant="outline" className="text-xs">
                            {time} ({count})
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Thematische Gruppen & Interaktionen */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-lg">
                      <Users className="h-5 w-5" />
                      Themen & Interaktionen
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <div className="text-sm font-medium text-muted-foreground mb-2">Thematische Gruppen</div>
                      <div className="space-y-1">
                        {Object.entries(characterAnalysis.sceneSummary.themes).map(([theme, scenes]) => (
                          <div key={theme} className="flex justify-between text-sm">
                            <span>{theme}</span>
                            <Badge variant="secondary" className="text-xs">{scenes.length} Szenen</Badge>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div>
                      <div className="text-sm font-medium text-muted-foreground mb-2">Wichtigste Interaktionen</div>
                      <div className="space-y-1">
                        {characterAnalysis.sceneSummary.interactions.map((interaction, index) => (
                          <div key={index} className="text-sm">{interaction}</div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Detaillierte Daten (für ChatGPT formatiert) */}
              <div className="bg-muted/30 p-4 rounded-lg font-mono text-sm whitespace-pre-wrap">
                {generateChatGPTPrompt()}
              </div>
            </CardContent>
          </Card>
        </>
      )}

      {!selectedCharacterId && (
        <Card>
          <CardContent className="text-center py-12">
            <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">
              Wähle einen Charakter aus, um die Analyse zu starten.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}