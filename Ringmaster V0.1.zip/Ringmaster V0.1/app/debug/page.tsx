// Einfache Debug-Seite um zu testen, ob React grundsätzlich funktioniert
export default function DebugPage() {
  return (
    <div className="min-h-screen bg-background p-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-8">🔧 Debug-Modus</h1>

        <div className="grid gap-6">
          <div className="p-6 bg-card rounded-lg border">
            <h2 className="text-xl font-semibold mb-4">✅ React funktioniert!</h2>
            <p className="text-muted-foreground mb-4">
              Wenn diese Seite angezeigt wird, ist die grundlegende React-App funktionsfähig.
            </p>
            <p className="text-sm text-muted-foreground">
              Wenn die Hauptseite (Dashboard) einen weißen Bildschirm zeigt, liegt das Problem
              wahrscheinlich an der Datenladung oder einem JavaScript-Fehler.
            </p>
          </div>

          <div className="p-6 bg-card rounded-lg border">
            <h2 className="text-xl font-semibold mb-4">🔍 Nächste Schritte:</h2>
            <ol className="list-decimal list-inside space-y-2 text-sm">
              <li>Öffne die Browser-Konsole (F12)</li>
              <li>Schaue nach roten Fehlermeldungen</li>
              <li>Teste die minimale Save-Datei: <code className="bg-muted px-2 py-1 rounded">ringmaster-minimal-test.json</code></li>
              <li>Wenn die minimale Datei funktioniert, liegt es an der Datengröße</li>
            </ol>
          </div>

          <div className="p-6 bg-card rounded-lg border">
            <h2 className="text-xl font-semibold mb-4">📁 Verfügbare Test-Dateien:</h2>
            <ul className="space-y-1 text-sm">
              <li><code className="bg-muted px-2 py-1 rounded">ringmaster-minimal-test.json</code> (950KB - für Tests)</li>
              <li><code className="bg-muted px-2 py-1 rounded">ringmaster-backup-[timestamp].json</code> (12MB - korrigiert)</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  )
}