import type React from "react"
import type { Metadata, Viewport } from "next"
import { Geist, Geist_Mono } from "next/font/google"
import { Analytics } from "@vercel/analytics/next"
import { SeriesProvider } from "@/lib/series-context"
import { ChampionshipProvider } from "@/lib/championship-context"
import { LanguageProvider } from "@/lib/i18n/language-context"
import { SkinProvider } from "@/lib/skin-context"
import { EventStyleProvider } from "@/lib/event-style-context"
import { AuthProvider } from "@/lib/auth-context"
import { ThemeProvider } from "@/components/theme-provider"
import { Sidebar } from "@/components/sidebar"
import { SaveButton } from "@/components/save-button"
import { LanguageSelector } from "@/components/language-selector"
import { ServiceWorkerRegister } from "@/components/service-worker-register"
import { Toaster } from "@/components/ui/toaster"
import "./globals.css"

const _geist = Geist({ subsets: ["latin"] })
const _geistMono = Geist_Mono({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Ringmaster",
  description: "Manage your wrestling promotion with characters, storylines, scenes and events",
  generator: 'v0.app',
  manifest: '/manifest.webmanifest',
  icons: {
    icon: '/favicon.ico',
    apple: '/apple-icon.png'
  }
}

export const viewport: Viewport = {
  themeColor: '#111111',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="de" suppressHydrationWarning>
      <head>
        <link rel="manifest" href="/manifest.webmanifest" />
      </head>
      <body className="font-sans antialiased">
        <ServiceWorkerRegister />
        <AuthProvider>
          <SkinProvider>
            <ThemeProvider>
              <LanguageProvider>
                <EventStyleProvider>
                  <SeriesProvider>
                    <ChampionshipProvider>
                    <div className="flex h-screen overflow-hidden">
                      <Sidebar />
                      <main className="flex-1 overflow-auto relative">
                        <SaveButton />
                        <LanguageSelector />
                        <div className="container max-w-7xl mx-auto p-6 pt-16">{children}</div>
                      </main>
                    </div>
                  </ChampionshipProvider>
                </SeriesProvider>
              </EventStyleProvider>
            </LanguageProvider>
            </ThemeProvider>
          </SkinProvider>
        </AuthProvider>
        <Toaster />
        <Analytics />
      </body>
    </html>
  )
}
