import { SavegamePanel } from "@/components/savegame-panel"
import { PageHeader } from "@/components/page-header"

export default function BackupPage() {
  return (
    <div className="space-y-6">
      <PageHeader
        title="Backup & Wiederherstellung"
        description="Sichern und wiederherstellen Sie Ihre Wrestling-Spiel Daten"
      />

      <div className="max-w-2xl">
        <SavegamePanel />
      </div>
    </div>
  )
}