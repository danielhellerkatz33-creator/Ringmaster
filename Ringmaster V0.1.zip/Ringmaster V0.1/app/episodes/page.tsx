"use client"

import { useState } from "react"
import { useSeries } from "@/lib/series-context"
import { PageHeader } from "@/components/page-header"
import { EmptyState } from "@/components/empty-state"
import { EpisodeForm } from "@/components/episode-form"
import { EpisodeDetail } from "@/components/episode-detail"
import { EventReportModal } from "@/components/event-report"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Plus, Film, MoreVertical, Pencil, Trash2, Eye, Clock, Clapperboard, Calendar, ImageIcon, SortAsc, FileText } from "lucide-react"
import { EventStyleSwitcher } from "@/components/event-style-switcher"
import { useEventStyle } from "@/lib/event-style-context"
import type { Event, Segment } from "@/lib/types"

const statusLabels: Record<Event["status"], string> = {
  planning: "In Planung",
  writing: "In Arbeit",
  production: "Produktion",
  completed: "Abgeschlossen",
}

const statusColors: Record<Event["status"], string> = {
  planning: "bg-gray-500/20 text-gray-400",
  writing: "bg-blue-500/20 text-blue-500",
  production: "bg-amber-500/20 text-amber-500",
  completed: "bg-green-500/20 text-green-500",
}

export default function EpisodesPage() {
  const { data, isLoading, deleteEpisode } = useSeries()
  const { eventStyle } = useEventStyle()
  const [showForm, setShowForm] = useState(false)
  const [editingEpisode, setEditingEpisode] = useState<Event | undefined>()
  const [viewingEpisode, setViewingEpisode] = useState<Event | undefined>()
  const [showReportModal, setShowReportModal] = useState<Event | undefined>()
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null)

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-pulse text-muted-foreground">Lädt Events...</div>
      </div>
    )
  }

  // Group events by status first, then by type
  const statusGroups = [
    { key: 'planning', label: 'In Planung', statuses: ['planning', 'writing', 'production'] },
    { key: 'completed', label: 'Abgeschlossen', statuses: ['completed'] }
  ]

  const getEventTypesByStatus = (statusGroup: { statuses: string[] }) => {
    const types = [...new Set(
      data.episodes
        .filter(e => statusGroup.statuses.includes(e.status))
        .map((e) => e.eventType || 'Weekly TV')
    )].sort()
    return types.length > 0 ? types : ['Weekly TV']
  }

  const getEventsByStatusAndType = (statusGroup: { statuses: string[] }, type: string) => {
    return data.episodes
      .filter((e) => 
        statusGroup.statuses.includes(e.status) && 
        (e.eventType || 'Weekly TV') === type
      )
      .sort((a, b) => {
        // Sort by air date (newest first), fallback to episode number if no air date
        if (a.airDate && b.airDate) {
          return new Date(b.airDate).getTime() - new Date(a.airDate).getTime()
        }
        if (a.airDate && !b.airDate) return -1
        if (!a.airDate && b.airDate) return 1
        return b.eventNumber - a.eventNumber
      })
  }

  const handleEdit = (episode: Event) => {
    setEditingEpisode(episode)
    setShowForm(true)
  }

  const handleDelete = (id: string) => {
    deleteEpisode(id)
    setDeleteConfirm(null)
  }

  const handleFormClose = (open: boolean) => {
    setShowForm(open)
    if (!open) setEditingEpisode(undefined)
  }

  const getEpisodeDuration = (episode: Event) => {
    return (episode.sceneIds || []).reduce((sum, sceneId) => {
      const scene = data.segments.find((s: Segment) => s.id === sceneId)
      return sum + (scene?.duration || 0)
    }, 0)
  }

  return (
    <>
      <PageHeader
        title="Events"
        description="Baue Events aus deinen Segmenten"
        action={
          <div className="flex items-center gap-3">
            <EventStyleSwitcher />
            <Button onClick={() => setShowForm(true)} className="gap-2">
              <Plus className="h-4 w-4" />
              Neues Event
            </Button>
          </div>
        }
      />

      {data.episodes.length === 0 ? (
        <EmptyState
          icon={Film}
          title="Noch keine Events"
          description="Erstelle Events und füge Segmente hinzu um deine Promotion zu strukturieren."
          actionLabel="Erstes Event erstellen"
          onAction={() => setShowForm(true)}
        />
      ) : (
        <Tabs defaultValue="planning">
          <TabsList className="mb-6">
            {statusGroups.map((status) => (
              <TabsTrigger key={status.key} value={status.key}>
                {status.label}
              </TabsTrigger>
            ))}
          </TabsList>

          {statusGroups.map((statusGroup) => (
            <TabsContent key={statusGroup.key} value={statusGroup.key}>
              <Tabs defaultValue={getEventTypesByStatus(statusGroup)[0] || "Weekly TV"}>
                <TabsList className="mb-4">
                  {getEventTypesByStatus(statusGroup).map((type) => (
                    <TabsTrigger key={type} value={type}>
                      {type}
                    </TabsTrigger>
                  ))}
                </TabsList>

                {getEventTypesByStatus(statusGroup).map((type) => (
                  <TabsContent key={type} value={type}>
                    <div className={`grid gap-4 ${
                      eventStyle === "style2" 
                        ? "grid-cols-1 md:grid-cols-2" 
                        : "grid-cols-1 md:grid-cols-2 lg:grid-cols-3"
                    }`}>
                      {getEventsByStatusAndType(statusGroup, type).map((episode) => {
                        const duration = getEpisodeDuration(episode)
                        return (
                          <Card key={episode.id} className={`group overflow-hidden transition-all duration-200 ${
                            eventStyle === "style2" ? "hover:shadow-lg hover:scale-[1.02]" : "hover:border-primary/50"
                          } bg-card`}>
                            {eventStyle === "style2" ? (
                              <>
                                {/* Bild-Header für Style 2 */}
                                <div className="relative w-full h-48 md:h-56 lg:h-64 overflow-hidden">
                                  {episode.imageUrl ? (
                                    <>
                                      <img
                                        src={episode.imageUrl}
                                        alt={episode.title}
                                        className="absolute inset-0 w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                                      />
                                      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent"></div>
                                    </>
                                  ) : (
                                    <div className="w-full h-full bg-muted flex items-center justify-center">
                                      <ImageIcon className="h-16 w-16 text-muted-foreground" />
                                    </div>
                                  )}
                                  
                                  {/* Status-Badge im Bild */}
                                  <div className="absolute top-3 right-3">
                                    <Badge className={`${
                                      statusColors[episode.status]
                                    } border-0 backdrop-blur-sm ${
                                      episode.imageUrl ? "bg-white/20 text-white" : ""
                                    }`}>
                                      {statusLabels[episode.status]}
                                    </Badge>
                                  </div>
                                </div>

                                {/* Content für Style 2 */}
                                <CardContent className="p-4">
                                  <div className="space-y-3">
                                    {/* Titel mit Dropdown */}
                                    <div className="flex items-start justify-between">
                                      <div className="flex-1 min-w-0">
                                        <h3 className="font-semibold text-lg leading-tight line-clamp-2">
                                          {episode.eventType} #{episode.eventNumber}: {episode.title}
                                        </h3>
                                      </div>
                                      <DropdownMenu>
                                        <DropdownMenuTrigger asChild>
                                          <Button
                                            variant="ghost"
                                            size="icon"
                                            className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity"
                                          >
                                            <MoreVertical className="h-4 w-4" />
                                          </Button>
                                        </DropdownMenuTrigger>
                                        <DropdownMenuContent align="end">
                                          {episode.status === "completed" ? (
                                            <DropdownMenuItem onClick={() => setShowReportModal(episode)}>
                                              <FileText className="h-4 w-4 mr-2" />
                                              Bericht anzeigen
                                            </DropdownMenuItem>
                                          ) : (
                                            <DropdownMenuItem onClick={() => setViewingEpisode(episode)}>
                                              <Eye className="h-4 w-4 mr-2" />
                                              Segmente verwalten
                                            </DropdownMenuItem>
                                          )}
                                          <DropdownMenuItem onClick={() => handleEdit(episode)}>
                                            <Pencil className="h-4 w-4 mr-2" />
                                            Bearbeiten
                                          </DropdownMenuItem>
                                          <DropdownMenuItem
                                            onClick={() => setDeleteConfirm(episode.id)}
                                            className="text-destructive focus:text-destructive"
                                          >
                                            <Trash2 className="h-4 w-4 mr-2" />
                                            Löschen
                                          </DropdownMenuItem>
                                        </DropdownMenuContent>
                                      </DropdownMenu>
                                    </div>

                                    {/* Metadaten horizontal */}
                                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                                      {episode.airDate && (
                                        <span className="flex items-center gap-1">
                                          <Calendar className="h-4 w-4" />
                                          {new Date(episode.airDate).toLocaleDateString("de-DE")}
                                        </span>
                                      )}
                                      <span className="flex items-center gap-1">
                                        <Clock className="h-4 w-4" />
                                        {duration} Min.
                                      </span>
                                      <span className="flex items-center gap-1">
                                        <Clapperboard className="h-4 w-4" />
                                        {episode.sceneIds.length} Szenen
                                      </span>
                                    </div>

                                    {/* Button */}
                                    <div className="flex justify-end">
                                      <Button
                                        variant="outline"
                                        size="sm"
                                        onClick={() => episode.status === "completed" ? setShowReportModal(episode) : setViewingEpisode(episode)}
                                        className="hover:bg-primary hover:text-primary-foreground transition-colors"
                                      >
                                        {episode.status === "completed" ? (
                                          <>
                                            <FileText className="h-4 w-4 mr-2" />
                                            Bericht anzeigen
                                          </>
                                        ) : (
                                          <>
                                            <Eye className="h-4 w-4 mr-2" />
                                            Szenen verwalten
                                          </>
                                        )}
                                      </Button>
                                    </div>
                                  </div>
                                </CardContent>
                              </>
                            ) : (
                              <>
                                {/* Original Style 1 Layout */}
                                <CardHeader className="flex flex-row items-start justify-between space-y-0 pb-3">
                                  <div className="flex items-start gap-3 flex-1">
                                    {episode.imageUrl ? (
                                      <img
                                        src={episode.imageUrl || "/placeholder.svg"}
                                        alt={episode.title}
                                        className={`object-cover rounded-lg shrink-0 transition-all duration-200 hover:scale-105 ${
                                          eventStyle === "style1" 
                                            ? "w-16 h-12 md:w-20 md:h-15" 
                                            : "w-24 h-16 md:w-32 md:h-20"
                                        }`}
                                      />
                                    ) : (
                                      <div className={`bg-muted rounded-lg flex items-center justify-center shrink-0 ${
                                        eventStyle === "style1" 
                                          ? "w-16 h-12 md:w-20 md:h-15" 
                                          : "w-24 h-16 md:w-32 md:h-20"
                                      }`}>
                                        <ImageIcon className={`text-muted-foreground ${
                                          eventStyle === "style1" 
                                            ? "h-5 w-5 md:h-6 md:w-6" 
                                            : "h-6 w-6 md:h-8 md:w-8"
                                        }`} />
                                      </div>
                                    )}
                                    <div className="flex-1 min-w-0">
                                      <div className="flex items-center gap-2 mb-1">
                                        <span className="font-mono text-sm text-muted-foreground">
                                          {episode.eventType || 'Weekly TV'} #{episode.eventNumber}
                                        </span>
                                        <Badge className={`${statusColors[episode.status]} border-0 text-xs`}>
                                          {statusLabels[episode.status]}
                                        </Badge>
                                      </div>
                                      <h3 className="font-semibold text-foreground leading-tight">{episode.title}</h3>
                                    </div>
                                  </div>
                                  <DropdownMenu>
                                    <DropdownMenuTrigger asChild>
                                      <Button
                                        variant="ghost"
                                        size="icon"
                                        className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity"
                                      >
                                        <MoreVertical className="h-4 w-4" />
                                      </Button>
                                    </DropdownMenuTrigger>
                                    <DropdownMenuContent align="end">
                                      {episode.status === "completed" ? (
                                        <DropdownMenuItem onClick={() => setShowReportModal(episode)}>
                                          <FileText className="h-4 w-4 mr-2" />
                                          Bericht anzeigen
                                        </DropdownMenuItem>
                                      ) : (
                                        <DropdownMenuItem onClick={() => setViewingEpisode(episode)}>
                                          <Eye className="h-4 w-4 mr-2" />
                                          Segmente verwalten
                                        </DropdownMenuItem>
                                      )}
                                      <DropdownMenuItem onClick={() => handleEdit(episode)}>
                                        <Pencil className="h-4 w-4 mr-2" />
                                        Bearbeiten
                                      </DropdownMenuItem>
                                      <DropdownMenuItem
                                        onClick={() => setDeleteConfirm(episode.id)}
                                        className="text-destructive focus:text-destructive"
                                      >
                                        <Trash2 className="h-4 w-4 mr-2" />
                                        Löschen
                                      </DropdownMenuItem>
                                    </DropdownMenuContent>
                                  </DropdownMenu>
                                </CardHeader>
                                <CardContent className="pt-0">
                                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                                    <span className="flex items-center gap-1">
                                      <Clapperboard className="h-3 w-3" />
                                      {episode.sceneIds.length} Szenen
                                    </span>
                                    <div className="flex items-center gap-3">
                                      {episode.airDate && (
                                        <span className="flex items-center gap-1">
                                          <Calendar className="h-3 w-3" />
                                          {new Date(episode.airDate).toLocaleDateString("de-DE")}
                                        </span>
                                      )}
                                      <span className="flex items-center gap-1">
                                        <Clock className="h-3 w-3" />
                                        {duration} Min.
                                      </span>
                                    </div>
                                  </div>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    className="w-full mt-3 bg-transparent"
                                    onClick={() => episode.status === "completed" ? setShowReportModal(episode) : setViewingEpisode(episode)}
                                  >
                                    {episode.status === "completed" ? (
                                      <>
                                        <FileText className="h-4 w-4 mr-2" />
                                        Bericht anzeigen
                                      </>
                                    ) : (
                                      <>
                                        <Eye className="h-4 w-4 mr-2" />
                                        Szenen verwalten
                                      </>
                                    )}
                                  </Button>
                                </CardContent>
                              </>
                            )}
                          </Card>
                        )
                      })}
                    </div>
                  </TabsContent>
                ))}
              </Tabs>
            </TabsContent>
          ))}
        </Tabs>
      )}

      <EpisodeForm open={showForm} onOpenChange={handleFormClose} episode={editingEpisode} />

      {viewingEpisode && (
        <EpisodeDetail
          open={!!viewingEpisode}
          onOpenChange={(open) => !open && setViewingEpisode(undefined)}
          episode={viewingEpisode}
        />
      )}

      {showReportModal && (
        <EventReportModal
          open={!!showReportModal}
          onOpenChange={(open) => !open && setShowReportModal(undefined)}
          event={showReportModal}
        />
      )}

      <AlertDialog open={!!deleteConfirm} onOpenChange={(open) => !open && setDeleteConfirm(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Event löschen?</AlertDialogTitle>
            <AlertDialogDescription>
              Diese Aktion kann nicht rückgängig gemacht werden. Die Szenen werden nicht gelöscht.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Abbrechen</AlertDialogCancel>
            <AlertDialogAction onClick={() => deleteConfirm && handleDelete(deleteConfirm)}>Löschen</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}
