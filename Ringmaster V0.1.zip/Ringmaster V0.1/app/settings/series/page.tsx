"use client"

import { useState, useEffect } from "react"
import { useSeries } from "@/lib/series-context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { ImageCropper } from "@/components/image-cropper"
import { Upload, X, Save, Tv, Edit } from "lucide-react"

const genreOptions = [
  "Drama", "Comedy", "Thriller", "Sci-Fi", "Fantasy", "Horror",
  "Romance", "Action", "Mystery", "Crime", "Documentary"
]

export default function SeriesTab() {
  const { data, updateSeries, uploadCoverImage, getCoverImageUrl } = useSeries()
  const [title, setTitle] = useState((data.series && data.series.length > 0) ? data.series[0].title : "")
  const [logline, setLogline] = useState((data.series && data.series.length > 0) ? data.series[0].logline : "")
  const [selectedGenres, setSelectedGenres] = useState<string[]>((data.series && data.series.length > 0) ? data.series[0].genre || [] : [])
  const [coverImageUrl, setCoverImageUrl] = useState<string | null>(null)
  const [isUploading, setIsUploading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [showCropper, setShowCropper] = useState(false)
  const [selectedImageFile, setSelectedImageFile] = useState<File | null>(null)
  const [imagePreviewUrl, setImagePreviewUrl] = useState<string | null>(null)

  // Load cover image URL on mount
  useEffect(() => {
    let isMounted = true

    const loadCoverImage = async () => {
      if (data.series && data.series.length > 0) {
        // Revoke previous URL to prevent memory leaks
        if (coverImageUrl && coverImageUrl.startsWith('blob:')) {
          URL.revokeObjectURL(coverImageUrl)
        }

        const newUrl = await getCoverImageUrl(data.series[0])
        if (isMounted) {
          setCoverImageUrl(newUrl)
        }
      }
    }

    loadCoverImage()

    return () => {
      isMounted = false
    }
  }, [data.series, getCoverImageUrl])

  // Cleanup URL on unmount
  useEffect(() => {
    return () => {
      if (coverImageUrl && coverImageUrl.startsWith('blob:')) {
        URL.revokeObjectURL(coverImageUrl)
      }
    }
  }, [])

  const toggleGenre = (genre: string) => {
    setSelectedGenres(prev =>
      prev.includes(genre)
        ? prev.filter(g => g !== genre)
        : [...prev, genre]
    )
  }

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    setSelectedImageFile(file)
    // Create preview URL for cropping
    const previewUrl = URL.createObjectURL(file)
    setImagePreviewUrl(previewUrl)
    setShowCropper(true)

    // Reset the input
    event.target.value = ''
  }

  const handleCropComplete = async (croppedBlob: Blob) => {
    setIsUploading(true)
    try {
      await uploadCoverImage(new File([croppedBlob], 'cover.jpg', { type: 'image/jpeg' }))

      // Reload the cover image URL to show the new image immediately
      if (data.series && data.series.length > 0) {
        const newUrl = await getCoverImageUrl(data.series[0])
        setCoverImageUrl(newUrl)
      }

      // Clean up
      if (imagePreviewUrl) {
        URL.revokeObjectURL(imagePreviewUrl)
        setImagePreviewUrl(null)
      }
      setSelectedImageFile(null)
      setIsUploading(false)

      // Show success message for image upload
      setSuccess(true)
      setTimeout(() => setSuccess(false), 3000)
    } catch (error) {
      console.error("Error uploading cropped image:", error)
      setIsUploading(false)
    }
  }

  const removeImage = () => {
    if (data.series && data.series.length > 0) {
      updateSeries({
        ...data.series[0],
        coverImageBlobId: undefined,
        coverImageUrl: undefined
      })
      setCoverImageUrl(null)
    }
  }

  const handleSave = () => {
    if (!data.series || data.series.length === 0) return

    updateSeries({
      ...data.series[0],
      title: title.trim(),
      logline: logline.trim(),
      genre: selectedGenres,
      coverImageBlobId: data.series[0].coverImageBlobId, // Explicitly preserve the blob ID
      coverImageUrl: data.series[0].coverImageUrl // Explicitly preserve the URL
    })

    setSuccess(true)
    setTimeout(() => setSuccess(false), 3000)
  }

  if (!data.series || data.series.length === 0) {
    return (
      <div className="text-center py-12">
        <Tv className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
        <h3 className="text-lg font-medium mb-2">Keine Serie gefunden</h3>
        <p className="text-muted-foreground">
          Erstelle zuerst eine Serie, bevor du sie bearbeiten kannst.
        </p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Serie bearbeiten</CardTitle>
          <CardDescription>
            Bearbeite die grundlegenden Informationen deiner Serie
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {success && (
            <Alert className="border-green-200 bg-green-50">
              <AlertDescription className="text-green-800">
                Serie erfolgreich gespeichert!
              </AlertDescription>
            </Alert>
          )}

          <div className="space-y-2">
            <Label htmlFor="title">Titel der Serie</Label>
            <Input
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="z.B. GZSZ 1992"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="logline">Logline</Label>
            <Textarea
              id="logline"
              value={logline}
              onChange={(e) => setLogline(e.target.value)}
              placeholder="Eine kurze Zusammenfassung der Serie in 1-2 Sätzen..."
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label>Genres</Label>
            <div className="flex flex-wrap gap-2">
              {genreOptions.map((genre) => (
                <Badge
                  key={genre}
                  variant={selectedGenres.includes(genre) ? "default" : "outline"}
                  className="cursor-pointer hover:bg-primary/80"
                  onClick={() => toggleGenre(genre)}
                >
                  {genre}
                </Badge>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Label>Cover-Bild</Label>
            {coverImageUrl ? (
              <div className="relative group">
                <img
                  src={coverImageUrl}
                  alt="Serie Cover"
                  className="w-full h-48 object-cover rounded-lg border"
                />
                <div className="absolute top-2 right-2 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <Button
                    variant="secondary"
                    size="sm"
                    onClick={() => setShowCropper(true)}
                    className="bg-white/90 hover:bg-white"
                  >
                    <Edit className="h-4 w-4 mr-1" />
                    Bearbeiten
                  </Button>
                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={removeImage}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ) : (
              <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-8 text-center">
                <Upload className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
                <p className="text-sm text-muted-foreground mb-4">
                  Ziehe ein Bild hierher oder klicke zum Auswählen
                </p>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                  id="cover-upload"
                  disabled={isUploading}
                />
                <Label htmlFor="cover-upload">
                  <Button variant="outline" disabled={isUploading} asChild>
                    <span>
                      {isUploading ? "Lädt..." : "Bild auswählen"}
                    </span>
                  </Button>
                </Label>
              </div>
            )}
          </div>

          <Button onClick={handleSave} className="w-full" disabled={!title.trim()}>
            <Save className="h-4 w-4 mr-2" />
            Änderungen speichern
          </Button>
        </CardContent>
      </Card>

      {/* Image Cropper Dialog */}
      <ImageCropper
        open={showCropper}
        onOpenChange={(open) => {
          setShowCropper(open)
          if (!open) {
            // Clean up when closing
            if (imagePreviewUrl) {
              URL.revokeObjectURL(imagePreviewUrl)
              setImagePreviewUrl(null)
            }
            setSelectedImageFile(null)
          }
        }}
        imageSrc={imagePreviewUrl || ''}
        onCropComplete={handleCropComplete}
        aspect={1183/180} // Banner aspect ratio (1183x180 pixels)
      />
    </div>
  )
}