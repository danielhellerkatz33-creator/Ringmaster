"use client"

import { useState, useEffect } from "react"
import { useSeries } from "@/lib/series-context"
import { indexedDBStorage } from "@/lib/indexeddb-storage"
import type { Arena } from "@/lib/types"
import { PageHeader } from "@/components/page-header"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { 
  Settings, 
  Users, 
  Calendar, 
  Trophy, 
  BarChart3,
  Building,
  Tv,
  Plus,
  Edit,
  Upload,
  MapPin,
  X,
  Trash2,
} from "lucide-react"
import { ImageCropper } from "@/components/image-cropper"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"

export default function GameCenterPage() {
  const { data, addPromotion, updatePromotion, addArena, updateArena, deleteArena, addShow, updateShow, deleteShow } = useSeries()
  const [promotionName, setPromotionName] = useState("")
  const [foundedYear, setFoundedYear] = useState("")
  const [owner, setOwner] = useState("")
  const [success, setSuccess] = useState(false)
  const [isUploading, setIsUploading] = useState(false)
  const [showCropper, setShowCropper] = useState(false)
  const [selectedImageFile, setSelectedImageFile] = useState<File | null>(null)
  const [imagePreviewUrl, setImagePreviewUrl] = useState<string | null>(null)

  // Arena Management State
  const [arenaName, setArenaName] = useState("")
  const [arenaLocation, setArenaLocation] = useState("")
  const [arenaCapacity, setArenaCapacity] = useState("")
  const [editingArena, setEditingArena] = useState<string | null>(null)
  const [showArenaDialog, setShowArenaDialog] = useState(false)

  // Show Management State
  const [showName, setShowName] = useState("")
  const [showType, setShowType] = useState<"weekly" | "ppv" | "special">("weekly")
  const [showFrequency, setShowFrequency] = useState<"weekly" | "bi_weekly" | "monthly" | "quarterly" | "yearly">("weekly")
  const [showDescription, setShowDescription] = useState("")
  const [showDuration, setShowDuration] = useState("")
  const [editingShow, setEditingShow] = useState<string | null>(null)
  const [showShowDialog, setShowShowDialog] = useState(false)

  // Load existing promotion data
  useEffect(() => {
    console.log('useEffect triggered, data.promotions:', data.promotions)
    if (data.promotions && data.promotions.length > 0) {
      const promotion = data.promotions[0]
      console.log('Loading promotion data:', promotion)
      setPromotionName(promotion.name || "")
      setFoundedYear(promotion.foundedYear || "")
      setOwner(promotion.owner || "")
    } else {
      console.log('No promotions found, setting defaults')
      setPromotionName("")
      setFoundedYear("")
      setOwner("")
    }
  }, [data.promotions])

  const handleSavePromotion = () => {
    console.log('handleSavePromotion called')
    console.log('promotionName:', promotionName)
    console.log('data.promotions:', data.promotions)
    
    if (!promotionName.trim()) {
      console.log('No promotion name, returning')
      return
    }

    const promotionData = {
      name: promotionName.trim(),
      foundedYear: foundedYear.trim(),
      owner: owner.trim(),
    }

    console.log('promotionData:', promotionData)

    if (data.promotions && data.promotions.length > 0) {
      // Update existing promotion
      console.log('Updating existing promotion:', data.promotions[0].id)
      updatePromotion({
        ...data.promotions[0],
        ...promotionData,
      })
    } else {
      // Create new promotion
      console.log('Creating new promotion')
      addPromotion(promotionData)
    }

    setSuccess(true)
    setTimeout(() => setSuccess(false), 3000)
  }

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    setSelectedImageFile(file)
    // Create preview URL for cropping
    const previewUrl = URL.createObjectURL(file)
    setImagePreviewUrl(previewUrl)
    setShowCropper(true)

    // Reset the input
    event.target.value = ''
  }

  const handleCropComplete = async (croppedBlob: Blob) => {
    setIsUploading(true)
    try {
      // Convert blob to base64
      const base64 = await new Promise<string>((resolve) => {
        const reader = new FileReader()
        reader.onloadend = () => resolve(reader.result as string)
        reader.readAsDataURL(croppedBlob)
      })

      // Update promotion with base64 logo
      if (data.promotions && data.promotions.length > 0) {
        updatePromotion({
          ...data.promotions[0],
          logoBase64: base64,
        })
      } else {
        addPromotion({
          name: promotionName.trim(),
          foundedYear: foundedYear.trim(),
          owner: owner.trim(),
          logoBase64: base64,
        })
      }

      // Clean up
      if (imagePreviewUrl) {
        URL.revokeObjectURL(imagePreviewUrl)
        setImagePreviewUrl(null)
      }
      setSelectedImageFile(null)
      setIsUploading(false)

      // Show success message for image upload
      setSuccess(true)
      setTimeout(() => setSuccess(false), 3000)
    } catch (error) {
      console.error("Error uploading cropped image:", error)
      setIsUploading(false)
    }
  }

  const removeLogo = () => {
    if (data.promotions && data.promotions.length > 0) {
      updatePromotion({
        ...data.promotions[0],
        logoBase64: undefined,
      })
    }
  }

  // Arena Management Functions
  const handleAddArena = () => {
    setArenaName("")
    setArenaLocation("")
    setArenaCapacity("")
    setEditingArena(null)
    setShowArenaDialog(true)
  }

  const handleEditArena = (arena: Arena) => {
    setArenaName(arena.name)
    setArenaLocation(arena.location)
    setArenaCapacity(arena.capacity.toString())
    setEditingArena(arena.id)
    setShowArenaDialog(true)
  }

  const handleSaveArena = () => {
    if (!arenaName.trim() || !arenaLocation.trim() || !arenaCapacity.trim()) {
      return
    }

    const arenaData = {
      name: arenaName.trim(),
      location: arenaLocation.trim(),
      capacity: parseInt(arenaCapacity),
    }

    console.log('Saving arena:', arenaData)

    if (editingArena) {
      updateArena({
        ...arenaData,
        id: editingArena,
        createdAt: new Date(),
        updatedAt: new Date(),
      })
    } else {
      addArena(arenaData)
    }

    setShowArenaDialog(false)
    setArenaName("")
    setArenaLocation("")
    setArenaCapacity("")
    setEditingArena(null)
  }

  const handleDeleteArena = (arenaId: string) => {
    if (confirm("Möchten Sie diese Arena wirklich löschen?")) {
      deleteArena(arenaId)
    }
  }

  // Show Management Functions
  const handleAddShow = () => {
    setShowName("")
    setShowType("weekly")
    setShowFrequency("weekly")
    setShowDescription("")
    setShowDuration("")
    setEditingShow(null)
    setShowShowDialog(true)
  }

  // Extract shows from existing events
  const getShowsFromEvents = () => {
    if (!data.episodes || data.episodes.length === 0) return []
    
    const eventMap = new Map<string, { title: string; type: string; count: number }>()
    
    data.episodes.forEach(event => {
      const key = event.title.toLowerCase()
      if (eventMap.has(key)) {
        eventMap.get(key)!.count++
      } else {
        eventMap.set(key, {
          title: event.title,
          type: event.eventType,
          count: 1
        })
      }
    })
    
    return Array.from(eventMap.values()).map(event => ({
      ...event,
      // Get current duration from state-of-the-art logic
      currentDuration: getCurrentDurationForEvent(event.title, event.type)
    }))
  }

  // Get current duration for an event title (mimics state-of-the-art logic)
  const getCurrentDurationForEvent = (title: string, eventType: string): number => {
    if (title.toLowerCase().includes("nwa main event")) {
      return 60
    }
    if (title.toLowerCase().includes("world championship wrestling")) {
      return 90
    }
    
    switch (eventType) {
      case "Weekly TV":
        return 120
      case "PPV":
        return 180
      case "TV-Special":
        return 120
      default:
        return 120
    }
  }

  // Create show from event
  const handleCreateShowFromEvent = (eventData: any) => {
    setShowName(eventData.title)
    setShowType(eventData.type === "Weekly TV" ? "weekly" : eventData.type === "PPV" ? "ppv" : "special")
    setShowFrequency("weekly")
    setShowDescription(`Automatisch erstellt aus ${eventData.count} Events`)
    setShowDuration(eventData.currentDuration.toString())
    setEditingShow(null)
    setShowShowDialog(true)
  }

  const handleEditShow = (show: any) => {
    setShowName(show.name)
    setShowType(show.type)
    setShowFrequency(show.frequency || "weekly")
    setShowDescription(show.description || "")
    setShowDuration(show.defaultDuration?.toString() || "")
    setEditingShow(show.id)
    setShowShowDialog(true)
  }

  const handleSaveShow = () => {
    if (!showName.trim() || !showDuration.trim()) {
      return
    }

    const showData = {
      name: showName.trim(),
      type: showType,
      frequency: showFrequency,
      description: showDescription.trim(),
      defaultDuration: parseInt(showDuration),
    }

    console.log('Saving show:', showData)

    if (editingShow) {
      updateShow({
        ...showData,
        id: editingShow,
        createdAt: new Date(),
        updatedAt: new Date(),
      })
    } else {
      addShow(showData)
    }

    setShowShowDialog(false)
    setShowName("")
    setShowType("weekly")
    setShowFrequency("weekly")
    setShowDescription("")
    setShowDuration("")
    setEditingShow(null)
  }

  const handleDeleteShow = (showId: string) => {
    if (confirm("Möchten Sie diese Show wirklich löschen?")) {
      deleteShow(showId)
    }
  }

  return (
    <>
      <PageHeader
        title="🎮 Game Center"
        description="Zentrale Verwaltungseinstellungen für deine Wrestling-Promotion"
      />

      {/* 📊 QUICK STATS */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
          📊 Quick Stats
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
            <CardContent className="p-4 text-center">
              <Users className="h-8 w-8 mx-auto mb-2 text-blue-600" />
              <div className="text-2xl font-bold text-blue-900">{data.characters?.length || 0}</div>
              <div className="text-sm text-blue-700">Wrestler</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
            <CardContent className="p-4 text-center">
              <Calendar className="h-8 w-8 mx-auto mb-2 text-green-600" />
              <div className="text-2xl font-bold text-green-900">{data.episodes?.length || 0}</div>
              <div className="text-sm text-green-700">Events</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
            <CardContent className="p-4 text-center">
              <Trophy className="h-8 w-8 mx-auto mb-2 text-purple-600" />
              <div className="text-2xl font-bold text-purple-900">{data.characterArcs?.length || 0}</div>
              <div className="text-sm text-purple-700">Titles</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-orange-50 to-orange-100 border-orange-200">
            <CardContent className="p-4 text-center">
              <Tv className="h-8 w-8 mx-auto mb-2 text-orange-600" />
              <div className="text-2xl font-bold text-orange-900">3</div>
              <div className="text-sm text-orange-700">Shows</div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* 🏢 PROMOTION SETTINGS */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
          🏢 Promotion Settings
        </h2>
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Building className="h-5 w-5" />
              Promotion Information
            </CardTitle>
            <CardDescription>
              Konfiguriere die grundlegenden Informationen deiner Wrestling-Promotion
            </CardDescription>
          </CardHeader>
          <CardContent>
            {success && (
              <div className="mb-4 p-3 bg-green-50 border border-green-200 rounded-lg">
                <div className="text-green-800 text-sm font-medium">✅ Promotion erfolgreich gespeichert!</div>
              </div>
            )}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="promotion-name">Promotion Name</Label>
                  <Input
                    id="promotion-name"
                    value={promotionName}
                    onChange={(e) => setPromotionName(e.target.value)}
                    placeholder="z.B. Ringmaster Pro"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="founded-year">Founded Year</Label>
                  <Input
                    id="founded-year"
                    value={foundedYear}
                    onChange={(e) => setFoundedYear(e.target.value)}
                    placeholder="z.B. 2024"
                  />
                </div>
              </div>
              
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="owner">Owner</Label>
                  <Input
                    id="owner"
                    value={owner}
                    onChange={(e) => setOwner(e.target.value)}
                    placeholder="Dein Name"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label>Logo</Label>
                  {data.promotions && data.promotions.length > 0 && data.promotions[0].logoBase64 ? (
                    <div className="relative group">
                      <img
                        src={data.promotions[0].logoBase64}
                        alt="Promotion Logo"
                        className="w-full h-32 object-cover rounded-lg border"
                      />
                      <div className="absolute top-2 right-2 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <Button
                          variant="secondary"
                          size="sm"
                          onClick={() => setShowCropper(true)}
                          className="bg-white/90 hover:bg-white"
                        >
                          <Edit className="h-4 w-4 mr-1" />
                          Bearbeiten
                        </Button>
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={removeLogo}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-8 text-center">
                      <Upload className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
                      <p className="text-sm text-muted-foreground mb-4">
                        Ziehe ein Logo hierher oder klicke zum Auswählen
                      </p>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleImageUpload}
                        className="hidden"
                        id="logo-upload"
                        disabled={isUploading}
                      />
                      <Label htmlFor="logo-upload">
                        <Button variant="outline" disabled={isUploading} asChild>
                          <span>
                            {isUploading ? "Lädt..." : "Logo auswählen"}
                          </span>
                        </Button>
                      </Label>
                    </div>
                  )}
                </div>
              </div>
            </div>
            
            <div className="mt-6 pt-6 border-t">
              <Button className="w-full" onClick={handleSavePromotion}>
                <Settings className="h-4 w-4 mr-2" />
                Save Promotion Settings
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 🏟️ ARENA MANAGEMENT */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
          🏟️ Arena Management
        </h2>
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="h-5 w-5" />
              Veranstaltungsorte
            </CardTitle>
            <CardDescription>
              Verwalte die Arenen für deine Wrestling-Events
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-medium">Deine Arenen</h3>
                <Button onClick={handleAddArena} size="sm">
                  <Plus className="h-4 w-4 mr-2" />
                  Arena hinzufügen
                </Button>
              </div>
              
              {data.arenas && data.arenas.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {data.arenas.map((arena) => (
                    <div key={arena.id} className="p-4 border rounded-lg bg-muted/50 hover:bg-muted/70 transition-colors">
                      <div className="flex justify-between items-start mb-2">
                        <h4 className="font-medium">{arena.name}</h4>
                        <Badge variant="secondary">{arena.location}</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mb-3">Kapazität: {arena.capacity.toLocaleString()}</p>
                      <div className="flex gap-2">
                        <Button 
                          variant="outline" 
                          size="sm" 
                          onClick={() => handleEditArena(arena)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="destructive" 
                          size="sm" 
                          onClick={() => handleDeleteArena(arena.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <MapPin className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <h4 className="text-lg font-medium mb-2">Keine Arenen vorhanden</h4>
                  <p className="text-muted-foreground mb-4">
                    Füge deine erste Arena hinzu, um Events zu veranstalten
                  </p>
                  <Button onClick={handleAddArena}>
                    <Plus className="h-4 w-4 mr-2" />
                    Erste Arena erstellen
                  </Button>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 📺 SHOW MANAGEMENT */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
          📺 Show Management
        </h2>
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Tv className="h-5 w-5" />
              Shows & Laufzeiten
            </CardTitle>
            <CardDescription>
              Verwalte deine Shows und deren Standard-Laufzeiten
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {/* Existing Shows */}
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-medium">Konfigurierte Shows</h3>
                  <Button onClick={handleAddShow} size="sm">
                    <Plus className="h-4 w-4 mr-2" />
                    Show hinzufügen
                  </Button>
                </div>
                
                {data.shows && data.shows.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {data.shows.map((show) => (
                      <div key={show.id} className="p-4 border rounded-lg bg-muted/50 hover:bg-muted/70 transition-colors">
                        <div className="flex justify-between items-start mb-2">
                          <h4 className="font-medium">{show.name}</h4>
                          <div className="flex gap-1">
                            <Badge variant="secondary">{show.type}</Badge>
                            {show.defaultDuration && (
                              <Badge variant="outline">{show.defaultDuration} Min.</Badge>
                            )}
                          </div>
                        </div>
                        <p className="text-sm text-muted-foreground mb-1">
                          Typ: {show.type}
                          {show.frequency && ` • ${show.frequency}`}
                        </p>
                        {show.description && (
                          <p className="text-sm text-muted-foreground mb-3">{show.description}</p>
                        )}
                        {show.defaultDuration && (
                          <p className="text-sm font-medium mb-3">
                            Standard-Laufzeit: {show.defaultDuration} Minuten
                          </p>
                        )}
                        <div className="flex gap-2">
                          <Button 
                            variant="outline" 
                            size="sm" 
                            onClick={() => handleEditShow(show)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="destructive" 
                            size="sm" 
                            onClick={() => handleDeleteShow(show.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-4">
                    <p className="text-muted-foreground">Noch keine Shows konfiguriert</p>
                  </div>
                )}
              </div>

              {/* Detected Shows from Events */}
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-medium">Gefundene Shows aus Events</h3>
                  <Badge variant="secondary">
                    {getShowsFromEvents().length} Shows gefunden
                  </Badge>
                </div>
                
                {getShowsFromEvents().length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {getShowsFromEvents().map((eventShow, index) => {
                      const isConfigured = data.shows?.some(show => 
                        show.name.toLowerCase() === eventShow.title.toLowerCase()
                      )
                      
                      return (
                        <div key={index} className="p-4 border rounded-lg bg-orange-50/50 hover:bg-orange-50/70 transition-colors">
                          <div className="flex justify-between items-start mb-2">
                            <h4 className="font-medium">{eventShow.title}</h4>
                            <div className="flex gap-1">
                              <Badge variant="secondary">{eventShow.type}</Badge>
                              <Badge variant="outline">{eventShow.currentDuration} Min.</Badge>
                              {isConfigured && (
                                <Badge variant="default" className="bg-green-100 text-green-800">
                                  Konfiguriert
                                </Badge>
                              )}
                            </div>
                          </div>
                          <p className="text-sm text-muted-foreground mb-2">
                            {eventShow.count} Events gefunden
                          </p>
                          <p className="text-sm font-medium mb-3">
                            Aktuelle Laufzeit: {eventShow.currentDuration} Minuten
                          </p>
                          {!isConfigured && (
                            <Button 
                              size="sm" 
                              onClick={() => handleCreateShowFromEvent(eventShow)}
                              className="w-full"
                            >
                              <Plus className="h-4 w-4 mr-2" />
                              Show erstellen
                            </Button>
                          )}
                          {isConfigured && (
                            <div className="text-center text-sm text-green-600 font-medium">
                              ✅ Bereits konfiguriert
                            </div>
                          )}
                        </div>
                      )
                    })}
                  </div>
                ) : (
                  <div className="text-center py-4">
                    <p className="text-muted-foreground">Keine Events mit Shows gefunden</p>
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Image Cropper Dialog */}
      <ImageCropper
        open={showCropper}
        onOpenChange={(open) => {
          setShowCropper(open)
          if (!open) {
            // Clean up when closing
            if (imagePreviewUrl) {
              URL.revokeObjectURL(imagePreviewUrl)
              setImagePreviewUrl(null)
            }
            setSelectedImageFile(null)
          }
        }}
        imageSrc={imagePreviewUrl || ''}
        onCropComplete={handleCropComplete}
        aspect={1} // Square aspect ratio for logo
      />

      {/* Arena Dialog */}
      <Dialog open={showArenaDialog} onOpenChange={setShowArenaDialog}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>
              {editingArena ? "Arena bearbeiten" : "Neue Arena erstellen"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="arena-name">Arena Name</Label>
              <Input
                id="arena-name"
                value={arenaName}
                onChange={(e) => setArenaName(e.target.value)}
                placeholder="z.B. Madison Square Garden"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="arena-location">Standort</Label>
              <Input
                id="arena-location"
                value={arenaLocation}
                onChange={(e) => setArenaLocation(e.target.value)}
                placeholder="z.B. New York, NY"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="arena-capacity">Kapazität</Label>
              <Input
                id="arena-capacity"
                type="number"
                value={arenaCapacity}
                onChange={(e) => setArenaCapacity(e.target.value)}
                placeholder="z.B. 20000"
              />
            </div>
          </div>
          
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setShowArenaDialog(false)}>
              Abbrechen
            </Button>
            <Button onClick={handleSaveArena}>
              {editingArena ? "Speichern" : "Erstellen"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Show Dialog */}
      <Dialog open={showShowDialog} onOpenChange={setShowShowDialog}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>
              {editingShow ? "Show bearbeiten" : "Neue Show erstellen"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="show-name">Show Name</Label>
              <Input
                id="show-name"
                value={showName}
                onChange={(e) => setShowName(e.target.value)}
                placeholder="z.B. World Championship Wrestling"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="show-type">Show Typ</Label>
              <select
                id="show-type"
                value={showType}
                onChange={(e) => setShowType(e.target.value as "weekly" | "ppv" | "special")}
                className="w-full p-2 border rounded-md"
              >
                <option value="weekly">Weekly TV</option>
                <option value="ppv">PPV</option>
                <option value="special">TV-Special</option>
              </select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="show-frequency">Frequenz</Label>
              <select
                id="show-frequency"
                value={showFrequency}
                onChange={(e) => setShowFrequency(e.target.value as any)}
                className="w-full p-2 border rounded-md"
              >
                <option value="weekly">Wöchentlich</option>
                <option value="bi_weekly">2-wöchentlich</option>
                <option value="monthly">Monatlich</option>
                <option value="quarterly">Vierteljährlich</option>
                <option value="yearly">Jährlich</option>
              </select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="show-duration">Standard-Laufzeit (Minuten)</Label>
              <Input
                id="show-duration"
                type="number"
                min="30"
                max="300"
                value={showDuration}
                onChange={(e) => setShowDuration(e.target.value)}
                placeholder="z.B. 90"
              />
              <p className="text-xs text-muted-foreground">
                Diese Laufzeit wird im State of The Art Bericht verwendet
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="show-description">Beschreibung (optional)</Label>
              <textarea
                id="show-description"
                value={showDescription}
                onChange={(e) => setShowDescription(e.target.value)}
                placeholder="z.B. Wöchentliche Hauptshow der Promotion"
                className="w-full p-2 border rounded-md min-h-[80px]"
              />
            </div>
          </div>
          
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setShowShowDialog(false)}>
              Abbrechen
            </Button>
            <Button onClick={handleSaveShow}>
              {editingShow ? "Speichern" : "Erstellen"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}