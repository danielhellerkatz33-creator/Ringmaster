"use client"

import { useState } from "react"
import { useSeries } from "@/lib/series-context"
import { EmptyState } from "@/components/empty-state"
import { LocationForm } from "@/components/location-form"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Plus, MapPin, Search } from "lucide-react"
import type { Location } from "@/lib/types"

export default function LocationsTab() {
  const { data, isLoading, deleteLocation } = useSeries()
  const [showForm, setShowForm] = useState(false)
  const [editingLocation, setEditingLocation] = useState<Location | undefined>()
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null)
  const [search, setSearch] = useState("")

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-pulse text-muted-foreground">Lade Drehorte...</div>
      </div>
    )
  }

  const filteredLocations = data.locations.filter((location) =>
    location.name.toLowerCase().includes(search.toLowerCase()) ||
    location.description.toLowerCase().includes(search.toLowerCase())
  )

  const handleEdit = (location: Location) => {
    setEditingLocation(location)
    setShowForm(true)
  }

  const handleDelete = (id: string) => {
    deleteLocation(id)
    setDeleteConfirm(null)
  }

  const handleFormClose = (open: boolean) => {
    setShowForm(open)
    if (!open) setEditingLocation(undefined)
  }

  return (
    <>
      {/* Header with Action */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex gap-4 flex-1 max-w-sm">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Drehorte suchen..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9"
            />
          </div>
        </div>
        <Button onClick={() => setShowForm(true)} className="gap-2">
          <Plus className="h-4 w-4" />
          Neuer Drehort
        </Button>
      </div>

      {/* Content */}
      {filteredLocations.length === 0 ? (
        <EmptyState
          icon={MapPin}
          title={search ? "Keine Drehorte gefunden" : "Noch keine Drehorte"}
          description={
            search
              ? "Versuche andere Suchkriterien."
              : "Erstelle deinen ersten Drehort, um mit der Planung zu beginnen."
          }
          actionLabel={!search ? "Ersten Drehort erstellen" : undefined}
          onAction={!search ? () => setShowForm(true) : undefined}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredLocations.map((location) => (
            <div
              key={location.id}
              className="p-4 border rounded-lg hover:bg-muted/50 transition-colors"
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="font-medium">{location.name}</h3>
                    <span className={`px-2 py-1 rounded-full text-xs ${
                      location.isActive
                        ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                        : 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200'
                    }`}>
                      {location.isActive ? 'Aktiv' : 'Inaktiv'}
                    </span>
                  </div>
                  {location.description && (
                    <p className="text-sm text-muted-foreground mb-3">
                      {location.description}
                    </p>
                  )}
                </div>
              </div>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleEdit(location)}
                >
                  Bearbeiten
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setDeleteConfirm(location.id)}
                  className="text-destructive hover:text-destructive"
                >
                  Löschen
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Location Form */}
      <LocationForm open={showForm} onOpenChange={handleFormClose} location={editingLocation} />

      <AlertDialog open={!!deleteConfirm} onOpenChange={(open) => !open && setDeleteConfirm(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Drehort löschen?</AlertDialogTitle>
            <AlertDialogDescription>
              Diese Aktion kann nicht rückgängig gemacht werden.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Abbrechen</AlertDialogCancel>
            <AlertDialogAction onClick={() => deleteConfirm && handleDelete(deleteConfirm)}>Löschen</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}