"use client"

import { useState } from "react"
import { useSeries } from "@/lib/series-context"
import { PageHeader } from "@/components/page-header"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Calendar } from "@/components/ui/calendar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { CalendarCheck, Users, AlertCircle, Clock } from "lucide-react"
import { format } from "date-fns"
import { de } from "date-fns/locale"
import type { Character } from "@/lib/types"
import { CharacterAvatar } from "@/components/character-avatar"

export default function ContractAvailabilityPage() {
  const { data, isLoading, updateCharacter } = useSeries()
  const [openCalendarId, setOpenCalendarId] = useState<string | null>(null)

  // Filter wrestlers to exclude "inactive" and "retired" status and sort by contract availability date
  const activeWrestlers = [...(data.characters || [])]
    .filter((character: Character) => character.status !== "inactive" && character.status !== "retired")
    .sort((a, b) => {
      const dateA = a.contractAvailableUntil ? new Date(a.contractAvailableUntil).getTime() : Infinity
      const dateB = b.contractAvailableUntil ? new Date(b.contractAvailableUntil).getTime() : Infinity
      // Sort by date (oldest first), wrestlers without dates go to the end
      return dateA - dateB
    })

  // Filter inactive wrestlers (excluding retired) and sort by contract availability date
  const inactiveWrestlers = [...(data.characters || [])]
    .filter((character: Character) => character.status === "inactive")
    .sort((a, b) => {
      const dateA = a.contractAvailableUntil ? new Date(a.contractAvailableUntil).getTime() : Infinity
      const dateB = b.contractAvailableUntil ? new Date(b.contractAvailableUntil).getTime() : Infinity
      // Sort by date (oldest first), wrestlers without dates go to the end
      return dateA - dateB
    })

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-500"
      case "injured":
        return "bg-yellow-500"
      case "suspended":
        return "bg-orange-500"
      case "retired":
        return "bg-gray-500"
      default:
        return "bg-gray-400"
    }
  }

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case "active":
        return "default"
      case "injured":
        return "secondary"
      case "suspended":
        return "outline"
      case "retired":
        return "outline"
      default:
        return "outline"
    }
  }

  const handleDateSelect = (characterId: string, date: Date | undefined) => {
    const character = data.characters.find((c: Character) => c.id === characterId)
    if (character) {
      updateCharacter({
        ...character,
        contractAvailableUntil: date || undefined,
        updatedAt: new Date()
      })
    }
    setOpenCalendarId(null)
  }

  const clearAvailabilityDate = (characterId: string) => {
    const character = data.characters.find((c: Character) => c.id === characterId)
    if (character) {
      updateCharacter({
        ...character,
        contractAvailableUntil: undefined,
        updatedAt: new Date()
      })
    }
  }

  const getAvailabilityForCharacter = (characterId: string) => {
    const character = data.characters.find((c: Character) => c.id === characterId)
    return character?.contractAvailableUntil
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-pulse text-muted-foreground">Lädt...</div>
      </div>
    )
  }

  return (
    <>
      <PageHeader
        title="Contract Availability"
        description="Vertragsstatus und Verfügbarkeit der Wrestler"
      />

      <div className="space-y-6">
        <Tabs defaultValue="active" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="active" className="flex items-center gap-2">
              <CalendarCheck className="h-4 w-4" />
              Active Contracts ({activeWrestlers.length})
            </TabsTrigger>
            <TabsTrigger value="future" className="flex items-center gap-2">
              <Clock className="h-4 w-4" />
              Future Contracts ({inactiveWrestlers.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="active" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Aktive Wrestler ({activeWrestlers.length})
                </CardTitle>
                <CardDescription>
                  Wrestler mit aktiven Verträgen, sortiert nach Vertragsablauf
                </CardDescription>
              </CardHeader>
              <CardContent>
                {activeWrestlers.length === 0 ? (
                  <div className="text-center py-8">
                    <AlertCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground">Keine aktiven Wrestler gefunden</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {activeWrestlers.map((character: Character) => {
                  const availability = getAvailabilityForCharacter(character.id)
                  
                  return (
                    <div
                      key={character.id}
                      className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                    >
                      <div className="flex items-center gap-4">
                        <CharacterAvatar 
                          name={character.name} 
                          character={character}
                          size="lg"
                        />
                        <div>
                          <h3 className="font-semibold text-lg">{character.name}</h3>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge 
                              variant={getStatusBadgeVariant(character.status)}
                              className="capitalize"
                            >
                              {character.status}
                            </Badge>
                            <Badge variant="outline" className="capitalize">
                              {character.position.replace('_', ' ')}
                            </Badge>
                            <Badge variant="outline" className="capitalize">
                              {character.alignment}
                            </Badge>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-3">
                        <div className="text-right">
                          <p className="text-sm text-muted-foreground">Verfügbar bis:</p>
                          <p className="font-medium">
                            {availability 
                              ? format(availability, "dd. MMMM yyyy", { locale: de })
                              : "Nicht festgelegt"
                            }
                          </p>
                        </div>
                        
                        <div className="flex gap-2">
                          <Popover open={openCalendarId === character.id} onOpenChange={(open) => setOpenCalendarId(open ? character.id : null)}>
                            <PopoverTrigger asChild>
                              <Button variant="outline" size="sm">
                                <CalendarCheck className="h-4 w-4 mr-2" />
                                {availability ? "Ändern" : "Datum setzen"}
                              </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="end">
                              <Calendar
                                mode="single"
                                selected={availability || undefined}
                                onSelect={(date) => handleDateSelect(character.id, date)}
                                defaultMonth={availability || new Date(1988, 0, 1)}
                                locale={de}
                                captionLayout="dropdown"
                                fromYear={1950}
                                toYear={2030}
                              />
                            </PopoverContent>
                          </Popover>
                          
                          {availability && (
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => clearAvailabilityDate(character.id)}
                            >
                              Löschen
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  )
                })}
              </div>
            )}
          </CardContent>
        </Card>
          </TabsContent>

          <TabsContent value="future" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-5 w-5" />
                  Inaktive Wrestler ({inactiveWrestlers.length})
                </CardTitle>
                <CardDescription>
                  Wrestler mit Status "inactive", sortiert nach Vertragsablauf
                </CardDescription>
              </CardHeader>
              <CardContent>
                {inactiveWrestlers.length === 0 ? (
                  <div className="text-center py-8">
                    <AlertCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground">Keine inaktiven Wrestler gefunden</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {inactiveWrestlers.map((character: Character) => {
                      const availability = getAvailabilityForCharacter(character.id)
                      
                      return (
                        <div
                          key={character.id}
                          className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                        >
                          <div className="flex items-center gap-4">
                            <CharacterAvatar 
                              name={character.name} 
                              character={character}
                              size="lg"
                            />
                            <div>
                              <h3 className="font-semibold text-lg">{character.name}</h3>
                              <div className="flex items-center gap-2 mt-1">
                                <Badge 
                                  variant={getStatusBadgeVariant(character.status)}
                                  className="capitalize"
                                >
                                  {character.status}
                                </Badge>
                                <Badge variant="outline" className="capitalize">
                                  {character.position.replace('_', ' ')}
                                </Badge>
                              </div>
                            </div>
                          </div>
                          
                          <div className="flex items-center gap-4">
                            <div className="text-right">
                              <div className="text-sm font-medium">Verfügbar ab</div>
                              <div className="text-lg">
                                {availability ? (
                                  <span className="text-green-600">
                                    {format(availability, "dd.MM.yyyy", { locale: de })}
                                  </span>
                                ) : (
                                  <span className="text-muted-foreground">Nicht festgelegt</span>
                                )}
                              </div>
                            </div>
                            
                            <div className="flex gap-2">
                              <Popover open={openCalendarId === character.id} onOpenChange={(open) => setOpenCalendarId(open ? character.id : null)}>
                                <PopoverTrigger asChild>
                                  <Button variant="outline" size="sm">
                                    <CalendarCheck className="h-4 w-4 mr-2" />
                                    {availability ? "Ändern" : "Datum setzen"}
                                  </Button>
                                </PopoverTrigger>
                                <PopoverContent className="w-auto p-0" align="end">
                                  <Calendar
                                    mode="single"
                                    selected={availability || undefined}
                                    onSelect={(date) => handleDateSelect(character.id, date)}
                                    defaultMonth={availability || new Date(1988, 0, 1)}
                                    locale={de}
                                    captionLayout="dropdown"
                                    fromYear={1950}
                                    toYear={2030}
                                  />
                                </PopoverContent>
                              </Popover>
                              
                              {availability && (
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  onClick={() => clearAvailabilityDate(character.id)}
                                >
                                  Löschen
                                </Button>
                              )}
                            </div>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertCircle className="h-5 w-5" />
              Hinweis
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Diese Seite zeigt alle Wrestler mit ihren Verträgen. 
              Im "Active Contracts" Reiter siehst du aktive Wrestler, im "Future Contracts" Reiter inaktive Wrestler. 
              Sie können für jeden Wrestler ein Verfügbarkeitsdatum festlegen, bis zu dem der Wrestler unter Vertrag steht.
            </p>
          </CardContent>
        </Card>
      </div>
    </>
  )
}
