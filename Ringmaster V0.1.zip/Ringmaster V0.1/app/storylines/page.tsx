"use client"

import { useState } from "react"
import { useSeries } from "@/lib/series-context"
import { PageHeader } from "@/components/page-header"
import { EmptyState } from "@/components/empty-state"
import { StorylineForm } from "@/components/storyline-form"
import { StateOfTheArtReportDialog } from "@/components/state-of-the-art-report"
import { UpgradeModal } from "@/components/upgrade-modal"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Plus, BookOpen, MoreVertical, Pencil, Trash2, BarChart3 } from "lucide-react"
import type { Storyline } from "@/lib/types"
import { CharacterAvatar } from "@/components/character-avatar"
import { canActivateStoryline, getCurrentPlan } from "@/lib/plans"
import { useAuth } from "@/lib/auth-context"

const statusLabels: Record<Storyline["status"], string> = {
  planning: "In Planung",
  active: "Aktiv",
  paused: "Pausiert",
  completed: "Abgeschlossen",
}

const typeLabels: Record<Storyline["type"], string> = {
  main: "Main Story",
  subplot: "Side Story",
}

export default function StorylinesPage() {
  const { data, isLoading, deleteStoryline } = useSeries()
  const { user, isPro } = useAuth()
  const [showForm, setShowForm] = useState(false)
  const [editingStoryline, setEditingStoryline] = useState<Storyline | undefined>()
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null)
  const [showStateOfTheArtReport, setShowStateOfTheArtReport] = useState(false)
  const [showUpgradeModal, setShowUpgradeModal] = useState(false)

  // Check limits with user status
  const currentPlan = getCurrentPlan(isPro)
  const activeStorylinesCount = data.storylines.filter(s => s.status === "active").length
  const canCreate = canActivateStoryline(activeStorylinesCount, isPro)
  const isAtLimit = !canCreate && activeStorylinesCount > 0

  // Debug logging
  console.log('Storylines Debug:')
  console.log('- Total Storylines:', data.storylines.length)
  console.log('- Active Storylines:', activeStorylinesCount)
  console.log('- Current Plan:', currentPlan.name)
  console.log('- Max Active Storylines:', currentPlan.limits.maxActiveStorylines)
  console.log('- Can Create:', canCreate)
  console.log('- Is At Limit:', isAtLimit)
  console.log('- Storyline Details:', data.storylines.map(s => ({ id: s.id, title: s.title, status: s.status })))

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-pulse text-muted-foreground">Lädt Storylines...</div>
      </div>
    )
  }

  const handleEdit = (storyline: Storyline) => {
    setEditingStoryline(storyline)
    setShowForm(true)
  }

  const handleDelete = (id: string) => {
    deleteStoryline(id)
    setDeleteConfirm(null)
  }

  const handleFormClose = (open: boolean) => {
    setShowForm(open)
    if (!open) setEditingStoryline(undefined)
  }

  const handleCreateStoryline = () => {
    if (canCreate) {
      setShowForm(true)
    } else {
      setShowUpgradeModal(true)
    }
  }

  // Group storylines by status
  const groupedStorylines = {
    active: data.storylines.filter((s) => s.status === "active"),
    planning: data.storylines.filter((s) => s.status === "planning"),
    paused: data.storylines.filter((s) => s.status === "paused"),
    completed: data.storylines.filter((s) => s.status === "completed"),
  }

  return (
    <>
      <PageHeader
        title="Storylines"
        description={
          `Aktive Storylines: ${activeStorylinesCount}/${currentPlan.limits.maxActiveStorylines === Infinity ? '∞' : currentPlan.limits.maxActiveStorylines}`
        }
        action={
          <div className="flex gap-2">
            <Button 
              onClick={() => setShowStateOfTheArtReport(true)} 
              variant="outline"
              className="gap-2"
            >
              <BarChart3 className="h-4 w-4" />
              State Of The Art
            </Button>
            <Button 
              onClick={handleCreateStoryline} 
              className="gap-2"
              disabled={!canCreate && !isAtLimit}
              variant={isAtLimit ? "outline" : "default"}
            >
              <Plus className="h-4 w-4" />
              {isAtLimit ? "Upgrade für mehr" : "Neue Storyline"}
            </Button>
          </div>
        }
      />

      {data.storylines.length === 0 ? (
        <EmptyState
          icon={BookOpen}
          title="Noch keine Storylines"
          description="Erstelle Storylines um die Storylines deiner Promotion zu strukturieren."
          actionLabel="Erste Storyline erstellen"
          onAction={handleCreateStoryline}
        />
      ) : (
        <div className="space-y-8">
          {Object.entries(groupedStorylines).map(([status, storylines]) => {
            if (storylines.length === 0) return null
            return (
              <div key={status}>
                <h2 className="text-lg font-semibold text-foreground mb-4">
                  {statusLabels[status as Storyline["status"]]} ({storylines.length})
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {storylines.map((storyline) => {
                    const characters = data.characters
                      .filter((c) => storyline.characterIds.includes(c.id))
                      .sort((a, b) => a.name.localeCompare(b.name))
                    const segments = data.segments.filter((s) => s.storylineIds?.includes(storyline.id) || false)
                    return (
                      <Card key={storyline.id} className="group hover:border-primary/50 transition-colors bg-card">
                        <CardHeader className="flex flex-row items-start justify-between space-y-0 pb-3">
                          <div className="flex items-start gap-3">
                            <div
                              className="h-4 w-4 rounded-full mt-1 shrink-0"
                              style={{ backgroundColor: storyline.color }}
                            />
                            <div>
                              <h3 className="font-semibold text-foreground leading-tight">{storyline.title}</h3>
                              <Badge variant="outline" className="mt-1 text-xs capitalize">
                                {typeLabels[storyline.type]}
                              </Badge>
                            </div>
                          </div>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity"
                              >
                                <MoreVertical className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => handleEdit(storyline)}>
                                <Pencil className="h-4 w-4 mr-2" />
                                Bearbeiten
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                onClick={() => setDeleteConfirm(storyline.id)}
                                className="text-destructive focus:text-destructive"
                              >
                                <Trash2 className="h-4 w-4 mr-2" />
                                Löschen
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </CardHeader>
                        <CardContent className="pt-0">
                          {storyline.description && (
                            <p className="text-sm text-muted-foreground line-clamp-2 mb-3">{storyline.description}</p>
                          )}
                          <div className="flex items-center justify-between text-xs text-muted-foreground mb-3">
                            <span>{characters.length} Charaktere</span>
                            <span>{segments.length} Segmente</span>
                          </div>
                          {characters.length > 0 && (
                            <div className="flex -space-x-2">
                              {characters.slice(0, 4).map((char) => (
                                <CharacterAvatar
                                  key={char.id}
                                  character={char}
                                  size="sm"
                                  className="border-2 border-card"
                                />
                              ))}
                              {characters.length > 4 && (
                                <div className="h-7 w-7 rounded-full bg-muted border-2 border-card flex items-center justify-center">
                                  <span className="text-xs">+{characters.length - 4}</span>
                                </div>
                              )}
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    )
                  })}
                </div>
              </div>
            )
          })}
        </div>
      )}

      <StorylineForm open={showForm} onOpenChange={handleFormClose} storyline={editingStoryline} />

      <StateOfTheArtReportDialog 
        open={showStateOfTheArtReport} 
        onOpenChange={setShowStateOfTheArtReport} 
      />

      <AlertDialog open={!!deleteConfirm} onOpenChange={(open) => !open && setDeleteConfirm(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Storyline löschen?</AlertDialogTitle>
            <AlertDialogDescription>
              Diese Aktion kann nicht rückgängig gemacht werden. Segmente, die dieser Storyline zugeordnet sind, werden
              nicht gelöscht.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Abbrechen</AlertDialogCancel>
            <AlertDialogAction onClick={() => deleteConfirm && handleDelete(deleteConfirm)}>Löschen</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <UpgradeModal
        open={showUpgradeModal}
        onOpenChange={setShowUpgradeModal}
        limitType="activeStorylines"
        currentCount={activeStorylinesCount}
        maxCount={currentPlan.limits.maxActiveStorylines === Infinity ? 999 : currentPlan.limits.maxActiveStorylines}
      />
    </>
  )
}
