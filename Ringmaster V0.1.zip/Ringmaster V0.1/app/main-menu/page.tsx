import { MainMenu } from "@/components/main-menu";

export default function MainMenuPage() {
  return <MainMenu />;
}