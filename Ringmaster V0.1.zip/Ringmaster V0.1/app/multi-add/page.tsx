"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Plus, X, Users, Upload } from "lucide-react"
import { useSeries } from "@/lib/series-context"

interface ParsedCharacter {
  name: string
  position: string
  alignment: string
  status: string
  hometown: string
}

export default function MultiAddPage() {
  const [inputText, setInputText] = useState("")
  const [parsedCharacters, setParsedCharacters] = useState<ParsedCharacter[]>([])

  const { addCharacter } = useSeries()

  const parseCharacters = () => {
    if (!inputText.trim()) return

    const lines = inputText.split('\n').filter(line => line.trim())
    const characters: ParsedCharacter[] = []

    for (const line of lines) {
      // Skip header lines
      if (line.includes('Wrestler') && line.includes('Position')) continue
      if (line.includes('---')) continue

      // Split by tabs or multiple spaces
      const parts = line.split(/\t+|\s{2,}/).filter(part => part.trim())
      
      if (parts.length >= 4) {
        const name = parts[0].trim()
        const position = parts[1].trim()
        const alignment = parts[2].trim()
        const status = parts[3].trim()
        const hometown = parts.slice(4).join(' ').trim()

        // Map position values to enum values
        let mappedPosition: string = "mid_card"
        if (position.toLowerCase().includes('main') || position.toLowerCase().includes('event')) {
          mappedPosition = "main_event"
        } else if (position.toLowerCase().includes('upper')) {
          mappedPosition = "upper_card"
        } else if (position.toLowerCase().includes('mid')) {
          mappedPosition = "mid_card"
        } else if (position.toLowerCase().includes('lower')) {
          mappedPosition = "lower_card"
        } else if (position.toLowerCase().includes('jobber')) {
          mappedPosition = "jobber"
        } else if (position.toLowerCase().includes('manager')) {
          mappedPosition = "manager"
        } else if (position.toLowerCase().includes('commentary')) {
          mappedPosition = "commentary"
        } else if (position.toLowerCase().includes('referee')) {
          mappedPosition = "referee"
        } else if (position.toLowerCase().includes('staff')) {
          mappedPosition = "staff"
        } else if (position.toLowerCase().includes('road')) {
          mappedPosition = "road_agent"
        }

        // Map alignment values
        let mappedAlignment: string = "face"
        if (alignment.toLowerCase().includes('heel')) {
          mappedAlignment = "heel"
        } else if (alignment.toLowerCase().includes('tween')) {
          mappedAlignment = "tweener"
        } else if (alignment.toLowerCase().includes('face')) {
          mappedAlignment = "face"
        }

        // Map status values
        let mappedStatus: string = "active"
        if (status.toLowerCase().includes('active')) {
          mappedStatus = "active"
        } else if (status.toLowerCase().includes('injur')) {
          mappedStatus = "injured"
        } else if (status.toLowerCase().includes('suspend')) {
          mappedStatus = "suspended"
        } else if (status.toLowerCase().includes('retir')) {
          mappedStatus = "retired"
        } else if (status.toLowerCase().includes('inact')) {
          mappedStatus = "inactive"
        }

        characters.push({
          name,
          position: mappedPosition,
          alignment: mappedAlignment,
          status: mappedStatus,
          hometown: hometown || ""
        })
      }
    }

    setParsedCharacters(characters)
  }

  const removeCharacter = (index: number) => {
    setParsedCharacters(parsedCharacters.filter((_, i) => i !== index))
  }

  const saveAllCharacters = async () => {
    try {
      for (const character of parsedCharacters) {
        await addCharacter({
          name: character.name,
          position: character.position as any,
          alignment: character.alignment as any,
          status: character.status as any,
          hometown: character.hometown,
        })
      }

      setParsedCharacters([])
      setInputText("")
      alert(`${parsedCharacters.length} Wrestler wurden erfolgreich gespeichert!`)
    } catch (error) {
      console.error("Fehler beim Speichern:", error)
      alert("Fehler beim Speichern der Wrestler.")
    }
  }

  return (
    <div className="container mx-auto p-6">
      <div className="mb-6">
        <h1 className="text-3xl font-bold">Multi Add - Wrestler</h1>
        <p className="text-muted-foreground">
          Fügen Sie mehrere Wrestler gleichzeitig über tabellarische Daten hinzu
        </p>
      </div>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5" />
            Daten einfügen
          </CardTitle>
          <CardDescription>
            Fügen Sie tabellarische Wrestler-Daten ein (Tab-getrennt oder mit Leerzeichen formatiert). 
            Erwartete Spalten: Name, Position, Alignment, Status, Heimatstadt
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Textarea
            placeholder="Wrestler	Position	Alignment	Status	Heimatstadt / Staat
Abdullah the Butcher	Uppercard	Heel	Active	The Sudan
Bam Bam Bigelow	Uppercard	Heel	Active	Asbury Park, New Jersey
Barry Windham	Main-Eventer	Heel	Active	Sweetwater, Texas..."
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            className="min-h-40 font-mono text-sm"
          />
          <Button onClick={parseCharacters} disabled={!inputText.trim()}>
            <Plus className="h-4 w-4 mr-2" />
            Wrestler parsen
          </Button>
        </CardContent>
      </Card>

      {parsedCharacters.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Geparste Wrestler ({parsedCharacters.length})
            </CardTitle>
            <CardDescription>
              Überprüfen Sie die geparsten Wrestler und speichern Sie sie in der Datenbank
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {parsedCharacters.map((character, index) => (
                <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex-1">
                    <div className="font-medium">{character.name}</div>
                    <div className="text-sm text-muted-foreground">
                      {character.position} • {character.alignment} • {character.status}
                      {character.hometown && ` • ${character.hometown}`}
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => removeCharacter(index)}
                    className="text-destructive hover:text-destructive"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>

            <div className="flex justify-end">
              <Button onClick={saveAllCharacters} size="lg" className="px-8">
                Alle {parsedCharacters.length} Wrestler speichern
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {parsedCharacters.length === 0 && inputText.trim() && (
        <Card>
          <CardContent className="text-center py-8 text-muted-foreground">
            <Users className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>Keine Wrestler geparst</p>
            <p className="text-sm">Fügen Sie Daten ein und klicken Sie auf "Wrestler parsen"</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
