"use client"

import { useState } from "react"
import { useSeries } from "@/lib/series-context"
import { PageHeader } from "@/components/page-header"
import { EmptyState } from "@/components/empty-state"
import { SceneForm } from "@/components/scene-form"
import { MultiSceneForm } from "@/components/multi-scene-form"
import { Pagination } from "@/components/ui/pagination"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuCheckboxItem } from "@/components/ui/dropdown-menu"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Plus, Clapperboard, MoreVertical, Pencil, Trash2, Search, MapPin, Clock, ArrowUpDown, Table } from "lucide-react"
import type { Segment } from "@/lib/types"
import { CharacterAvatar } from "@/components/character-avatar"

const ITEMS_PER_PAGE = 50

type SortOption = "status" | "alphabet" | "storyline"

const sortOptions: { value: SortOption; label: string }[] = [
  { value: "status", label: "Nach Status" },
  { value: "alphabet", label: "Nach Alphabet" },
  { value: "storyline", label: "Nach Storyline" },
]

export default function ScenesPage() {
  const { data, isLoading, deleteScene } = useSeries()
  const [showForm, setShowForm] = useState(false)
  const [showMultiForm, setShowMultiForm] = useState(false)
  const [editingScene, setEditingScene] = useState<Segment | undefined>()
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null)
  const [search, setSearch] = useState("")
  const [sortBy, setSortBy] = useState<SortOption>("status")
  const [currentPage, setCurrentPage] = useState(1)
  const [selectedActiveStorylines, setSelectedActiveStorylines] = useState<Set<string>>(new Set())
  const [selectedCompletedStorylines, setSelectedCompletedStorylines] = useState<Set<string>>(new Set())

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-pulse text-muted-foreground">Lädt Szenen...</div>
      </div>
    )
  }

  const filteredAndSortedScenes = (data.segments || [])
    .filter(
      (scene: Segment) => {
        // Textsuche
        const matchesSearch = scene.title.toLowerCase().includes(search.toLowerCase())

        // Storyline-Filter: wenn keine Storylines ausgewählt sind, zeige alle Segmente
        // wenn Storylines ausgewählt sind, zeige nur Segmente die zu diesen Storylines gehören
        const hasSelectedStorylines = selectedActiveStorylines.size > 0 || selectedCompletedStorylines.size > 0
        const allSelectedStorylines = new Set([...selectedActiveStorylines, ...selectedCompletedStorylines])

        const matchesStorylineFilter = !hasSelectedStorylines ||
          (scene.storylineIds && scene.storylineIds.some(id => allSelectedStorylines.has(id)))

        return matchesSearch && matchesStorylineFilter
      }
    )
    .sort((a: Segment, b: Segment) => {
      switch (sortBy) {
        case "status": {
          // Segmente nicht in Episode zuerst, dann Segmente in Episode
          const aInEpisode = data.episodes?.some((ep) => ep.sceneIds?.includes(a.id))
          const bInEpisode = data.episodes?.some((ep) => ep.sceneIds?.includes(b.id))
          if (aInEpisode !== bInEpisode) {
            return aInEpisode ? 1 : -1
          }
          // Bei gleichem Status: alphabetisch nach Titel
          return a.title.localeCompare(b.title)
        }
        case "alphabet":
          return a.title.localeCompare(b.title)
        case "storyline": {
          // Zuerst Segmente ohne Storyline, dann nach Storyline-Titel
          const aStoryline = (a.storylineIds && a.storylineIds.length > 0) 
            ? data.storylines.find((s) => s.id === a.storylineIds![0]) 
            : null
          const bStoryline = (b.storylineIds && b.storylineIds.length > 0) 
            ? data.storylines.find((s) => s.id === b.storylineIds![0]) 
            : null

          if (!aStoryline && !bStoryline) {
            return a.title.localeCompare(b.title)
          }
          if (!aStoryline) return -1
          if (!bStoryline) return 1

          const storylineCompare = aStoryline.title.localeCompare(bStoryline.title)
          if (storylineCompare !== 0) return storylineCompare

          // Bei gleicher Storyline: alphabetisch nach Titel
          return a.title.localeCompare(b.title)
        }
        default:
          return 0
      }
    })

  // Pagination berechnen
  const totalItems = filteredAndSortedScenes.length
  const totalPages = Math.ceil(totalItems / ITEMS_PER_PAGE)
  const startIndex = (currentPage - 1) * ITEMS_PER_PAGE
  const endIndex = startIndex + ITEMS_PER_PAGE
  const paginatedScenes = filteredAndSortedScenes.slice(startIndex, endIndex)

  // Reset zur ersten Seite wenn Suchbegriff sich ändert
  const handleSearchChange = (value: string) => {
    setSearch(value)
    setCurrentPage(1)
  }

  // Reset zur ersten Seite wenn Sortierung sich ändert
  const handleSortChange = (value: SortOption) => {
    setSortBy(value)
    setCurrentPage(1)
  }

  const handleEdit = (scene: Segment) => {
    setEditingScene(scene)
    setShowForm(true)
  }

  const handleDelete = (id: string) => {
    deleteScene(id)
    setDeleteConfirm(null)
    // Seite zurücksetzen wenn nötig
    setTimeout(() => {
      const newTotalItems = data.segments.length - 1
      const newTotalPages = Math.ceil(newTotalItems / ITEMS_PER_PAGE)
      if (currentPage > newTotalPages && newTotalPages > 0) {
        setCurrentPage(newTotalPages)
      }
    }, 0)
  }

  const handleFormClose = (open: boolean) => {
    setShowForm(open)
    if (!open) setEditingScene(undefined)
  }

  return (
    <>
      <PageHeader
        title="Segmente"
        description="Erstelle und verwalte einzelne Segmente"
        action={
          <div className="flex gap-2">
            <Button onClick={() => setShowForm(true)} className="gap-2">
              <Plus className="h-4 w-4" />
              Neues Segment
            </Button>
            <Button onClick={() => setShowMultiForm(true)} variant="outline" className="gap-2">
              <Clapperboard className="h-4 w-4" />
              Multi-Segmente erstellen
            </Button>
          </div>
        }
      />

      {/* Storyline Filters */}
      <div className="flex gap-4 mb-6">
        {/* Active Storylines Filter */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" className="gap-2">
              <div className="flex items-center gap-2">
                Aktive Storylines
                {selectedActiveStorylines.size > 0 && (
                  <Badge variant="secondary" className="ml-1">
                    {selectedActiveStorylines.size}
                  </Badge>
                )}
              </div>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start" className="w-56">
            {data.storylines.filter((s) => s.status !== "completed").length === 0 ? (
              <DropdownMenuItem disabled>
                Keine aktiven Storylines vorhanden
              </DropdownMenuItem>
            ) : (
              data.storylines
                .filter((s) => s.status !== "completed")
                .sort((a, b) => a.title.localeCompare(b.title))
                .map((storyline) => (
                  <DropdownMenuCheckboxItem
                    key={storyline.id}
                    checked={selectedActiveStorylines.has(storyline.id)}
                    onCheckedChange={(checked) => {
                      const newSelected = new Set(selectedActiveStorylines)
                      if (checked) {
                        newSelected.add(storyline.id)
                      } else {
                        newSelected.delete(storyline.id)
                      }
                      setSelectedActiveStorylines(newSelected)
                      setCurrentPage(1)
                    }}
                  >
                    <div className="flex items-center gap-2">
                      <div className="h-3 w-3 rounded-full" style={{ backgroundColor: storyline.color }} />
                      {storyline.title}
                    </div>
                  </DropdownMenuCheckboxItem>
                ))
            )}
          </DropdownMenuContent>
        </DropdownMenu>

        {/* Completed Storylines Filter */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" className="gap-2">
              <div className="flex items-center gap-2">
                Abgeschlossene Storylines
                {selectedCompletedStorylines.size > 0 && (
                  <Badge variant="secondary" className="ml-1">
                    {selectedCompletedStorylines.size}
                  </Badge>
                )}
              </div>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start" className="w-56">
            {data.storylines.filter((s) => s.status === "completed").length === 0 ? (
              <DropdownMenuItem disabled>
                Keine abgeschlossenen Storylines vorhanden
              </DropdownMenuItem>
            ) : (
              data.storylines
                .filter((s) => s.status === "completed")
                .sort((a, b) => a.title.localeCompare(b.title))
                .map((storyline) => (
                  <DropdownMenuCheckboxItem
                    key={storyline.id}
                    checked={selectedCompletedStorylines.has(storyline.id)}
                    onCheckedChange={(checked) => {
                      const newSelected = new Set(selectedCompletedStorylines)
                      if (checked) {
                        newSelected.add(storyline.id)
                      } else {
                        newSelected.delete(storyline.id)
                      }
                      setSelectedCompletedStorylines(newSelected)
                      setCurrentPage(1)
                    }}
                  >
                    <div className="flex items-center gap-2">
                      <div className="h-3 w-3 rounded-full" style={{ backgroundColor: storyline.color }} />
                      {storyline.title}
                    </div>
                  </DropdownMenuCheckboxItem>
                ))
            )}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* Search and Sort */}
      <div className="flex gap-4 mb-6">
        <div className="relative max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Segment suchen..."
            value={search}
            onChange={(e) => handleSearchChange(e.target.value)}
            className="pl-9"
          />
        </div>
        <div className="flex items-center gap-2 min-w-[200px]">
          <ArrowUpDown className="h-4 w-4 text-muted-foreground" />
          <Select value={sortBy} onValueChange={handleSortChange}>
            <SelectTrigger>
              <SelectValue placeholder="Sortieren nach..." />
            </SelectTrigger>
            <SelectContent>
              {sortOptions.map((option) => (
                <SelectItem key={option.value} value={option.value}>
                  {option.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {paginatedScenes.length === 0 ? (
        <EmptyState
          icon={Clapperboard}
          title={search ? "Keine Segmente gefunden" : "Noch keine Segmente"}
          description={
            search ? "Versuche andere Suchbegriffe." : "Erstelle Segmente um den Aufbau deiner Episoden zu planen."
          }
          actionLabel={!search ? "Erstes Segment erstellen" : undefined}
          onAction={!search ? () => setShowForm(true) : undefined}
        />
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {paginatedScenes.map((scene: Segment) => {
              const storyline = (scene.storylineIds && scene.storylineIds.length > 0) 
                ? data.storylines.find((s) => s.id === scene.storylineIds![0]) 
                : null
              const characters = data.characters
                .filter((c) => scene.characterIds.includes(c.id))
                .sort((a, b) => a.name.localeCompare(b.name))
              const episode = data.episodes.find((ep) => ep.sceneIds?.includes(scene.id))

              return (
                <Card key={scene.id} className="group hover:border-primary/50 transition-colors bg-card">
                  <CardHeader className="flex flex-row items-start justify-between space-y-0 pb-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        {storyline && (
                          <div className="h-3 w-3 rounded-full shrink-0" style={{ backgroundColor: storyline.color }} />
                        )}
                        <h3 className="font-semibold text-foreground leading-tight truncate">{scene.title}</h3>
                      </div>
                    </div>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <MoreVertical className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => handleEdit(scene)}>
                          <Pencil className="h-4 w-4 mr-2" />
                          Bearbeiten
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          onClick={() => setDeleteConfirm(scene.id)}
                          className="text-destructive focus:text-destructive"
                        >
                          <Trash2 className="h-4 w-4 mr-2" />
                          Löschen
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </CardHeader>
                  <CardContent className="pt-0">
                    {scene.description && (
                      <p className="text-sm text-muted-foreground line-clamp-2 mb-3">{scene.description}</p>
                    )}
                    <div className="flex items-center justify-between text-xs text-muted-foreground mb-3">
                      <span className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {scene.duration} Min.
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      {characters.length > 0 && (
                        <div className="flex -space-x-2">
                          {characters.slice(0, 4).map((char) => (
                            <CharacterAvatar
                              key={char.id}
                              character={char}
                              size="xs"
                              className="border-2 border-card"
                            />
                          ))}
                          {characters.length > 4 && (
                            <div className="h-6 w-6 rounded-full bg-muted border-2 border-card flex items-center justify-center">
                              <span className="text-xs">+{characters.length - 4}</span>
                            </div>
                          )}
                        </div>
                      )}
                      {episode && (
                        <Badge variant="secondary" className="text-xs">
                          In Event
                        </Badge>
                      )}
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>

          {/* Pagination */}
          {filteredAndSortedScenes.length > ITEMS_PER_PAGE && (
            <Pagination
              currentPage={currentPage}
              totalPages={totalPages}
              onPageChange={setCurrentPage}
              showInfo={true}
              totalItems={totalItems}
              itemsPerPage={ITEMS_PER_PAGE}
            />
          )}
        </>
      )}

      <SceneForm open={showForm} onOpenChange={handleFormClose} scene={editingScene} />

      <MultiSceneForm open={showMultiForm} onOpenChange={setShowMultiForm} />

      <AlertDialog open={!!deleteConfirm} onOpenChange={(open) => !open && setDeleteConfirm(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Segment löschen?</AlertDialogTitle>
            <AlertDialogDescription>
              Diese Aktion kann nicht rückgängig gemacht werden. Das Segment wird auch aus allen Events entfernt.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Abbrechen</AlertDialogCancel>
            <AlertDialogAction onClick={() => deleteConfirm && handleDelete(deleteConfirm)}>Löschen</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}
