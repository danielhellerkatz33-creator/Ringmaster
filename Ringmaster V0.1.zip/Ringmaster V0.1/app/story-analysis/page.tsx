"use client"

import { useState, useMemo } from "react"
import { useSeries } from "@/lib/series-context"
import { PageHeader } from "@/components/page-header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Copy, Brain, FileText, TrendingUp, MapPin, Clock, Users, Network } from "lucide-react"
import { toast } from "sonner"
import type { Segment, Character, Storyline, Relationship } from "@/lib/types"

// Hilfsfunktionen für Storyline-Analyse
const countBy = <T,>(array: T[], key: keyof T): Record<string, number> => {
  return array.reduce((acc, item) => {
    const value = String(item[key])
    acc[value] = (acc[value] || 0) + 1
    return acc
  }, {} as Record<string, number>)
}

const analyzeCharacterNetwork = (storyline: Storyline, segments: Segment[], characters: Character[], relationships: Relationship[]) => {
  // Alle einzigartigen Charakter-IDs aus den Segmenten sammeln
  const storylineCharacterIds = new Set<string>()
  segments.forEach(segment => {
    segment.characterIds.forEach(charId => storylineCharacterIds.add(charId))
  })

  // Charaktere nach Häufigkeit sortieren
  const characterFrequency: Record<string, number> = {}
  segments.forEach(segment => {
    segment.characterIds.forEach(charId => {
      characterFrequency[charId] = (characterFrequency[charId] || 0) + 1
    })
  })

  const sortedCharacters = Array.from(storylineCharacterIds)
    .map(charId => characters.find(c => c.id === charId))
    .filter(Boolean)
    .sort((a, b) => (characterFrequency[b!.id] || 0) - (characterFrequency[a!.id] || 0))

  // Relevante Beziehungen finden
  const relevantRelationships = relationships.filter(rel =>
    rel.characterIds && rel.characterIds.some(id => storylineCharacterIds.has(id))
  )

  return {
    characters: sortedCharacters as Character[],
    characterFrequency,
    relationships: relevantRelationships,
    totalCharacters: storylineCharacterIds.size
  }
}

const analyzeStoryProgression = (segments: Segment[]): string => {
  if (segments.length === 0) return "Keine Segmente verfügbar"

  const sortedSegments = [...segments].sort((a, b) => a.order - b.order)

  // Einfache Progression basierend auf Segment-Typen und Position
  const totalSegments = sortedSegments.length
  const firstThird = sortedSegments.slice(0, Math.floor(totalSegments / 3))
  const middleThird = sortedSegments.slice(Math.floor(totalSegments / 3), Math.floor(2 * totalSegments / 3))
  const lastThird = sortedSegments.slice(Math.floor(2 * totalSegments / 3))

  const getPhaseDescription = (phaseSegments: Segment[]): string => {
    if (phaseSegments.length === 0) return "Keine Segmente"

    // Einfache Heuristik für Story-Phasen
    const conflictKeywords = ['kampf', 'streit', 'konflikt', 'problem', 'krise']
    const resolutionKeywords = ['lösung', 'frieden', 'ende', 'abschluss']

    const hasConflict = phaseSegments.some(segment =>
      conflictKeywords.some(keyword =>
        segment.title.toLowerCase().includes(keyword) ||
        segment.description.toLowerCase().includes(keyword)
      )
    )

    const hasResolution = phaseSegments.some(segment =>
      resolutionKeywords.some(keyword =>
        segment.title.toLowerCase().includes(keyword) ||
        segment.description.toLowerCase().includes(keyword)
      )
    )

    if (hasResolution) return "Auflösung"
    if (hasConflict) return "Konflikt"
    if (phaseSegments.length > 0) return "Entwicklung"

    return "Setup"
  }

  return `${getPhaseDescription(firstThird)} → ${getPhaseDescription(middleThird)} → ${getPhaseDescription(lastThird)}`
}

const groupSegmentsByTheme = (segments: Segment[]): Record<string, Segment[]> => {
  const themes: Record<string, Segment[]> = {
    'Einführung': [],
    'Konflikt': [],
    'Entwicklung': [],
    'Höhepunkt': [],
    'Auflösung': [],
    'Andere': []
  }

  segments.forEach(segment => {
    const title = segment.title.toLowerCase()
    const description = segment.description.toLowerCase()
    const text = `${title} ${description}`

    if (text.includes('einführung') || text.includes('beginn') || text.includes('start') || text.includes('vorstellung')) {
      themes['Einführung'].push(segment)
    } else if (text.includes('kampf') || text.includes('streit') || text.includes('konflikt') || text.includes('krise') || text.includes('problem')) {
      themes['Konflikt'].push(segment)
    } else if (text.includes('höhepunkt') || text.includes('climax') || text.includes('kulmination') || text.includes('entscheidung')) {
      themes['Höhepunkt'].push(segment)
    } else if (text.includes('lösung') || text.includes('ende') || text.includes('abschluss') || text.includes('resolution')) {
      themes['Auflösung'].push(segment)
    } else if (text.includes('entwicklung') || text.includes('fortschritt') || text.includes('wachstum') || text.includes('änderung')) {
      themes['Entwicklung'].push(segment)
    } else {
      themes['Andere'].push(segment)
    }
  })

  // Leere Kategorien entfernen
  return Object.fromEntries(
    Object.entries(themes).filter(([, segments]) => segments.length > 0)
  )
}

const generateStorylineSummary = (storyline: Storyline, segments: Segment[], characters: Character[], relationships: Relationship[]) => {
  if (segments.length === 0) {
    return {
      overview: "Keine Segmente für diese Storyline gefunden.",
      stats: {},
      themes: {},
      characterNetwork: { characters: [], characterFrequency: {}, relationships: [], totalCharacters: 0 },
      progression: ""
    }
  }

  const locationStats = {} // Keine Location-Daten für Segmente verfügbar
  const timeStats = {} // Keine TimeOfDay-Daten für Segmente verfügbar
  const progression = analyzeStoryProgression(segments)
  const thematicGroups = groupSegmentsByTheme(segments)
  const characterNetwork = analyzeCharacterNetwork(storyline, segments, characters, relationships)

  const totalDuration = segments.reduce((sum, segment) => sum + segment.duration, 0)
  const avgDuration = Math.round(totalDuration / segments.length)

  return {
    overview: `"${storyline.title}": ${segments.length} Segmente mit ${characterNetwork.totalCharacters} Charakteren (Ø ${avgDuration} Minuten pro Segment)`,
    stats: {
      locations: locationStats,
      times: timeStats,
      totalDuration,
      avgDuration
    },
    themes: thematicGroups,
    characterNetwork,
    progression
  }
}

export default function StoryAnalysisPage() {
  const { data, isLoading } = useSeries()
  const [selectedStorylineId, setSelectedStorylineId] = useState<string>("")

  // Storyline-Daten für Analyse aggregieren
  const storylineAnalysis = useMemo(() => {
    if (!selectedStorylineId) return null

    const storyline = data.storylines.find(s => s.id === selectedStorylineId)
    if (!storyline) return null

    // Alle relevanten Daten sammeln
    const storylineScenes = data.segments.filter(s => 
      s.storylineIds && s.storylineIds.includes(storyline.id)
    )

    // Szenen chronologisch sortieren und mit Event-Informationen anreichern
    const sortedScenes = storylineScenes
      .map(scene => {
        // Finde das Event dieser Szene
        const event = data.episodes.find(ep => ep.sceneIds.includes(scene.id))
        return { ...scene, event }
      })
      .sort((a, b) => {
        // Zuerst nach Event sortieren, dann nach Szene-Order
        if (a.event && b.event) {
          if (a.event.eventNumber !== b.event.eventNumber) {
            return a.event.eventNumber - b.event.eventNumber
          }
        }
        return a.order - b.order
      })

    // Storyline-Zusammenfassung generieren
    const storylineSummary = generateStorylineSummary(storyline, sortedScenes, data.characters, data.relationships)

    return {
      storyline,
      scenes: sortedScenes,
      storylineSummary
    }
  }, [selectedStorylineId, data])

  // ChatGPT-Prompt generieren
  const generateChatGPTPrompt = () => {
    if (!storylineAnalysis) return ""

    const { storyline, scenes, storylineSummary } = storylineAnalysis

    const relationshipText = storylineSummary.characterNetwork.relationships.map((rel: Relationship) => {
      const charNames = rel.characterIds ? rel.characterIds.map(charId => {
        const char = data.characters.find(c => c.id === charId)
        return char?.name || 'Unbekannt'
      }) : ['Unbekannt']
      const relTypeText = rel.type === 'tag_team' ? 'Tag Team' : 
                         rel.type === 'stable' ? 'Stable' : 
                         rel.type === 'manager' ? 'Manager' : 
                         rel.type === 'rivalry' ? 'Rivalität' : 
                         rel.type === 'friendship' ? 'Freundschaft' : rel.type
      return `- ${charNames.join(' & ')}: ${relTypeText} (Intensität: ${rel.intensity}/10)`
    }).join("\n")

    const themeText = Object.entries(storylineSummary.themes).map(([theme, themeSegments]) =>
      `${theme} (${(themeSegments as Segment[]).length} Segmente)`
    ).join("\n")

    const sceneText = scenes.map(scene => {
      const eventInfo = scene.event
        ? `Event ${scene.event.eventNumber}`
        : `Event ?`
      return `- ${eventInfo}, Segment ${scene.order}: ${scene.title} - ${scene.description} (Dauer: ${scene.duration} Minuten)`
    }).join("\n")

    return `Du bist ein erfahrener Wrestling-Promotion-Autor. Analysiere diese Storyline und schlage Entwicklungsmöglichkeiten vor:

🎭 STORYLINE: ${storyline.title}
Typ: ${storyline.type === 'main' ? 'Hauptplot' : storyline.type === 'subplot' ? 'Nebenhandlung' : 'Charakterbogen'}
Status: ${storyline.status === 'planning' ? 'Planung' : storyline.status === 'active' ? 'Aktiv' : storyline.status === 'paused' ? 'Pausiert' : 'Abgeschlossen'}
Beschreibung: ${storyline.description}

📊 SEGMENT-ZUSAMMENFASSUNG:
${storylineSummary.overview}
• Story-Progression: ${storylineSummary.progression}
• Häufigste Orte: ${Object.entries(storylineSummary.stats.locations || {}).slice(0, 3).map(([loc, count]) => `${loc} (${count}x)`).join(", ")}
• Häufigste Tageszeiten: ${Object.entries(storylineSummary.stats.times || {}).slice(0, 3).map(([time, count]) => `${time} (${count}x)`).join(", ")}

🎭 CHARAKTER-NETZWERK:
${storylineSummary.characterNetwork.characters.map(char =>
  `- ${char.name} (${(storylineSummary.characterNetwork.characterFrequency as Record<string, number>)[char.id] || 0} Segmente, Rolle: ${char.position})`
).join("\n")}

💑 BEZIEHUNGEN INNERHALB DER STORYLINE:
${relationshipText}

🎬 THEMATISCHE GRUPPIERUNG:
${themeText}

📺 DETAILLIERTE SEGMENT-CHRONOLOGIE:
${sceneText}

Basierend auf diesen Daten:
1. Wie könnte sich diese Storyline weiterentwickeln?
2. Welche Charakter-Beziehungen sollten vertieft werden?
3. Gibt es Plotlöcher oder ungenutzte Möglichkeiten?
4. Wie passt diese Storyline in den Gesamtkontext der Promotion?
5. Welche Wendungen oder Twists wären besonders effektiv?`
  }

  const copyToClipboard = async () => {
    const prompt = generateChatGPTPrompt()
    await navigator.clipboard.writeText(prompt)
    toast.success("Prompt wurde in die Zwischenablage kopiert!")
  }

  if (isLoading) {
    return (
      <div className="animate-pulse space-y-4">
        <div className="h-8 bg-muted rounded w-1/4" />
        <div className="h-64 bg-muted rounded" />
      </div>
    )
  }

  return (
    <div className="space-y-8">
      <PageHeader
        title="Story-Analyse für KI"
        description="Analysiere Storylines und generiere KI-Prompts für ChatGPT"
      />

      {/* Storyline-Auswahl */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Network className="h-5 w-5" />
            Storyline auswählen
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Select value={selectedStorylineId} onValueChange={setSelectedStorylineId}>
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Wähle eine Storyline für die Analyse..." />
            </SelectTrigger>
            <SelectContent>
              {data.storylines.map((storyline) => (
                <SelectItem key={storyline.id} value={storyline.id}>
                  <div className="flex items-center gap-2">
                    <div
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: storyline.color }}
                    />
                    {storyline.title} ({storyline.type})
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {/* Analyse-Ergebnis */}
      {storylineAnalysis && (
        <>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Analyse: {storylineAnalysis.storyline.title}</span>
                <Button onClick={copyToClipboard} className="flex items-center gap-2">
                  <Copy className="h-4 w-4" />
                  Für ChatGPT kopieren
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Zusammenfassung */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center p-3 bg-muted/50 rounded-lg">
                  <div className="text-2xl font-bold">{storylineAnalysis.scenes.length}</div>
                  <div className="text-sm text-muted-foreground">Szenen</div>
                </div>
                <div className="text-center p-3 bg-muted/50 rounded-lg">
                  <div className="text-2xl font-bold">{storylineAnalysis.storylineSummary.characterNetwork.totalCharacters}</div>
                  <div className="text-sm text-muted-foreground">Charaktere</div>
                </div>
                <div className="text-center p-3 bg-muted/50 rounded-lg">
                  <div className="text-2xl font-bold">{storylineAnalysis.storylineSummary.characterNetwork.relationships.length}</div>
                  <div className="text-sm text-muted-foreground">Beziehungen</div>
                </div>
                <div className="text-center p-3 bg-muted/50 rounded-lg">
                  <div className="text-2xl font-bold">{Object.keys(storylineAnalysis.storylineSummary.themes).length}</div>
                  <div className="text-sm text-muted-foreground">Themen</div>
                </div>
              </div>

              {/* Szenen-Zusammenfassung */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Statistische Analyse */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-lg">
                      <TrendingUp className="h-5 w-5" />
                      Story-Analyse
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <div className="text-sm font-medium text-muted-foreground mb-1">Übersicht</div>
                      <div className="text-sm">{storylineAnalysis.storylineSummary.overview}</div>
                    </div>

                    <div>
                      <div className="text-sm font-medium text-muted-foreground mb-1">Story-Progression</div>
                      <div className="text-sm">{storylineAnalysis.storylineSummary.progression}</div>
                    </div>

                    <div>
                      <div className="text-sm font-medium text-muted-foreground mb-2">Häufigste Orte</div>
                      <div className="flex flex-wrap gap-1">
                        {Object.entries(storylineAnalysis.storylineSummary.stats.locations || {})
                          .sort(([,a], [,b]) => b - a)
                          .slice(0, 3)
                          .map(([location, count]) => (
                          <Badge key={location} variant="outline" className="text-xs">
                            {location} ({count})
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div>
                      <div className="text-sm font-medium text-muted-foreground mb-2">Häufigste Tageszeiten</div>
                      <div className="flex flex-wrap gap-1">
                        {Object.entries(storylineAnalysis.storylineSummary.stats.times || {})
                          .sort(([,a], [,b]) => b - a)
                          .slice(0, 3)
                          .map(([time, count]) => (
                          <Badge key={time} variant="outline" className="text-xs">
                            {time} ({count})
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Themen & Charakter-Netzwerk */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-lg">
                      <Users className="h-5 w-5" />
                      Themen & Charaktere
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <div className="text-sm font-medium text-muted-foreground mb-2">Thematische Gruppen</div>
                      <div className="space-y-1">
                        {Object.entries(storylineAnalysis.storylineSummary.themes).map(([theme, scenes]) => (
                          <div key={theme} className="flex justify-between text-sm">
                            <span>{theme}</span>
                            <Badge variant="secondary" className="text-xs">{(scenes as Segment[]).length} Szenen</Badge>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div>
                      <div className="text-sm font-medium text-muted-foreground mb-2">Wichtigste Charaktere</div>
                      <div className="space-y-1">
                        {storylineAnalysis.storylineSummary.characterNetwork.characters.slice(0, 5).map((character) => (
                          <div key={character.id} className="flex justify-between text-sm">
                            <span>{character.name}</span>
                            <Badge variant="secondary" className="text-xs">
                              {(storylineAnalysis.storylineSummary.characterNetwork.characterFrequency as Record<string, number>)[character.id] || 0} Szenen
                            </Badge>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Detaillierte Daten (für ChatGPT formatiert) */}
              <div className="bg-muted/30 p-4 rounded-lg font-mono text-sm whitespace-pre-wrap">
                {generateChatGPTPrompt()}
              </div>
            </CardContent>
          </Card>
        </>
      )}

      {!selectedStorylineId && (
        <Card>
          <CardContent className="text-center py-12">
            <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">
              Wähle eine Storyline aus, um die Analyse zu starten.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}