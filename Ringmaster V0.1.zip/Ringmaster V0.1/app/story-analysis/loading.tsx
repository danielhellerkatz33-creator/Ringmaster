export default function StoryAnalysisLoading() {
  return (
    <div className="animate-pulse space-y-4">
      <div className="h-8 bg-muted rounded w-1/4" />
      <div className="h-32 bg-muted rounded" />
      <div className="h-64 bg-muted rounded" />
    </div>
  )
}