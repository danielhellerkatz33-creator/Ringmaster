"use client"

import { useState } from "react"
import { useSeries } from "@/lib/series-context"
import { PageHeader } from "@/components/page-header"
import { EmptyState } from "@/components/empty-state"
import { ChampionshipForm } from "@/components/character-arc-form"
import { ChampionshipHistory } from "@/components/championship-history"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Plus, TrendingUp, MoreVertical, Pencil, Trash2, ArrowRight, Crown, History } from "lucide-react"
import { cn } from "@/lib/utils"
import type { CharacterArc, Character } from "@/lib/types"

const statusLabels: Record<CharacterArc["status"], string> = {
  planned: "Geplant",
  active: "Aktiv",
  completed: "Abgeschlossen",
}

const statusColors: Record<CharacterArc["status"], string> = {
  planned: "bg-gray-500/20 text-gray-400",
  active: "bg-blue-500/20 text-blue-500",
  completed: "bg-green-500/20 text-green-500",
}

export default function ArcsPage() {
  const { data, isLoading, deleteCharacterArc } = useSeries()
  const [showForm, setShowForm] = useState(false)
  const [editingArc, setEditingArc] = useState<CharacterArc | undefined>()
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null)
  const [showHistory, setShowHistory] = useState<CharacterArc | null>(null)

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-pulse text-muted-foreground">Lädt Championships...</div>
      </div>
    )
  }

  const handleEdit = (arc: CharacterArc) => {
    setEditingArc(arc)
    setShowForm(true)
  }

  const handleDelete = (id: string) => {
    deleteCharacterArc(id)
    setDeleteConfirm(null)
  }

  const handleFormClose = (open: boolean) => {
    setShowForm(open)
    if (!open) {
      setEditingArc(undefined)
    }
  }

  const getCharacter = (id: string) => data.characters.find((c) => c.id === id)
  const getEpisode = (id?: string) => (id ? data.episodes.find((e) => e.id === id) : undefined)

  const formatDate = (dateString?: string) => {
    if (!dateString) return null
    return new Date(dateString).toLocaleDateString('de-DE', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    })
  }

  // Group arcs by character
  const arcsByCharacter = data.characterArcs.reduce(
    (acc, arc) => {
      const charId = arc.characterId
      if (!acc[charId]) acc[charId] = []
      acc[charId].push(arc)
      return acc
    },
    {} as Record<string, CharacterArc[]>,
  )

  return (
    <>
      <PageHeader
        title={`Championships (${data.characterArcs.length})`}
        description="Verwalte die Titel deiner Promotion"
        action={
          <Button onClick={() => setShowForm(true)} className="gap-2">
            <Plus className="h-4 w-4" />
            Neues Championship
          </Button>
        }
      />

      {data.characterArcs.length === 0 ? (
        <EmptyState
          icon={TrendingUp}
          title="Noch keine Championships"
          description="Erstelle Championships um die Titel deiner Promotion zu verwalten."
          actionLabel="Erstes Championship erstellen"
          onAction={() => setShowForm(true)}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {data.characterArcs.map((arc) => {
            const completedMilestones = arc.milestones.filter((m) => m.completed).length
            const progress = arc.milestones.length > 0 ? (completedMilestones / arc.milestones.length) * 100 : 0
            const currentChampions = arc.currentChampionIds.map(id => 
              data.characters.find((c) => c.id === id)
            ).filter((c): c is Character => c !== undefined)

            return (
              <Card key={arc.id} className="group hover:border-primary/50 transition-colors bg-card">
                {arc.image && (
                  <div className="relative h-32 overflow-hidden">
                    <img
                      src={arc.image}
                      alt={arc.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                  </div>
                )}
                <CardHeader className={cn("flex flex-row items-start justify-between space-y-0 pb-3", arc.image && "pt-3")}>
                  <div>
                    <h3 className="font-semibold text-foreground leading-tight">{arc.title}</h3>
                    <div className="flex items-center gap-2 mt-1">
                      <Badge className={cn(statusColors[arc.status], "border-0")}>
                        {statusLabels[arc.status]}
                      </Badge>
                      <Badge variant="outline" className="text-xs">
                        {arc.type === "singles" ? "Singles" : 
                         arc.type === "tag_team" ? "Tag Team" :
                         arc.type === "trios" ? "Trios" : "Six-Man"}
                      </Badge>
                      <Badge variant="outline" className="text-xs">
                        {arc.prestige === "world" ? "World" :
                         arc.prestige === "national" ? "National" :
                         arc.prestige === "regional" ? "Regional" :
                         arc.prestige === "local" ? "Local" : "Developmental"}
                      </Badge>
                    </div>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => handleEdit(arc)}>
                        <Pencil className="h-4 w-4 mr-2" />
                        Bearbeiten
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => setShowHistory(arc)}>
                        <History className="h-4 w-4 mr-2" />
                        Titelhistorie
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        onClick={() => setDeleteConfirm(arc.id)}
                        className="text-destructive focus:text-destructive"
                      >
                        <Trash2 className="h-4 w-4 mr-2" />
                        Löschen
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </CardHeader>
                <CardContent className="pt-0">
                  {arc.description && (
                    <p className="text-sm text-muted-foreground line-clamp-2 mb-3">{arc.description}</p>
                  )}

                  {/* Current Champions */}
                  {currentChampions.length > 0 && (
                    <div className="flex items-center gap-2 text-xs text-muted-foreground mb-3">
                      <Crown className="h-3 w-3" />
                      <span>Aktuelle Champion{arc.type !== "singles" ? "s" : ""}: {currentChampions.map(c => c.name).join(", ")}</span>
                    </div>
                  )}

                  {(arc.startEpisodeId) && (
                    <div className="flex items-center gap-2 text-xs text-muted-foreground mb-3">
                      <span>
                        Gegründet: {formatDate(arc.startEpisodeId)}
                      </span>
                    </div>
                  )}

                  {/* Championship Stats */}
                  <div className="grid grid-cols-2 gap-4 text-xs">
                    <div>
                      <span className="text-muted-foreground">Regentschaften:</span>
                      <span className="font-medium ml-1">{arc.championHistory.length}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Status:</span>
                      <span className="font-medium ml-1">{statusLabels[arc.status]}</span>
                    </div>
                  </div>

                  {arc.milestones.length > 0 && (
                    <div className="space-y-2 mt-3">
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-muted-foreground">Meilensteine</span>
                        <span className="text-foreground">
                          {completedMilestones}/{arc.milestones.length}
                        </span>
                      </div>
                      <Progress value={progress} className="h-2" />
                    </div>
                  )}
                </CardContent>
              </Card>
            )
          })}
        </div>
      )}

      <ChampionshipForm open={showForm} onOpenChange={handleFormClose} arc={editingArc} />

      {showHistory && (
        <ChampionshipHistory
          open={!!showHistory}
          onOpenChange={(open) => !open && setShowHistory(null)}
          championshipId={showHistory.id}
        />
      )}

      <AlertDialog open={!!deleteConfirm} onOpenChange={(open) => !open && setDeleteConfirm(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Championship löschen?</AlertDialogTitle>
            <AlertDialogDescription>
              Diese Aktion kann nicht rückgängig gemacht werden.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Abbrechen</AlertDialogCancel>
            <AlertDialogAction onClick={() => deleteConfirm && handleDelete(deleteConfirm)}>Löschen</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}
