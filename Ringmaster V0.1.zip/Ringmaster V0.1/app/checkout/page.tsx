"use client"

import { useEffect, useState } from "react"
import { useSearchParams } from "next/navigation"
import { loadStripe } from "@stripe/stripe-js"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Loader2, CreditCard, ArrowLeft } from "lucide-react"

export default function CheckoutPage() {
  const searchParams = useSearchParams()
  const sessionId = searchParams.get("sessionId")
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState("")

  useEffect(() => {
    const redirectToStripe = async () => {
      if (!sessionId) {
        setError("No session ID provided")
        setIsLoading(false)
        return
      }

      try {
        // Get Stripe publishable key
        const publishableKey = process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY
        if (!publishableKey) {
          setError("Stripe not configured")
          setIsLoading(false)
          return
        }

        // Load Stripe and redirect to checkout
        const stripe = await loadStripe(publishableKey)
        if (!stripe) {
          setError("Failed to load Stripe")
          setIsLoading(false)
          return
        }

        // Redirect to Stripe Checkout using direct URL
        window.location.href = `https://checkout.stripe.com/pay/${sessionId}`
      } catch (err) {
        setError("An error occurred while setting up checkout")
        console.error("Checkout error:", err)
      } finally {
        setIsLoading(false)
      }
    }

    redirectToStripe()
  }, [sessionId])

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" />
          <p className="text-muted-foreground">Redirecting to Stripe...</p>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <div className="mx-auto mb-4 w-16 h-16 bg-red-100 dark:bg-red-900/20 rounded-full flex items-center justify-center">
              <CreditCard className="h-8 w-8 text-red-600 dark:text-red-400" />
            </div>
            <CardTitle className="text-red-600 dark:text-red-400">
              Checkout Error
            </CardTitle>
            <CardDescription>
              {error}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <Button onClick={() => window.history.back()} className="w-full">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Go Back
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return null // Should redirect before this renders
}
